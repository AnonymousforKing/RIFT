python -u main.py -dataset ENTITY -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 1
python -u main.py -dataset ENTITY -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 2
python -u main.py -dataset ENTITY -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 3
python -u main.py -dataset ENTITY -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 4

python -u main.py -dataset RELATION -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 1
python -u main.py -dataset RELATION -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 2
python -u main.py -dataset RELATION -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 3
python -u main.py -dataset RELATION -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 4

python -u main.py -dataset FACT -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 1.0 -note 55 -Top_k 1
python -u main.py -dataset FACT -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 1.0 -note 55 -Top_k 2
python -u main.py -dataset FACT -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 1.0 -note 55 -Top_k 3
python -u main.py -dataset FACT -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 1.0 -note 55 -Top_k 4

python -u main.py -dataset HYBRID -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 1
python -u main.py -dataset HYBRID -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 2
python -u main.py -dataset HYBRID -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 3
python -u main.py -dataset HYBRID -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 4

python -u main.py -dataset FB_CKGE -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 1
python -u main.py -dataset FB_CKGE -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 2
python -u main.py -dataset FB_CKGE -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 3
python -u main.py -dataset FB_CKGE -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 4

python -u main.py -dataset graph_lower -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 1
python -u main.py -dataset graph_lower -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 2
python -u main.py -dataset graph_lower -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 3
python -u main.py -dataset graph_lower -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 4

python -u main.py -dataset graph_equal -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 1
python -u main.py -dataset graph_equal -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 2
python -u main.py -dataset graph_equal -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 3
python -u main.py -dataset graph_equal -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 4

python -u main.py -dataset graph_higher -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 1
python -u main.py -dataset graph_higher -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 2
python -u main.py -dataset graph_higher -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 3
python -u main.py -dataset graph_higher -gpu 0 -CKGE_name MF-CKGE -learning_rate 0.0001 -batch_size 2048 -seed 55 -unify_weight 0.01 -reconstruct_weight 0.1 -note 55 -Top_k 4