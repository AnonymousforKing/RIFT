# -*- coding: utf-8 -*-
"""scatter_native 正确性验证:与纯 Python 参考实现逐元素对拍(独立运行,CPU 即可)。

覆盖本仓库全部真实调用形态:
  - scatter_add(src=[E,D] float, dim=0, index, dim_size)      (ConvLayer/GCN)
  - scatter_add(src=[E,1] long,  dim=0, index, dim_size)      (MAE.get_weight)
  - scatter_add(src=[E]   float, index, dim_size)  默认 dim    (ConvLayer else 分支)
  - scatter_mean(src=[E,D] float, dim=0, index, dim_size)     (ConvLayer 主路径)
  - scatter_max (值 + argmax 语义)                             (star-import 兼容)
边界:空 index、未覆盖桶、负值最大、dim_size 大于 index.max()+1。
"""
import sys, os
import numpy as np
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from src.model.scatter_native import scatter_add, scatter_mean, scatter_max

torch.manual_seed(3); np.random.seed(3)
ok_all = True


def check(name, cond, detail=""):
    global ok_all
    ok_all = ok_all and bool(cond)
    print(f"{'[PASS]' if cond else '[FAIL]'} {name}  {detail}")


def ref_add(src, index, dim_size):
    out = np.zeros((dim_size,) + tuple(src.shape[1:]), dtype=np.float64)
    for j, i in enumerate(index):
        out[i] += src[j]
    return out


def ref_mean(src, index, dim_size):
    s = ref_add(src, index, dim_size)
    c = np.zeros(dim_size)
    for i in index:
        c[i] += 1
    c = np.maximum(c, 1)
    return s / c.reshape((-1,) + (1,) * (src.ndim - 1))


def ref_max(src, index, dim_size):
    E = src.shape[0]
    vals = np.zeros((dim_size,) + tuple(src.shape[1:]), dtype=np.float64)
    args = np.full((dim_size,) + tuple(src.shape[1:]), E, dtype=np.int64)
    covered = np.zeros(dim_size, dtype=bool)
    for j, i in enumerate(index):
        if not covered[i]:
            vals[i] = src[j]
            args[i] = j
            covered[i] = True
        else:
            better = src[j] >= vals[i]      # 平局取最后(与实现一致)
            vals[i] = np.where(better, src[j], vals[i])
            args[i] = np.where(better, j, args[i])
    return vals, args


for trial, (E, D, N) in enumerate([(50, 8, 12), (200, 16, 40), (7, 1, 20), (0, 4, 5)]):
    idx_np = np.random.randint(0, max(N - 2, 1), size=E)   # 留出未覆盖桶
    src_np = np.random.randn(E, D) * 3
    idx = torch.from_numpy(idx_np).long()
    src = torch.from_numpy(src_np)

    a = scatter_add(src=src, dim=0, index=idx, dim_size=N)
    check(f"[{trial}] scatter_add [E={E},D={D}] == 参考", np.allclose(a.numpy(), ref_add(src_np, idx_np, N), atol=1e-12),
          f"max|Δ|={np.max(np.abs(a.numpy() - ref_add(src_np, idx_np, N))) if E else 0:.2e}")

    m = scatter_mean(src=src, dim=0, index=idx, dim_size=N)
    check(f"[{trial}] scatter_mean == 参考(未覆盖桶=0)", np.allclose(m.numpy(), ref_mean(src_np, idx_np, N), atol=1e-12))

    v, g = scatter_max(src=src, dim=0, index=idx, dim_size=N)
    rv, rg = ref_max(src_np, idx_np, N)
    check(f"[{trial}] scatter_max 值 == 参考(未覆盖桶=0)", np.allclose(v.numpy(), rv, atol=1e-12))
    gath_ok = True
    for i in range(N):
        for d in range(D):
            j = int(g[i, d].item())
            if j < E:
                gath_ok = gath_ok and (abs(src_np[j, d] - rv[i, d]) < 1e-12)
            else:
                gath_ok = gath_ok and (rg[i, d] == E)
    check(f"[{trial}] scatter_max argmax 指回最大源元素", gath_ok)

# 调用点形态:long src [E,1](get_weight)
E, N = 60, 15
idx_np = np.random.randint(0, N, size=E)
ones = torch.ones(E, dtype=torch.long).unsqueeze(1)
w = scatter_add(src=ones, dim=0, index=torch.from_numpy(idx_np).long(), dim_size=N)
ref_w = np.zeros((N, 1), dtype=np.int64)
for i in idx_np:
    ref_w[i, 0] += 1
check("get_weight 形态:long [E,1] scatter_add == 计数", np.array_equal(w.numpy(), ref_w), f"dtype={w.dtype}")

# 调用点形态:1-D src + 默认 dim(ConvLayer else 分支的 torch.ones(E))
s1 = torch.rand(E, dtype=torch.float64)
a1 = scatter_add(src=s1, index=torch.from_numpy(idx_np).long(), dim_size=N)
ref1 = np.zeros(N)
for j, i in enumerate(idx_np):
    ref1[i] += s1[j].item()
check("1-D src + 默认 dim scatter_add == 参考", np.allclose(a1.numpy(), ref1, atol=1e-12))

# float32 路径(MPS 精度)
srcf = torch.randn(80, 6, dtype=torch.float32)
idxf = torch.randint(0, 10, (80,))
af = scatter_add(src=srcf, dim=0, index=idxf, dim_size=10)
check("float32 dtype 跟随 src", af.dtype == torch.float32)
check("float32 数值 == float64 参考(1e-5)", np.allclose(af.numpy(), ref_add(srcf.numpy().astype(np.float64), idxf.numpy(), 10), atol=1e-5))

print("=" * 60)
print("scatter_native 全部通过 ✅" if ok_all else "存在失败 ❌")
sys.exit(0 if ok_all else 1)
