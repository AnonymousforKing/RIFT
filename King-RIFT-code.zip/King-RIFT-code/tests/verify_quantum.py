# -*- coding: utf-8 -*-
"""量子启发模块的数值验证(独立运行,CPU 即可)。

对照"复矩阵参考实现"逐比特校验门;校验振幅编码下保真度 = cos²、Hadamard 重述 = 余弦、
去极化/ZNE 单调性、shots 采样无偏性、贫瘠高原探针有限。仅依赖 torch + numpy。
"""
import sys, os, math
import numpy as np
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from src.model import quantum as Q

torch.manual_seed(0)
np.random.seed(0)
DT = torch.float64
PASS, FAIL = "[PASS]", "[FAIL]"
ok_all = True


def check(name, cond, detail=""):
    global ok_all
    ok_all = ok_all and bool(cond)
    print(f"{PASS if cond else FAIL} {name}  {detail}")


# ---- 复矩阵参考门:对单比特子空间用标准 2x2 幺正,验证双实通道实现 ----
def ref_apply(state, k, q, U):
    """对 q 比特复态 state(np complex,[2^q]) 的 qubit k 施加单比特门 U(2x2 complex)。"""
    dim = 1 << q
    out = np.zeros_like(state)
    kb = 1 << k
    for s in range(dim):
        if s & kb:
            continue
        s0, s1 = s, s | kb
        a0, a1 = state[s0], state[s1]
        out[s0] = U[0, 0] * a0 + U[0, 1] * a1
        out[s1] = U[1, 0] * a0 + U[1, 1] * a1
    return out


def gate_matrices(angle):
    c, s = math.cos(angle / 2), math.sin(angle / 2)
    RY = np.array([[c, -s], [s, c]], dtype=complex)
    RZ = np.array([[complex(c, -s), 0], [0, complex(c, s)]], dtype=complex)
    RX = np.array([[c, complex(0, -s)], [complex(0, -s), c]], dtype=complex)
    return {"ry": RY, "rz": RZ, "rx": RX}


print("=" * 70)
print("1) 单比特门:双实通道实现 vs 复矩阵参考(逐比特最大绝对误差应 ~0)")
print("=" * 70)
q = 3
dim = 1 << q
for gate, applier in [("ry", Q._apply_ry), ("rz", Q._apply_rz), ("rx", Q._apply_rx)]:
    max_err = 0.0
    for trial in range(5):
        psi = np.random.randn(dim) + 1j * np.random.randn(dim)
        psi /= np.linalg.norm(psi)
        angle = float(np.random.uniform(-math.pi, math.pi))
        k = np.random.randint(0, q)
        # 双实通道
        re = torch.tensor(psi.real, dtype=DT).view(1, -1)
        im = torch.tensor(psi.imag, dtype=DT).view(1, -1)
        re2, im2 = applier(re, im, k, q, torch.tensor(angle, dtype=DT))
        got = re2.view(-1).numpy() + 1j * im2.view(-1).numpy()
        ref = ref_apply(psi, k, q, gate_matrices(angle)[gate])
        max_err = max(max_err, float(np.max(np.abs(got - ref))))
    check(f"{gate.upper()} 门一致", max_err < 1e-12, f"max_err={max_err:.2e}")

print("\n" + "=" * 70)
print("2) CNOT 置换:control=1 时翻转 target")
print("=" * 70)
perm = Q._cnot_perm(2, 0, 1).numpy()  # control=qubit0(LSB), target=qubit1
# control 位(bit0)=1 的基态翻转 target 位(bit1):1<->3,0/2 不变 => [0,3,2,1]
expected = np.array([0, 3, 2, 1])
involutive = np.array_equal(perm[perm], np.arange(4))            # CNOT 自逆
is_perm = sorted(perm.tolist()) == [0, 1, 2, 3]
check("CNOT 置换正确(control=0,target=1)", np.array_equal(perm, expected), f"perm={perm.tolist()}")
check("CNOT 为合法置换且自逆", is_perm and involutive)

print("\n" + "=" * 70)
print("3) 振幅编码 + 态重叠:保真度 = cos²,Hadamard 重述 = 余弦")
print("=" * 70)
N, d = 64, 200
H = torch.randn(N, d, dtype=DT)
Hn = torch.nn.functional.normalize(H, 2, -1)
cos_classical = Hn @ Hn.t()                                  # 经典余弦矩阵
re, im = Q.amplitude_embed(H)                                # 无参振幅编码(零填充到 2^q)
fid = Q.fidelity_sim(re, im, re, im, squared=True)           # |⟨a|b⟩|²
overlap_re = Q.fidelity_sim(re, im, re, im, squared=False)   # Re⟨a|b⟩
check("零填充不改变内积(Re⟨a|b⟩=cos)",
      torch.allclose(overlap_re, cos_classical, atol=1e-10),
      f"max|Δ|={(overlap_re-cos_classical).abs().max().item():.2e}")
check("振幅编码保真度 = cos²",
      torch.allclose(fid, cos_classical ** 2, atol=1e-10),
      f"max|Δ|={(fid-cos_classical**2).abs().max().item():.2e}")
# overlap_measure 的三种模式
g = cos_classical
check("overlap_measure(hadamard)=cos", torch.allclose(Q.overlap_measure(g, 'hadamard'), g))
check("overlap_measure(swap)=cos²", torch.allclose(Q.overlap_measure(g, 'swap'), g * g))

print("\n" + "=" * 70)
print("4) state_overlap(hadamard) 与经典余弦矩阵逐元素相等(接线等价性的根据)")
print("=" * 70)
A = torch.randn(40, 200, dtype=DT)
B = torch.randn(33, 200, dtype=DT)
so = Q.state_overlap(A, B, mode='hadamard')
cos_ref = torch.nn.functional.normalize(A, 2, -1) @ torch.nn.functional.normalize(B, 2, -1).t()
check("state_overlap(hadamard)=经典余弦", torch.allclose(so, cos_ref, atol=1e-10),
      f"max|Δ|={(so-cos_ref).abs().max().item():.2e}")
check("state_overlap(swap)=余弦²",
      torch.allclose(Q.state_overlap(A, B, mode='swap'), cos_ref ** 2, atol=1e-10))

print("\n" + "=" * 70)
print("5) cosine_to_state_overlap(逐元素余弦,predict/parameter_cut 用)")
print("=" * 70)
a = torch.randn(50, 200, dtype=DT)
b = torch.randn(50, 200, dtype=DT)
c1 = Q.cosine_to_state_overlap(a, b, dim=-1)
c2 = torch.nn.functional.cosine_similarity(a, b, dim=-1)
check("cosine_to_state_overlap=cosine_similarity", torch.allclose(c1, c2, atol=1e-10),
      f"max|Δ|={(c1-c2).abs().max().item():.2e}")

print("\n" + "=" * 70)
print("6) shots 采样:无偏估计 |⟨a|b⟩|²(大 shots 收敛到解析 swap)")
print("=" * 70)
gen = torch.Generator().manual_seed(123)
g = torch.empty(2000, dtype=DT).uniform_(-1, 1)
analytic = g * g
est = torch.stack([Q.overlap_measure(g, 'shots', shots=4096, generator=gen) for _ in range(8)]).mean(0)
mae = (est - analytic).abs().mean().item()
check("shots 估计接近解析 swap", mae < 0.02, f"MAE={mae:.4f}")

print("\n" + "=" * 70)
print("7) VQC 幺正性:固定线路保范数 + 对所有态施加同一 U 不改变重叠(诚实点 ii)")
print("=" * 70)
circ = Q.VariationalCircuit(n_qubits=4, layers=3, full_rotation=True).to(DT)
re0, im0 = Q.amplitude_embed(torch.randn(20, 16, dtype=DT))
re1, im1 = circ(init_state=(re0, im0))
norms = (re1 ** 2 + im1 ** 2).sum(1)
check("VQC 输出为单位范数纯态", torch.allclose(norms, torch.ones_like(norms), atol=1e-10),
      f"max|‖ψ‖²-1|={(norms-1).abs().max().item():.2e}")
# 同一 U 作用前后,两两重叠不变
ov_before = Q.fidelity_sim(re0, im0, re0, im0, squared=True)
ov_after = Q.fidelity_sim(re1, im1, re1, im1, squared=True)
check("共享幺正不改变两两保真度(未训练线路=no-op)",
      torch.allclose(ov_before, ov_after, atol=1e-9),
      f"max|Δ|={(ov_before-ov_after).abs().max().item():.2e}")

print("\n" + "=" * 70)
print("8) 误差缓解:去极化把保真度往 1/D 收缩;ZNE 把它外推回纯态值")
print("=" * 70)
Fp = torch.tensor([0.9, 0.5, 0.1], dtype=DT)
D = 16
Fdep = Q.depolarized_fidelity(Fp, p=0.2, dim=D)
check("去极化向 1/D 收缩", bool(((Fdep - 1.0 / D).abs() < (Fp - 1.0 / D).abs()).all()),
      f"F={Fp.tolist()} → {[round(x,3) for x in Fdep.tolist()]}")
Fzne = Q.zne_fidelity(Fp, base_p=0.2, dim=D, scales=[1.0, 2.0, 3.0])
check("ZNE 外推回纯态值", torch.allclose(Fzne, Fp, atol=1e-6),
      f"max|Δ|={(Fzne-Fp).abs().max().item():.2e}")

print("\n" + "=" * 70)
print("9) QuantumHilbertHead 前向 + 局部保真度 + 贫瘠高原探针(可训练性)")
print("=" * 70)
head = Q.QuantumHilbertHead(in_dim=200, n_qubits=4, layers=2, rank=16,
                            encoding="amplitude", hybrid_readout=True).to(DT)
out = head(torch.randn(16, 200, dtype=DT))
check("头输出含合法纯态", out["squared"] and out["re"].shape == (16, 16))
lf = Q.local_fidelity_sim(out["re"], out["im"], out["re"], out["im"], q=4)
in_range = bool(((lf >= -1e-9) & (lf <= 1 + 1e-9)).all())
symmetric = torch.allclose(lf, lf.t(), atol=1e-9)
# 纠缠纯态的单比特约化态一般为混态,故自局部保真度 ½(1+|a_k|²)<1 属正确物理;
# 有意义的检验是"自身最相似"(对角为各行最大)与范围/对称性。
diag_is_rowmax = bool((lf.diag() >= lf.max(dim=1).values - 1e-9).all())
check("局部保真度 ∈[0,1] 且对称", in_range and symmetric)
check("局部保真度自身最相似(对角=行最大)", diag_is_rowmax,
      f"min diag={lf.diag().min().item():.4f}")
# 对**乘积态**(无纠缠)自局部保真度应=1:用单比特张量积构造一个可分态
prod = torch.zeros(3, 16, dtype=DT); prod[:, 0] = 1.0          # |0000> 乘积态
lf_prod = Q.local_fidelity_sim(prod, torch.zeros_like(prod), prod, torch.zeros_like(prod), q=4)
check("乘积态自局部保真度=1", bool((lf_prod.diag() > 1 - 1e-9).all()),
      f"min diag={lf_prod.diag().min().item():.4f}")
bp = Q.barren_plateau_probe(head, torch.randn(16, 200, dtype=DT), n_samples=12)
check("贫瘠高原探针返回有限值", math.isfinite(bp), f"var={bp:.3e}")

print("\n" + "=" * 70)
print(("全部通过 ✅" if ok_all else "存在失败 ❌"))
print("=" * 70)
sys.exit(0 if ok_all else 1)
