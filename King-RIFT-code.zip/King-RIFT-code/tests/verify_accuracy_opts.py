# -*- coding: utf-8 -*-
"""准确率优化开关的单元验证(独立运行,CPU)。

  1. config():命令行显式传入的 -learning_rate/-emb_dim/-batch_size/
     -reconstruct_weight 不再被静默覆盖;未传入时默认值与原版一致;
     patience 等参数统一为正确类型(修复 str 与 int 比较崩溃)。
  2. corrupt():-neg_avoid_pos True 时负例不与正例实体相同、且 id=num_ent-1
     可被采到;默认 False 时行为与原版一致(范围 [0, num_ent-1))。
  3. 学习率调度参数(与 main.build_scheduler 相同构造):plateau 在验证指标
     停滞 patience 轮后按 factor 衰减,不低于 lr_min。
"""
import sys, os
import numpy as np
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
ok_all = True


def check(name, cond, detail=""):
    global ok_all
    ok_all = ok_all and bool(cond)
    print(f"{'[PASS]' if cond else '[FAIL]'} {name}  {detail}")


class A:
    pass


# ---------------- 1. config() CLI 尊重与类型规范化 ----------------
from src.config import config

def fresh_args():
    a = A()
    a.dataset = 'HYBRID'; a.CKGE_name = 'MF-CKGE'
    a.learning_rate = '0.0001'; a.emb_dim = '200'; a.batch_size = '2048'
    a.unify_weight = '0.01'; a.reconstruct_weight = '0.1'
    a.snapshot_num = '5'; a.epoch_num = '200'; a.neg_ratio = '10'
    a.patience = '3'; a.num_layer = '1'; a.num_workers = '1'
    a.Top_k = '3'; a.seed = '55'; a.margin = '8.0'; a.l2 = '0.0'
    a.threshold = '1.0'; a.eval_ent_chunk = '0'; a.adv_temp = '0.0'
    a.lr_decay_factor = '0.5'; a.lr_decay_patience = '1'; a.lr_min = '1e-6'
    a.grad_clip = '0.0'; a.quantum_sim_shots = '0'
    return a

_argv = sys.argv
sys.argv = ['main.py']                                  # 未显式传参
a = fresh_args(); a.learning_rate = '0.05'              # 模拟脏值,应被默认覆盖
config(a)
check("未传 -learning_rate 时应用原默认 1e-4", a.learning_rate == 0.0001)
check("patience 规范化为 int(修复与 int 比较崩溃)", isinstance(a.patience, int) and a.patience == 3)
check("epoch_num/neg_ratio/Top_k 为 int", all(isinstance(getattr(a, k), int) for k in ('epoch_num', 'neg_ratio', 'Top_k')))
check("margin/threshold 为 float", all(isinstance(getattr(a, k), float) for k in ('margin', 'threshold')))

sys.argv = ['main.py', '-learning_rate', '0.001', '-emb_dim', '100', '-reconstruct_weight', '0.5']
a = fresh_args(); a.learning_rate = '0.001'; a.emb_dim = '100'; a.reconstruct_weight = '0.5'
config(a)
check("显式 -learning_rate 被尊重(原版会静默覆盖)", a.learning_rate == 0.001, f"lr={a.learning_rate}")
check("显式 -emb_dim 被尊重", a.emb_dim == 100)
check("显式 -reconstruct_weight 不被数据集默认值覆盖", a.reconstruct_weight == 0.5)
sys.argv = _argv

# ---------------- 2. corrupt() 负采样 ----------------
from src.data_load.data_loader import TrainDatasetMarginLoss

class Snap:
    pass

class KG:
    pass

def make_ds(num_ent, neg_avoid):
    ds = TrainDatasetMarginLoss.__new__(TrainDatasetMarginLoss)   # 跳过 __init__
    ar = A(); ar.snapshot = 0; ar.neg_ratio = 10; ar.neg_avoid_pos = neg_avoid
    kg = KG(); s = Snap(); s.num_ent = num_ent; kg.snapshots = {0: s}
    ds.args = ar; ds.kg = kg
    return ds

np.random.seed(5)
NUM_ENT = 12
ds = make_ds(NUM_ENT, 'True')
hit_last, false_neg = False, False
for _ in range(600):
    s, r, o = np.random.randint(0, NUM_ENT), 0, np.random.randint(0, NUM_ENT)
    facts, label = ds.corrupt((s, r, o))
    assert label[0] == 1 and all(l == -1 for l in label[1:])
    for (ns, rr, no) in facts[1:]:
        if ns == NUM_ENT - 1 or no == NUM_ENT - 1:
            hit_last = True
        # 腐蚀逻辑保证一侧为正例值;若两侧都等于正例 → 该"负例"就是正例本身(假负例)
        if ns == s and no == o:
            false_neg = True
check("neg_avoid_pos:id=num_ent-1 可被采到(修复范围少 1)", hit_last)
check("neg_avoid_pos:不再产生与正例相同的假负例", not false_neg)

np.random.seed(5)
ds0 = make_ds(NUM_ENT, 'False')
hit_last0 = False
ok_range = True
for _ in range(600):
    s, r, o = np.random.randint(0, NUM_ENT), 0, np.random.randint(0, NUM_ENT)
    facts, label = ds0.corrupt((s, r, o))
    for (ns, rr, no) in facts[1:]:
        if ns == NUM_ENT - 1 and ns != s:
            hit_last0 = True
        if no == NUM_ENT - 1 and no != o:
            hit_last0 = True
        ok_range = ok_range and (0 <= ns < NUM_ENT) and (0 <= no < NUM_ENT)
check("默认路径:负例范围仍为原版 [0, num_ent-1)", not hit_last0 and ok_range)

# ---------------- 3. plateau 调度(与 main.build_scheduler 相同构造) ----------------
p = torch.nn.Parameter(torch.zeros(3))
opt = torch.optim.Adam([p], lr=1e-4)
sch = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, mode='max', factor=0.5, patience=1, min_lr=1e-6)
lrs = []
metrics = [0.10, 0.20, 0.20, 0.20, 0.20, 0.20]     # 第 2 轮起停滞
for m in metrics:
    sch.step(m)
    lrs.append(opt.param_groups[0]['lr'])
check("plateau:停滞 patience=1 轮后 lr 衰减 0.5", abs(lrs[-1] - 1e-4 * 0.5 ** 2) < 1e-12 or lrs[-1] < 1e-4,
      f"lrs={lrs}")
check("plateau:lr 不低于 lr_min", all(l >= 1e-6 - 1e-15 for l in lrs))

print("=" * 60)
print("准确率开关单元验证全部通过 ✅" if ok_all else "存在失败 ❌")
sys.exit(0 if ok_all else 1)
