# -*- coding: utf-8 -*-
"""优化版 BaseModel.predict 与原版(3D 张量路径)的数值等价性验证(独立运行,CPU,float64)。

方法:构造多 snapshot 的真实 BaseModel(优化版),在**同一份权重与输入**上,
分别运行 (a) 优化版 model.predict 与 (b) 从原始仓库逐字转录的 predict_reference
(含 [B,R,D] 大张量、einsum、norm 的原式),对比:
  1. score_all 逐元素最大绝对差(期望 ~1e-16 量级:原式为 einsum(先乘计数 c)、
     优化式为 matmul(代数约去 c),两种归约顺序在 IEEE754 下相差 ≤ 数个 ulp);
  2. 金标实体的排名(MRR 口径)逐条相同 —— 指标层面的强保证;
  3. attention 汇总向量一致;
  4. -eval_ent_chunk 分块打分与不分块逐位一致(predict 与 predict_Valid);
  5. -adv_temp=0 与原版负例等权平均逐位一致;>0 时权重合法且难负例权重更大;
  6. state_dict 保存/加载往返后 predict 输出逐位复原(-restore_best 的机制基础)。

注:参考实现中 Tensor(train_ent2rel[...]) 在原版默认 dtype(float32)下会被后续
float64 乘法自动提升;画像计数为小整数,f32→f64 提升无损,故本测试统一在
float64 默认 dtype 下运行即复现原版数值。
"""
import sys, os
import numpy as np
import torch
import torch.nn as nn
from copy import deepcopy
from torch import Tensor

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from src.model.BaseModel import BaseModel

torch.manual_seed(11); np.random.seed(11)
torch.set_default_dtype(torch.float64)
ok_all = True


def check(name, cond, detail=""):
    global ok_all
    ok_all = ok_all and bool(cond)
    print(f"{'[PASS]' if cond else '[FAIL]'} {name}  {detail}")


# ---------------- 构造最小可用的 args / kg ----------------
class A:  # args
    pass


class Snap:
    pass


class KG:
    pass


NUM_ENT = [40, 70, 100]
NUM_REL = [8, 12, 14]
D = 64

args = A()
args.emb_dim = D
args.device = torch.device('cpu')
args.margin = 8.0
args.Parameter_cut = 'False'
args.Top_k = 3
args.wo_adaptive = 'False'
args.quantum_attn = 'False'
args.quantum_sim_mode = 'hadamard'
args.quantum_sim_shots = 0
args.eval_ent_chunk = 0
args.adv_temp = 0.0
args.neg_ratio = 10
args.snapshot = 2
args.snapshot_test = 2

kg = KG()
kg.snapshots = {}
for i in range(3):
    s = Snap()
    s.num_ent = NUM_ENT[i]
    s.num_rel = NUM_REL[i]
    # 画像计数含 0 与 >1 的值(2/3/5),覆盖 c 约去的全部情形
    te = np.random.randint(0, 3, size=(NUM_ENT[i], NUM_REL[i])).astype(np.float64)
    te[te == 2] = np.random.choice([2, 3, 5], size=(te == 2).sum())
    s.train_ent2rel = te
    kg.snapshots[i] = s

model = BaseModel(args, kg)
# 模拟 combine 后的多 snapshot 状态:补齐 snapshot1/2 的实体矩阵与增长后的关系矩阵
with torch.no_grad():
    for i in (1, 2):
        p = nn.Parameter(torch.randn(NUM_ENT[i], D))
        model.ent_embeddings_list.append(p)
    model.rel_embeddings = nn.Parameter(torch.randn(NUM_REL[-1], D))


# ---------------- 原版 predict 逐字转录(3D 张量路径) ----------------
def predict_reference(model, sub, rel, obj, stage='Valid'):
    self = model
    if stage != 'Test':
        num_ent = self.kg.snapshots[self.args.snapshot].num_ent
    else:
        num_ent = self.kg.snapshots[self.args.snapshot_test].num_ent

    stage = 'Test'
    ent_embeddings_list, rel_embeddings = self.embedding(stage)

    score_all = None
    r = torch.index_select(rel_embeddings, 0, rel)
    r_norm = self.norm_rel(r)

    attention_all = None
    idx = 0

    index_module = 0
    for t in range(len(ent_embeddings_list)):
        item = ent_embeddings_list[index_module]
        index_module += 1
        sub_mask = (sub >= 0) & (sub < item.shape[0])
        obj_mask = (obj >= 0) & (obj < item.shape[0])

        train_ent2rel = self.kg.snapshots[idx].train_ent2rel

        if num_ent > train_ent2rel.shape[0]:
            train_ent2rel = np.concatenate((train_ent2rel, np.zeros((num_ent - train_ent2rel.shape[0], train_ent2rel.shape[1]))), axis=0)
        else:
            train_ent2rel = train_ent2rel[:num_ent]

        sub_cpu = sub.cpu().detach().numpy()
        sub_r_index = Tensor(train_ent2rel[sub_cpu, :]).to(self.args.device)
        if sub_r_index.shape[1] < rel_embeddings.shape[0]:
            sub_r_index = torch.cat([sub_r_index, torch.zeros(sub_r_index.shape[0], rel_embeddings.shape[0] - sub_r_index.shape[1]).to(self.args.device)], dim=1)

        idx = idx + 1

        sub_r_embedding = sub_r_index.unsqueeze(2) * rel_embeddings
        norm_matrix1 = torch.norm(sub_r_embedding, dim=2)
        attention = torch.einsum('brd,bd->br', sub_r_embedding, r)

        nonzero_mask1 = norm_matrix1 > 0
        norm_matrix1 = torch.where(nonzero_mask1, norm_matrix1, norm_matrix1.new_tensor(1.0))
        norm_matrix2 = torch.norm(r, dim=1).unsqueeze(1)
        cos_attention = attention / (norm_matrix1 * norm_matrix2)
        k = int(self.args.Top_k)
        top_k_values, top_k_indices = torch.topk(cos_attention, k, dim=1)
        attention = top_k_values.sum(dim=1)

        attention[~sub_mask] = 0
        attention[~obj_mask] = 0
        if attention_all is None:
            attention_all = attention.unsqueeze(1)
        else:
            attention_all = torch.cat([attention_all, attention.unsqueeze(1)], dim=1)

    attention_all = nn.Softmax(dim=-1)(attention_all)
    if self.args.wo_adaptive == 'True':
        attention_all = torch.ones_like(attention_all) / attention_all.size(-1)

    index_module = 0
    with torch.no_grad():
        for t in range(len(self.ent_embeddings_list)):
            item = ent_embeddings_list[index_module]
            sub_mask = (sub >= 0) & (sub < item.shape[0])
            obj_mask = (obj >= 0) & (obj < item.shape[0])
            item = item[:num_ent]
            item = torch.cat([item, torch.zeros(num_ent - item.shape[0], self.args.emb_dim).to(self.args.device)], dim=0)
            s = torch.index_select(item, 0, sub)

            o_all = item[:num_ent]
            s = self.norm_ent(s)

            o_all = self.norm_ent(o_all)

            pred_o = s + r_norm

            score = 9.0 - torch.norm(pred_o.unsqueeze(1) - o_all, p=1, dim=2)
            score[~sub_mask] = 0
            score[~obj_mask] = 0
            if score_all is None:
                score_all = score * attention_all[:, index_module].unsqueeze(1)
            else:
                score_all += score * attention_all[:, index_module].unsqueeze(1)

            index_module += 1
        return score_all, torch.sum(attention_all, dim=0)


def gold_ranks(score, obj):
    '''与 model_process 相同口径的金标排名(不做 label 过滤,两侧一致即可对拍)'''
    b = torch.arange(score.size(0))
    return (1 + torch.argsort(torch.argsort(score, dim=1, descending=True), dim=1, descending=False))[b, obj]


# ---------------- 1/2/3:predict 等价性(两种 num_ent 分支) ----------------
for tag, stage, ss_test in [("snapshot_test=2(pad 分支)", 'Test', 2), ("snapshot_test=0(截断分支)", 'Test', 0)]:
    args.snapshot_test = ss_test
    ne = NUM_ENT[ss_test]
    B = 64
    sub = torch.randint(0, ne, (B,))
    obj = torch.randint(0, ne, (B,))
    rel = torch.randint(0, NUM_REL[-1], (B,))

    s_ref, a_ref = predict_reference(model, sub, rel, obj, stage=stage)
    s_opt, a_opt = model.predict(sub, rel, obj, stage=stage)

    dmax = (s_ref - s_opt).abs().max().item()
    check(f"{tag}: score 最大绝对差 < 1e-9", dmax < 1e-9, f"max|Δ|={dmax:.2e}")
    check(f"{tag}: attention 汇总一致", torch.allclose(a_ref, a_opt, atol=1e-9),
          f"max|Δ|={(a_ref-a_opt).abs().max().item():.2e}")
    rk_ref, rk_opt = gold_ranks(s_ref, obj).double(), gold_ranks(s_opt, obj).double()
    mrr_ref, mrr_opt = (1.0 / rk_ref).mean().item(), (1.0 / rk_opt).mean().item()
    check(f"{tag}: 金标排名逐条相同(MRR 口径)", torch.equal(rk_ref, rk_opt),
          f"MRR_ref={mrr_ref:.6f} MRR_opt={mrr_opt:.6f} |Δ|={abs(mrr_ref-mrr_opt):.2e}")

args.snapshot_test = 2

# ---------------- 4:eval_ent_chunk 分块 == 不分块(逐位) ----------------
B = 32
sub = torch.randint(0, NUM_ENT[2], (B,))
obj = torch.randint(0, NUM_ENT[2], (B,))
rel = torch.randint(0, NUM_REL[-1], (B,))
args.eval_ent_chunk = 0
s0, a0 = model.predict(sub, rel, obj, stage='Test')
args.eval_ent_chunk = 17          # 刻意不整除 num_ent=100
s1, a1 = model.predict(sub, rel, obj, stage='Test')
check("predict 分块打分与不分块逐位一致", torch.equal(s0, s1) and torch.equal(a0, a1),
      f"max|Δ|={(s0-s1).abs().max().item():.2e}")

model.expand_ent_embeddings = nn.Parameter(torch.randn(NUM_ENT[2], D))
args.eval_ent_chunk = 0
v0 = model.predict_Valid(sub, rel)
args.eval_ent_chunk = 23
v1 = model.predict_Valid(sub, rel)
check("predict_Valid 分块与不分块逐位一致", torch.equal(v0, v1),
      f"max|Δ|={(v0-v1).abs().max().item():.2e}")
args.eval_ent_chunk = 0
model.expand_ent_embeddings = None

# ---------------- 5:自对抗负采样 ----------------
NR = args.neg_ratio
score = torch.rand(6 * (NR + 1)) * 10
label = torch.cat([torch.ones(6).unsqueeze(1), -torch.ones(6, NR)], dim=1).reshape(-1)
score = score.reshape(6, NR + 1).reshape(-1)
args.adv_temp = 0.0
p0, n0 = model.split_pn_score(score, label)
n_manual = score.reshape(6, NR + 1)[:, 1:].reshape(-1, NR).mean(dim=1)
# 注意:split_pn_score 用布尔筛选,与手工 reshape 的取数一致
check("adv_temp=0 与原版等权平均逐位一致", torch.equal(n0, n_manual),
      f"max|Δ|={(n0-n_manual).abs().max().item():.2e}")

args.adv_temp = 1.0
p1, n1 = model.split_pn_score(score, label)
neg = score.reshape(6, NR + 1)[:, 1:]
w = torch.softmax(-1.0 * neg, dim=1)
n_expect = (w * neg).sum(dim=1)
check("adv_temp=1 加权结果与公式一致", torch.allclose(n1, n_expect, atol=1e-12))
check("难负例(距离更小)权重更大", bool((w[torch.arange(6), neg.argmin(dim=1)] >= w.max(dim=1).values - 1e-12).all()))
check("加权 n_score 介于负例最小/最大值之间",
      bool(((n1 >= neg.min(dim=1).values - 1e-12) & (n1 <= neg.max(dim=1).values + 1e-12)).all()))
args.adv_temp = 0.0

# ---------------- 6:state_dict 往返(restore_best 机制基础) ----------------
sd = deepcopy(model.state_dict())
s_before, _ = model.predict(sub, rel, obj, stage='Test')
with torch.no_grad():
    for pth in model.parameters():
        pth.add_(torch.randn_like(pth) * 0.5)
s_perturb, _ = model.predict(sub, rel, obj, stage='Test')
model.load_state_dict(sd)
s_after, _ = model.predict(sub, rel, obj, stage='Test')
check("扰动后输出确实变化(测试有效性)", not torch.equal(s_before, s_perturb))
check("load_state_dict 往返后 predict 逐位复原", torch.equal(s_before, s_after))

print("=" * 60)
print("predict 等价性验证全部通过 ✅" if ok_all else "存在失败 ❌")
sys.exit(0 if ok_all else 1)
