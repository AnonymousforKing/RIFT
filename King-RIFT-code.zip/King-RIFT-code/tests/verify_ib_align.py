# -*- coding: utf-8 -*-
"""跨面信息瓶颈对齐(ib_align.py)正确性验证(独立运行,CPU 即可)。

验证内容:
  A. IB 上界原语(compute_cluster_scores / estimate_q / ib_upper_bound / IBUpperBoundLoss)
     与内置 numpy 参考实现逐元素一致(证明是 IBMA 数学的忠实移植);
  B. CrossFacetIB 是**对齐**目标:两面一致时损失显著小于两面随机时;
  C. 退化 batch(实体<2 / 无关系列)返回 0,数值有限,确定性可复现;
  D. 关系无正例/无负例的边界下损失仍有限;
  E. 梯度能回传到两面表示;
  F. **默认不变量**:-ib_align_weight=0 时,TransE.loss 与不含该项时逐位一致
     (若能构造最小 KG 桩;否则跳过并提示在真实数据上由冒烟测试覆盖)。

用法:python tests/verify_ib_align.py
"""
import sys, os
import numpy as np
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
torch.set_default_dtype(torch.float64)  # 与 CPU 默认精度一致,便于严格对拍
from src.model.ib_align import (
    compute_cluster_scores, estimate_q, ib_upper_bound,
    IBUpperBoundLoss, CrossFacetIB, batch_centroids, CLUBLoss,
)

torch.manual_seed(0); np.random.seed(0)
ok_all = True


def check(name, cond, detail=""):
    global ok_all
    ok_all = ok_all and bool(cond)
    print(f"{'[PASS]' if cond else '[FAIL]'} {name}  {detail}")


# ---------------------------------------------------------------------------
# numpy 参考(与 IBMA/ib_loss.py 逐式对应)
# ---------------------------------------------------------------------------
def np_softmax(x, axis=-1):
    x = x - x.max(axis=axis, keepdims=True)
    e = np.exp(x)
    return e / e.sum(axis=axis, keepdims=True)

def np_normalize(x, axis=1, eps=1e-12):
    n = np.sqrt((x * x).sum(axis=axis, keepdims=True))
    return x / np.clip(n, eps, None)

def np_cdist2(a, b):
    return (a * a).sum(1)[:, None] + (b * b).sum(1)[None, :] - 2.0 * a @ b.T

def np_scores(feats, cents, beta=1.0, normalize=True):
    if normalize:
        feats = np_normalize(feats)
    return np_softmax(-beta * np_cdist2(feats, cents), axis=-1)

def np_estimate_q(sa, sb, eps=1e-9):
    return (sa.T @ sb) / np.clip(sb.sum(0), eps, None)

def np_ib(inp, sa, sb, q, eps=1e-9):
    t1 = np.einsum('ni,nj,nj->n', sa, inp, np.log(np.clip(inp, eps, None)))
    t2 = np.einsum('ni,nj,ij->n', sa, sb, np.log(np.clip(q, eps, None)))
    return (t1 - t2).mean()


# ---------------------------------------------------------------------------
# A. 原语逐元素对拍
# ---------------------------------------------------------------------------
N, D, K = 50, 12, 2
fa = np.random.randn(N, D); fb = fa + 0.1 * np.random.randn(N, D)
cent = np_normalize(np.random.randn(K, D))
tfa, tfb, tc = map(lambda z: torch.tensor(z), (fa, fb, cent))

sa_t = compute_cluster_scores(tfa, tc).numpy()
sa_n = np_scores(fa, cent)
check("compute_cluster_scores == numpy", np.allclose(sa_t, sa_n, atol=1e-12),
      f"max|Δ|={np.abs(sa_t - sa_n).max():.2e}")

sb_t = compute_cluster_scores(tfb, tc)
q_t = estimate_q(compute_cluster_scores(tfa, tc), sb_t).numpy()
q_n = np_estimate_q(sa_n, np_scores(fb, cent))
check("estimate_q == numpy", np.allclose(q_t, q_n, atol=1e-12),
      f"max|Δ|={np.abs(q_t - q_n).max():.2e}")

inp = np_scores(fa, cent, normalize=False)
ib_t = ib_upper_bound(torch.tensor(inp), compute_cluster_scores(tfa, tc),
                      sb_t, torch.tensor(q_n)).item()
ib_n = np_ib(inp, sa_n, np_scores(fb, cent), q_n)
check("ib_upper_bound == numpy", abs(ib_t - ib_n) < 1e-12, f"|Δ|={abs(ib_t - ib_n):.2e}")

# 多类 IBUpperBoundLoss(C=3)
C = 3
cents = np.stack([np_normalize(np.random.randn(K, D)) for _ in range(C)])   # [C,K,D]
inpa = np.stack([np_scores(fa, cents[c], normalize=False) for c in range(C)], axis=1)  # [N,C,K]
inpb = np.stack([np_scores(fb, cents[c], normalize=False) for c in range(C)], axis=1)
la_n = np.mean([np_ib(inpa[:, c], np_scores(fa, cents[c]), np_scores(fb, cents[c]),
                      np_estimate_q(np_scores(fa, cents[c]), np_scores(fb, cents[c]))) for c in range(C)])
ib = IBUpperBoundLoss(beta=1.0, symmetric=True, reduction='mean')
la_t, lb_t = ib(tfa, tfb, torch.tensor(inpa), torch.tensor(inpb),
                torch.tensor(cents), torch.tensor(cents))
check("IBUpperBoundLoss(loss_a) == numpy", abs(la_t.item() - la_n) < 1e-10,
      f"|Δ|={abs(la_t.item() - la_n):.2e}")

# ---------------------------------------------------------------------------
# B. CrossFacetIB 确为对齐:一致面 < 随机面
# ---------------------------------------------------------------------------
E = 40
zA = torch.randn(E, D, requires_grad=True)
labels = (torch.rand(E, C) < 0.5).double()
cf = CrossFacetIB(beta=1.0)
zB_aligned = (zA.detach() + 0.05 * torch.randn(E, D))
zB_random = torch.randn(E, D)
l_align = cf(zA.detach(), zB_aligned, labels).item()
l_rand = cf(zA.detach(), zB_random, labels).item()
check("aligned facet loss < random facet loss", l_align < l_rand,
      f"aligned={l_align:.4f} random={l_rand:.4f}")

# ---------------------------------------------------------------------------
# C. 退化 batch / 有限 / 确定性
# ---------------------------------------------------------------------------
check("N<2 -> 0", cf(zA.detach()[:1], zB_aligned[:1], labels[:1]).item() == 0.0)
check("C==0 -> 0", cf(zA.detach(), zB_aligned, labels[:, :0]).item() == 0.0)
v1 = cf(zA.detach(), zB_aligned, labels).item()
v2 = cf(zA.detach(), zB_aligned, labels).item()
check("deterministic", v1 == v2)

# ---------------------------------------------------------------------------
# D. 关系无正例/无负例边界
# ---------------------------------------------------------------------------
lab_no_pos = labels.clone(); lab_no_pos[:, 0] = 0.0
lab_no_neg = labels.clone(); lab_no_neg[:, 0] = 1.0
check("empty-positive class finite", np.isfinite(cf(zA.detach(), zB_aligned, lab_no_pos).item()))
check("empty-negative class finite", np.isfinite(cf(zA.detach(), zB_aligned, lab_no_neg).item()))

# ---------------------------------------------------------------------------
# E. 梯度回传到两面
# ---------------------------------------------------------------------------
zA2 = torch.randn(E, D, requires_grad=True)
zB2 = torch.randn(E, D, requires_grad=True)
out = cf(zA2, zB2, labels)
out.backward()
check("grad flows to facet A", zA2.grad is not None and torch.isfinite(zA2.grad).all()
      and zA2.grad.abs().sum() > 0)
check("grad flows to facet B", zB2.grad is not None and torch.isfinite(zB2.grad).all()
      and zB2.grad.abs().sum() > 0)

# ---------------------------------------------------------------------------
# F. batch_centroids 对拍 + CLUB learning_loss 可优化
# ---------------------------------------------------------------------------
cA_t, aA_t = batch_centroids(torch.tensor(fa), torch.tensor(np.asarray(labels)))
# numpy 参考
lab_np = np.asarray(labels)
pos = lab_np.T; neg = (1 - lab_np).T
cA_n = np_normalize((pos @ fa) / np.clip(pos.sum(1), 1, None)[:, None])
aA_n = np_normalize((neg @ fa) / np.clip(neg.sum(1), 1, None)[:, None])
check("batch_centroids == numpy", np.allclose(cA_t.numpy(), cA_n, atol=1e-10)
      and np.allclose(aA_t.numpy(), aA_n, atol=1e-10))

club = CLUBLoss(D, D)
opt = torch.optim.Adam(club.parameters(), lr=1e-2)
x = torch.randn(128, D); y = x @ torch.randn(D, D) + 0.1 * torch.randn(128, D)
l0 = club.learning_loss(x, y).item()
for _ in range(200):
    opt.zero_grad(); l = club.learning_loss(x, y); l.backward(); opt.step()
l1 = club.learning_loss(x, y).item()
check("CLUB learning_loss decreases (aux net fits q)", l1 < l0, f"{l0:.3f} -> {l1:.3f}")

print("\n==== IB-ALIGN VERIFICATION:", "ALL PASS ✅" if ok_all else "SOME FAILED ❌", "====")
sys.exit(0 if ok_all else 1)
