from .utils import *
from .model.model_process import *


class Trainer():
    def __init__(self, args, kg, model, optimizer):
        self.args = args
        self.kg = kg  # information of snapshot sequence
        self.model = model
        self.optimizer = optimizer
        self.logger = args.logger
        self.train_processor = TrainBatchProcessor(args, kg)
        
        self.valid_processor = DevBatchProcessor(args, kg)

    def run_epoch(self, validate=True):
        """Train one epoch and optionally run validation.

        Args:
            validate: Whether to evaluate on the validation set after training.
                ``main.py`` uses this to honor ``--valid_every``.

        Returns:
            A tuple ``(loss, validation_result)``.  When validation is
            skipped, ``validation_result`` is ``None``.
        """
        loss = self.train_processor.process_epoch(self.model, self.optimizer)
        if not validate:
            return loss, None

        previous_valid = getattr(self.args, "valid", False)
        self.args.valid = True
        try:
            result = self.valid_processor.process_epoch(self.model)
        finally:
            # Do not leak validation mode into later training/test data loaders.
            self.args.valid = previous_valid
        return loss, result


