# -*- coding: utf-8 -*-
"""Command-line options for MF-CKGE with IB-based facet alignment."""
import argparse


def str2bool(value):
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text in {"1", "true", "yes", "y", "on"}:
        return True
    if text in {"0", "false", "no", "n", "off"}:
        return False
    raise argparse.ArgumentTypeError("expected a boolean value, got %r" % value)


parser = argparse.ArgumentParser(
    description="MF-CKGE with Information Bottleneck-based Multimodal Alignment",
    formatter_class=argparse.ArgumentDefaultsHelpFormatter,
)

# Training control
parser.add_argument("-snapshot_num", default=5, type=int)
parser.add_argument("-dataset", default="HYBRID")
parser.add_argument("-gpu", default=0, help="cpu | mps | CUDA device id")
parser.add_argument("-loss_name", default="Margin")
parser.add_argument("-train_new", default=True, type=str2bool)
parser.add_argument("-skip_previous", default="False")
parser.add_argument("-preset", default="none", choices=("none", "hybrid_m2max"),
                    help="accuracy-oriented named preset; explicit CLI flags still win")

# Model and optimization
parser.add_argument("-CKGE_name", default="MF-CKGE")
parser.add_argument("-optimizer_name", default="Adam")
parser.add_argument("-embedding_model", default="TransE")
parser.add_argument("-epoch_num", default=200, type=int)
parser.add_argument("-margin", default=8.0, type=float)
parser.add_argument("-batch_size", default=2048, type=int)
parser.add_argument("-learning_rate", default=1e-4, type=float)
parser.add_argument("-emb_dim", default=200, type=int)
parser.add_argument("-l2", default=0.0, type=float)
parser.add_argument("-neg_ratio", default=10, type=int)
parser.add_argument("-patience", default=3, type=int,
                    help="number of validation checks without improvement")
parser.add_argument("-unify_weight", default=0.01, type=float)
parser.add_argument("-reconstruct_weight", default=0.1, type=float)
parser.add_argument("-relation_unify_loss", default="True")
parser.add_argument("-using_reconstruct_loss", default="True")
parser.add_argument("-using_finetune", default="True")

parser.add_argument("-loss_normalization", default="legacy", choices=("legacy", "positive"),
                    help="positive fixes the original extra division by positive+negative count")
parser.add_argument("-negative_loss", default="aggregate", choices=("aggregate", "pairwise"))
parser.add_argument("-struct_task_weight", default=0.0, type=float)
parser.add_argument("-fused_task_weight", default=0.0, type=float)
parser.add_argument("-fusion_alpha", default=0.5, type=float)
parser.add_argument("-inverse_relation_weight", default=0.0, type=float,
                    help="TransE consistency penalty ||r + r_inverse||^2")
parser.add_argument("-gcn_residual", default=0.0, type=float,
                    help="residual share of raw embeddings in the structural facet")
parser.add_argument("-norm_eps", default=1e-12, type=float,
                    help="normalization floor; use about 1e-6 for MPS/float32")
parser.add_argument("-regularizer_every", default=1, type=int,
                    help="compute GCN/MAE/IB objectives every N mini-batches")
parser.add_argument("-regularizer_rescale", default="True")

# I/O and evaluation
parser.add_argument("-save_path", default="./checkpoint/")
parser.add_argument("-data_path", default="./data/")
parser.add_argument("-log_path", default="./logs/")
parser.add_argument("-num_layer", default=1, type=int)
parser.add_argument("-num_workers", default=1, type=int)
parser.add_argument("-valid_metrics", default="mrr")
parser.add_argument("-valid", default=True, type=str2bool)
parser.add_argument("-valid_every", default=1, type=int)
parser.add_argument("-eval_batch_size", default=100, type=int)
parser.add_argument("-rank_method", default="sort", choices=("sort", "count"))
parser.add_argument("-note", default="")
parser.add_argument("-seed", default=55, type=int)
parser.add_argument("-switch_cpu_gpu", default="False")
parser.add_argument("-visualization", default="False")
parser.add_argument("-wo_adaptive", default="False")
parser.add_argument("-Pass_snapshot0", default="False")
parser.add_argument("-Parameter_cut", default="False")
parser.add_argument("-Top_k", default=3, type=int)
parser.add_argument("-threshold", default=1.0, type=float)
parser.add_argument("-temporal_fusion", default="legacy", choices=("legacy", "candidate"),
                    help="candidate removes gold-object leakage from temporal fusion")
parser.add_argument("-validation_mode", default="current", choices=("current", "temporal"),
                    help="temporal validates with the same multi-snapshot inference used at test time")

# Optional quantum-inspired paths retained from the uploaded project
parser.add_argument("-quantum_cut", default="False")
parser.add_argument("-quantum_attn", default="False")
parser.add_argument("-quantum_sim_mode", default="hadamard",
                    choices=("hadamard", "swap", "shots"))
parser.add_argument("-quantum_sim_shots", default=0, type=int)

# Apple Silicon / performance
parser.add_argument("-fp", default="auto",
                    help="auto (MPS=float32, CPU/CUDA=float64) | float32 | float64")
parser.add_argument("-matmul_precision", default="high", choices=("highest", "high", "medium"))
parser.add_argument("-eval_ent_chunk", default=0, type=int)

# Accuracy controls
parser.add_argument("-restore_best", default="False")
parser.add_argument("-adv_temp", default=0.0, type=float)
parser.add_argument("-lr_scheduler", default="none", choices=("none", "plateau", "cosine"))
parser.add_argument("-lr_decay_factor", default=0.5, type=float)
parser.add_argument("-lr_decay_patience", default=1, type=int)
parser.add_argument("-lr_min", default=1e-6, type=float)
parser.add_argument("-neg_avoid_pos", default="False")
parser.add_argument("-neg_sampler", default="legacy", choices=("legacy", "vectorized", "bernoulli"))
parser.add_argument("-filter_false_negative", default="False")
parser.add_argument("-grad_clip", default=0.0, type=float)

# Information Bottleneck-based Multimodal Alignment
parser.add_argument("-ib_align_weight", default=0.0, type=float)
parser.add_argument("-ib_mode", default="ibb", choices=("ibb", "club"))
parser.add_argument("-ib_beta", default=1.0, type=float)
parser.add_argument("-ib_eps", default=1e-6, type=float)
parser.add_argument("-ib_centroid_mode", default="batch", choices=("batch", "ema"))
parser.add_argument("-ib_ema_momentum", default=0.95, type=float)
parser.add_argument("-ib_min_pos", default=1, type=int)
parser.add_argument("-ib_min_neg", default=1, type=int)
parser.add_argument("-ib_max_relations", default=0, type=int)
parser.add_argument("-ib_warmup_epochs", default=0, type=int)
parser.add_argument("-ib_ramp_epochs", default=0, type=int)

args = parser.parse_args()
