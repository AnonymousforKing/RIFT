import torch
import torch.nn as nn
import torch.nn.functional as F
import logging
import time
import random
from prettytable import PrettyTable
from torch.nn.init import xavier_normal_
from torch.nn import Parameter
import numpy as np
from copy import deepcopy
import sys, os
from torch.backends import cudnn


def get_param(shape):
    '''create learnable parameters'''
    # Mac 适配:去掉硬编码 .double(),精度由全局默认 dtype 统一治理
    # (main.py 中 set_default_dtype;CPU/CUDA 默认 float64,与原版逐位一致;MPS 用 float32)
    param = Parameter(torch.Tensor(*shape))
    xavier_normal_(param.data)
    return param


def select_device(gpu_arg):
    '''
    设备自动选择(Mac 适配):
      -gpu cpu   → CPU
      -gpu mps   → Apple-Silicon GPU(不可用则回退)
      -gpu <id>  → cuda:<id>(默认 0);无 CUDA 时:MPS 可用 → MPS,否则 CPU
    返回 torch.device。原版在此处硬编码 torch.cuda.set_device + .cuda(),
    在 Mac(无 CUDA)上直接崩溃;本函数保持原命令行不变即可跨平台运行。
    '''
    s = str(gpu_arg).strip().lower()
    if s == 'cpu':
        return torch.device('cpu')
    mps_ok = getattr(torch.backends, 'mps', None) is not None and \
        torch.backends.mps.is_available()
    if s == 'mps':
        if mps_ok:
            return torch.device('mps')
        print('[device] 请求 MPS 但不可用,回退 CPU')
        return torch.device('cpu')
    if torch.cuda.is_available():
        idx = int(s) if s.isdigit() else 0
        torch.cuda.set_device(idx)
        return torch.device('cuda:{}'.format(idx))
    if mps_ok:
        return torch.device('mps')
    return torch.device('cpu')


def resolve_dtype(fp_arg, device):
    '''
    精度策略(-fp auto|float32|float64):
      auto:CPU/CUDA → float64(与原版 .double() 逐位一致);MPS → float32(MPS 不支持 float64)
      显式 float64 + MPS 为硬冲突,给出明确报错而非底层崩溃。
    '''
    s = str(fp_arg).strip().lower()
    is_mps = (device.type == 'mps')
    if s in ('auto', ''):
        return torch.float32 if is_mps else torch.float64
    if s in ('float32', 'fp32', '32'):
        return torch.float32
    if s in ('float64', 'fp64', '64', 'double'):
        if is_mps:
            raise ValueError('MPS 后端不支持 float64:请使用 -fp float32(推荐)或 -gpu cpu -fp float64')
        return torch.float64
    raise ValueError('未知 -fp 取值: {} (可选 auto|float32|float64)'.format(fp_arg))


def empty_device_cache(device):
    '''设备无关的缓存清理(替代原版硬编码 torch.cuda.empty_cache())'''
    try:
        if device.type == 'cuda':
            torch.cuda.empty_cache()
        elif device.type == 'mps' and hasattr(torch, 'mps') and hasattr(torch.mps, 'empty_cache'):
            torch.mps.empty_cache()
    except Exception:
        pass


def same_seeds(seed):
    '''Set seed for reproduction'''
    os.environ['PYTHONHASHSEED'] = str(seed)
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    # Mac 适配:MPS 随机种子(torch.manual_seed 在新版已覆盖 MPS,双保险显式设置)
    try:
        if getattr(torch.backends, 'mps', None) is not None and torch.backends.mps.is_available():
            torch.mps.manual_seed(seed)
    except Exception:
        pass
    np.random.seed(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True

def load_fact(path):
    '''
    Load (sub, rel, obj) from file 'path'.
    :param path: xxx.txt
    :return: fact list: [(s, r, o)]
    '''
    facts = []
    with open(path, 'r') as f:
        for line in f:
            line = line.split()
            s, r, o = line[0], line[1], line[2]
            facts.append((s, r, o))
    return facts


def build_edge_index(s, o):
    '''build edge_index using subject and object entity'''
    index = [s + o, o + s]
    return torch.LongTensor(index)
