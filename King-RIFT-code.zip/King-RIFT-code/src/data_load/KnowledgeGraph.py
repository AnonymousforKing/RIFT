from ..utils import *
from copy import deepcopy as dcopy


class KnowledgeGraph():
    def __init__(self, args):
        self.args = args

        self.num_ent, self.num_rel = 0, 0
        self.entity2id, self.id2entity, self.relation2id, self.id2relation = dict(), dict(), dict(), dict()
        self.relation2inv = dict()

        self.snapshots = {i: SnapShot(self.args) for i in range(int(self.args.snapshot_num))}
        self.load_data()

    def load_data(self):
        '''
        load data from all snapshot file
        '''
        sr2o_all = dict()
        train_all, valid_all, test_all = [], [], []

        for ss_id in range(int(self.args.snapshot_num)):
            self.new_entities = set()
            '''load facts'''
            train_facts = load_fact(self.args.data_path + str(ss_id) + '/' + 'train.txt')
            test_facts = load_fact(self.args.data_path + str(ss_id) + '/' + 'test.txt')
            valid_facts = load_fact(self.args.data_path + str(ss_id) + '/' + 'valid.txt')

            '''extract entities & relations from facts'''
            self.expand_entity_relation(train_facts)
            self.expand_entity_relation(valid_facts)
            self.expand_entity_relation(test_facts)

            '''read train/test/valid data'''
            train = self.fact2id(train_facts)
            valid = self.fact2id(valid_facts, order=True)
            test = self.fact2id(test_facts, order=True)

            '''
            Get edge_index and edge_type for GCN"
                edge_index = [[s_1, s_2, ... s_n],[o_1, o_2, ..., o_n]]
                edge_type = [r_1, r_2, ..., r_n]
            '''
            edge_s, edge_r, edge_o = [], [], []
            edge_s, edge_o, edge_r = self.expand_kg(train, 'train', edge_s, edge_o, edge_r, sr2o_all)
            edge_s, edge_o, edge_r = self.expand_kg(valid, 'valid', edge_s, edge_o, edge_r, sr2o_all)
            edge_s, edge_o, edge_r = self.expand_kg(test, 'test', edge_s, edge_o, edge_r, sr2o_all)

            train_ent2rel = np.zeros((self.num_ent, self.num_rel), dtype=np.bool_)
            ent_weight = np.zeros((self.num_ent,1))
            point_triple_num = np.zeros(self.num_ent)
            if self.args.CKGE_name == 'MF-CKGE':
                for (s,r,o) in train:
                    train_ent2rel[s, r] = True
                    r_inv = self.relation2inv[r]
                    train_ent2rel[o, r_inv] = True

                    ent_weight[s] += 1
                    ent_weight[o] += 1
                    point_triple_num[s] += 1
                    point_triple_num[o] += 1
            elif self.args.CKGE_name == 'RotatE':
                for (s,r,o) in train:
                    train_ent2rel[s, r] = True
                    r_inv = self.relation2inv[r]
                    train_ent2rel[o, r_inv] = True

                    ent_weight[s] += 1
                    ent_weight[o] += 1
                    point_triple_num[s] += 1
                    point_triple_num[o] += 1
                    
            '''prepare data for 're-training' model'''
            train_all += train
            valid_all += valid
            test_all += test

            '''store this snapshot'''
            self.store_snapshot(ss_id, train, train_all, test, test_all, valid, valid_all, edge_s, edge_o, edge_r, sr2o_all,
                                train_ent2rel)
            self.new_entities.clear()

    def expand_entity_relation(self, facts):
        '''extract entities and relations from new facts'''
        for (s, r, o) in facts:
            '''extract entities'''
            if s not in self.entity2id.keys():
                self.entity2id[s] = self.num_ent
                self.num_ent += 1
            if o not in self.entity2id.keys():
                self.entity2id[o] = self.num_ent
                self.num_ent += 1

            '''extract relations'''
            if r not in self.relation2id.keys():
                self.relation2id[r] = self.num_rel
                self.id2relation[self.num_rel] = r
                self.relation2id[r + '_inv'] = self.num_rel + 1
                self.id2relation[self.num_rel + 1] = r + '_inv'
                self.relation2inv[self.num_rel] = self.num_rel + 1
                self.relation2inv[self.num_rel + 1] = self.num_rel
                self.num_rel += 2

    def fact2id(self, facts, order=False):
        """Map named triples to ids; stable-sort by relation when requested."""
        fact_id = [
            (self.entity2id[s], self.relation2id[r], self.entity2id[o])
            for (s, r, o) in facts
        ]
        if order:
            fact_id.sort(key=lambda triple: triple[1])
        return fact_id

    def expand_kg(self, facts, split, edge_s, edge_o, edge_r, sr2o_all):
        '''expand edge_index, edge_type (for GCN) and sr2o (to filter golden facts)'''
        def add_key2val(dict, key, val):
            '''add {key: value} to dict'''
            if key not in dict.keys():
                dict[key] = set()
            dict[key].add(val)

        for (h, r, t) in facts:
            self.new_entities.add(h)
            self.new_entities.add(t)
            if split == 'train':
                '''edge_index'''
                edge_s.append(h)
                edge_r.append(r)
                edge_o.append(t)
            '''sr2o'''
            add_key2val(sr2o_all, (h, r), t)
            add_key2val(sr2o_all, (t, self.relation2inv[r]), h)
        return edge_s, edge_o, edge_r

    def _negative_sampling_metadata(self, train_for_stats, train_known):
        """Bernoulli statistics and train-only positive lookup.

        Validation/test facts belong in ``sr2o_all`` for filtered evaluation, but
        must not influence training-time negative sampling.  ``train_known`` is
        cumulative up to the current snapshot, preventing replayed true facts from
        becoming negatives without leaking held-out triples.
        """
        stats_bidirectional = []
        for h, r, t in train_for_stats:
            stats_bidirectional.append((h, r, t))
            stats_bidirectional.append((t, self.relation2inv[r], h))
        head_sets = [set() for _ in range(self.num_rel)]
        tail_sets = [set() for _ in range(self.num_rel)]
        counts = np.zeros(self.num_rel, dtype=np.float64)
        for h, r, t in stats_bidirectional:
            head_sets[r].add(h)
            tail_sets[r].add(t)
            counts[r] += 1.0
        probability = np.full(self.num_rel, 0.5, dtype=np.float32)
        for r in range(self.num_rel):
            if counts[r] <= 0:
                continue
            tph = counts[r] / max(len(head_sets[r]), 1)
            hpt = counts[r] / max(len(tail_sets[r]), 1)
            probability[r] = np.float32(tph / max(tph + hpt, 1e-12))

        ro2s = {}
        positive_codes = []
        for h, r, t in train_known:
            inverse = self.relation2inv[r]
            ro2s.setdefault((r, t), set()).add(h)
            ro2s.setdefault((inverse, h), set()).add(t)
            positive_codes.append((int(h) * self.num_rel + int(r)) * self.num_ent + int(t))
            positive_codes.append((int(t) * self.num_rel + int(inverse)) * self.num_ent + int(h))
        positive_codes = np.unique(np.asarray(positive_codes, dtype=np.int64))
        return probability, ro2s, positive_codes

    def store_snapshot(self, ss_id, train_new, train_all, test, test_all, valid, valid_all, edge_s, edge_o, edge_r, sr2o_all,train_ent2rel):
        '''store snapshot data'''
        self.snapshots[ss_id].num_ent = dcopy(self.num_ent)
        self.snapshots[ss_id].num_rel = dcopy(self.num_rel)

        '''train, valid and test data'''
        self.snapshots[ss_id].train_new = dcopy(train_new)
        self.snapshots[ss_id].train_all = dcopy(train_all)
        self.snapshots[ss_id].test = dcopy(test)
        self.snapshots[ss_id].valid = dcopy(valid)
        self.snapshots[ss_id].valid_all = dcopy(valid_all)
        self.snapshots[ss_id].test_all = dcopy(test_all)

        '''edge_index, edge_type (for GCN of MEAN and LAN)'''
        self.snapshots[ss_id].edge_s = dcopy(edge_s)
        self.snapshots[ss_id].edge_r = dcopy(edge_r)
        self.snapshots[ss_id].edge_o = dcopy(edge_o)

        self.snapshots[ss_id].train_ent2rel = dcopy(train_ent2rel)
        '''sr2o (to filter golden facts)'''
        self.snapshots[ss_id].sr2o_all = dcopy(sr2o_all)
        rel_head_prob, ro2s_all, positive_codes = self._negative_sampling_metadata(
            train_new, train_all
        )
        self.snapshots[ss_id].rel_head_prob = rel_head_prob
        self.snapshots[ss_id].ro2s_all = ro2s_all
        self.snapshots[ss_id].positive_codes = positive_codes
        '''
            Get edge_index and edge_type for GCN"
                edge_index = [[s_1, s_2, ... s_n],[o_1, o_2, ..., o_n]]
                edge_type = [r_1, r_2, ..., r_n]
        '''
        self.snapshots[ss_id].edge_index = build_edge_index(edge_s, edge_o).to(self.args.device)
        self.snapshots[ss_id].edge_type = torch.cat(
            [torch.LongTensor(edge_r), torch.LongTensor(edge_r) + 1]).to(self.args.device)
        self.snapshots[ss_id].new_entities = dcopy(list(self.new_entities))

        if self.args.CKGE_name in ['LAN', 'MEAN']:
            self.snapshots[ss_id].ent2neigh, self.snapshots[ss_id].edge_index_sample, self.snapshots[ss_id].edge_type_sample, self.snapshots[ss_id].ent_neigh_num = self.snapshots[ss_id].sample_neighbor()


class SnapShot():
    def __init__(self, args):
        self.args = args
        self.num_ent, self.num_rel = 0, 0
        self.train_new, self.train_all, self.test, self.valid, self.valid_all, self.test_all = list(), list(), list(), list(), list(), list()
        # 
        self.edge_s, self.edge_r, self.edge_o = [], [], []
        self.sr2o_all = dict()
        self.ro2s_all = dict()
        self.rel_head_prob = None
        self.positive_codes = np.empty(0, dtype=np.int64)
        self.edge_index, self.edge_type = None, None
        self.new_entities = []

        self.train_ent2rel = None
        
    def sample_neighbor(self):
        '''sample neighbor for MEAN or LAN'''
        num = 64
        res = []
        triples = self.train_new
        ent2triples = {i:list() for i in range(self.num_ent)}
        edge_index_sample, edge_type_sample = [], []
        ent_neigh_num = torch.zeros(self.num_ent).to(self.args.device)
        for triple in triples:
            h, r, t = triple
            ent2triples[h].append((h, r, t))
            ent2triples[t].append((t, r+1, h))
        for ent in range(self.num_ent):
            ent2triples[ent].append((ent, self.num_rel, ent))
            if len(ent2triples[ent]) > num:
                ent_neigh_num[ent] = num
                samples = [ent2triples[ent][i] for i in np.random.choice(range(len(ent2triples[ent])), num, replace=False)]
            else:
                samples = ent2triples[ent]
                ent_neigh_num[ent] = len(ent2triples[ent])
                for i in range(num - len(ent2triples[ent])):
                    samples.append((self.num_ent, self.num_rel+1, self.num_ent))
            res.append(samples)
            for hrt in samples:
                h, r, t = hrt
                if r == self.num_rel+1:
                    pass
                else:
                    edge_index_sample.append([ent, t])
                    edge_type_sample.append(r)

        return torch.LongTensor(res).to(self.args.device), torch.LongTensor(edge_index_sample).to(self.args.device).t(), torch.LongTensor(edge_type_sample).to(self.args.device), ent_neigh_num
