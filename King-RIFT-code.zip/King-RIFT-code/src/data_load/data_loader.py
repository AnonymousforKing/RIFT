# -*- coding: utf-8 -*-
"""Evaluation datasets and vectorized, relation-aware negative sampling."""
from __future__ import annotations

import numpy as np
import torch
from torch.utils.data import Dataset


def _enabled(value):
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


class TestDataset(Dataset):
    def __init__(self, args, kg):
        self.args = args
        self.kg = kg
        self.valid, self.test = self.build_facts()

    def __len__(self):
        if self.args.valid:
            return len(self.valid[self.args.snapshot])
        return len(self.test[self.args.snapshot_test])

    def __getitem__(self, idx):
        item = (self.valid[self.args.snapshot][idx] if self.args.valid
                else self.test[self.args.snapshot_test][idx])
        return torch.tensor(item["fact"], dtype=torch.long), item["label"]

    def collate_fn(self, data):
        facts = torch.stack([item[0] for item in data], dim=0)
        num_ent = self.kg.snapshots[
            self.args.snapshot if self.args.valid else self.args.snapshot_test
        ].num_ent
        labels = torch.zeros((len(data), num_ent), dtype=torch.bool)
        for row, (_, positives) in enumerate(data):
            if positives:
                ids = torch.as_tensor(tuple(positives), dtype=torch.long)
                labels[row, ids] = True
        return facts[:, 0], facts[:, 1], facts[:, 2], labels

    def get_label(self, label):
        num_ent = self.kg.snapshots[
            self.args.snapshot if self.args.valid else self.args.snapshot_test
        ].num_ent
        output = torch.zeros(num_ent, dtype=torch.bool)
        if label:
            output[torch.as_tensor(tuple(label), dtype=torch.long)] = True
        return output

    def build_facts(self):
        valid, test = [], []
        for ss_id in range(int(self.args.snapshot_num)):
            snapshot = self.kg.snapshots[ss_id]
            valid_items, test_items = [], []
            for s, r, o in snapshot.valid:
                valid_items.append({"fact": (s, r, o), "label": snapshot.sr2o_all[(s, r)]})
                valid_items.append({"fact": (o, r + 1, s), "label": snapshot.sr2o_all[(o, r + 1)]})
            for s, r, o in snapshot.test:
                test_items.append({"fact": (s, r, o), "label": snapshot.sr2o_all[(s, r)]})
                test_items.append({"fact": (o, r + 1, s), "label": snapshot.sr2o_all[(o, r + 1)]})
            valid.append(valid_items)
            test.append(test_items)
        return valid, test


class TrainDatasetMarginLoss(Dataset):
    def __init__(self, args, kg):
        self.args = args
        self.kg = kg
        self.facts, self.facts_new = self.build_facts()

    def __len__(self):
        source = self.facts_new if self.args.train_new else self.facts
        return len(source[self.args.snapshot])

    def _positive(self, idx):
        source = self.facts_new if self.args.train_new else self.facts
        return source[self.args.snapshot][idx]["fact"]

    def __getitem__(self, idx):
        fact = self._positive(idx)
        if str(getattr(self.args, "neg_sampler", "legacy")).lower() == "legacy":
            facts, labels = self.corrupt(fact)
            return torch.tensor(facts, dtype=torch.long), torch.tensor(labels), None, None
        return torch.tensor(fact, dtype=torch.long), None, None, None

    def collate_fn(self, data):
        if data[0][0].ndim == 2:
            fact = torch.cat([item[0] for item in data], dim=0)
            label = torch.cat([item[1] for item in data], dim=0)
            return fact[:, 0], fact[:, 1], fact[:, 2], label
        positives = torch.stack([item[0] for item in data], dim=0)
        facts, labels = self._corrupt_batch(positives)
        return facts[:, 0], facts[:, 1], facts[:, 2], labels

    def build_facts(self):
        all_seen, current_only = [], []
        cumulative = []
        for ss_id in range(int(self.args.snapshot_num)):
            new_items = []
            for s, r, o in self.kg.snapshots[ss_id].train_new:
                new_items.append({"fact": (s, r, o), "label": 1})
                new_items.append({"fact": (o, r + 1, s), "label": 1})
            cumulative.extend(new_items)
            current_only.append(new_items)
            all_seen.append(list(cumulative))
        return all_seen, current_only

    @staticmethod
    def _encode_triples(head, relation, tail, num_rel, num_ent):
        return (head.astype(np.int64) * int(num_rel) + relation.astype(np.int64)) * int(num_ent) + tail.astype(np.int64)

    def _known_positive_codes(self, snapshot):
        codes = getattr(snapshot, "positive_codes", None)
        if codes is not None and len(codes):
            return codes
        values = []
        for (head, relation), tails in snapshot.sr2o_all.items():
            for tail in tails:
                values.append((int(head) * int(snapshot.num_rel) + int(relation)) * int(snapshot.num_ent) + int(tail))
        return np.unique(np.asarray(values, dtype=np.int64))

    def _resample_known(self, candidates, corrupt_head, positives, snapshot):
        """Vectorized false-negative rejection using encoded known triples."""
        num_ent, num_rel = int(snapshot.num_ent), int(snapshot.num_rel)
        positive_np = positives.cpu().numpy().astype(np.int64, copy=False)
        relation = positive_np[:, 1:2]
        known = self._known_positive_codes(snapshot)
        if known.size == 0:
            return candidates

        def invalid_mask():
            head = np.where(corrupt_head, candidates, positive_np[:, 0:1])
            tail = np.where(corrupt_head, positive_np[:, 2:3], candidates)
            codes = self._encode_triples(head, relation, tail, num_rel, num_ent)
            # ``positive_codes`` is sorted/unique.  ``searchsorted`` avoids the
            # temporary hash/table construction of ``np.isin`` and is materially
            # faster for HYBRID (tens of thousands of candidates against >100k
            # known triples per batch).
            positions = np.searchsorted(known, codes)
            in_range = positions < known.size
            safe_positions = np.minimum(positions, known.size - 1)
            return in_range & (known[safe_positions] == codes)

        invalid = invalid_mask()
        for _ in range(12):
            count = int(invalid.sum())
            if count == 0:
                return candidates
            candidates[invalid] = np.random.randint(0, num_ent, count)
            invalid = invalid_mask()

        # Dense one-to-many relations can survive random rejection. Resolve only
        # those rare leftovers deterministically; the hot path stays vectorized.
        for row, col in np.argwhere(invalid):
            start = int(candidates[row, col])
            for offset in range(1, num_ent + 1):
                candidates[row, col] = (start + offset) % num_ent
                if not invalid_mask()[row, col]:
                    break
        return candidates

    def _corrupt_batch(self, positives):
        snapshot = self.kg.snapshots[self.args.snapshot]
        batch_size = positives.shape[0]
        ratio = int(self.args.neg_ratio)
        num_ent = int(snapshot.num_ent)
        positive_np = positives.cpu().numpy()
        relations = positive_np[:, 1]

        mode = str(getattr(self.args, "neg_sampler", "vectorized")).lower()
        if mode == "bernoulli" and snapshot.rel_head_prob is not None:
            head_probability = snapshot.rel_head_prob[relations][:, None]
        else:
            head_probability = 0.5
        corrupt_head = np.random.random((batch_size, ratio)) < head_probability
        candidates = np.random.randint(0, num_ent, size=(batch_size, ratio), dtype=np.int64)

        avoid_exact = (_enabled(getattr(self.args, "neg_avoid_pos", "False")) or
                       _enabled(getattr(self.args, "filter_false_negative", "False")))
        if avoid_exact:
            positive_entity = np.where(corrupt_head, positive_np[:, 0:1], positive_np[:, 2:3])
            candidates = np.where(candidates == positive_entity, (candidates + 1) % num_ent, candidates)
        if _enabled(getattr(self.args, "filter_false_negative", "False")):
            candidates = self._resample_known(candidates, corrupt_head, positives, snapshot)

        negative = np.repeat(positive_np[:, None, :], ratio, axis=1)
        negative[:, :, 0] = np.where(corrupt_head, candidates, positive_np[:, 0:1])
        negative[:, :, 2] = np.where(corrupt_head, positive_np[:, 2:3], candidates)
        combined = np.concatenate([positive_np[:, None, :], negative], axis=1)
        labels = np.full((batch_size, ratio + 1), -1.0, dtype=np.float32)
        labels[:, 0] = 1.0
        return torch.from_numpy(combined.reshape(-1, 3)), torch.from_numpy(labels.reshape(-1))

    def corrupt(self, fact):
        snapshot = self.kg.snapshots[self.args.snapshot]
        s, r, o = fact
        ratio = int(self.args.neg_ratio)
        num_ent = int(snapshot.num_ent)
        avoid = _enabled(getattr(self.args, "neg_avoid_pos", "False"))
        upper = num_ent if avoid else max(num_ent - 1, 1)
        neg_s = np.random.randint(0, upper, ratio)
        neg_o = np.random.randint(0, upper, ratio)
        if avoid:
            neg_s = np.where(neg_s == s, (neg_s + 1) % num_ent, neg_s)
            neg_o = np.where(neg_o == o, (neg_o + 1) % num_ent, neg_o)
        corruption = np.random.random(ratio) < 0.5
        sub = np.where(corruption, neg_s, s)
        obj = np.where(corruption, o, neg_o)
        facts = [(s, r, o)] + [(int(ns), r, int(no)) for ns, no in zip(sub, obj)]
        return facts, [1.0] + [-1.0] * ratio
