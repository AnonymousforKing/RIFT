# -*- coding: utf-8 -*-
"""Configuration normalization and named presets."""
import sys


def _cli_given(flag):
    return flag in sys.argv


def _set_unless_cli(args, flag, name, value):
    if not _cli_given(flag):
        setattr(args, name, value)


def _canonicalize_types(args):
    int_keys = [
        "snapshot_num", "epoch_num", "batch_size", "emb_dim", "neg_ratio", "patience",
        "num_layer", "num_workers", "Top_k", "seed", "eval_ent_chunk",
        "eval_batch_size", "valid_every", "regularizer_every", "lr_decay_patience",
        "quantum_sim_shots", "ib_min_pos", "ib_min_neg", "ib_max_relations",
        "ib_warmup_epochs", "ib_ramp_epochs",
    ]
    float_keys = [
        "learning_rate", "margin", "l2", "unify_weight", "reconstruct_weight",
        "threshold", "adv_temp", "lr_decay_factor", "lr_min", "grad_clip",
        "ib_align_weight", "ib_beta", "ib_ema_momentum", "struct_task_weight",
        "fused_task_weight", "fusion_alpha", "inverse_relation_weight", "gcn_residual", "norm_eps", "ib_eps",
    ]
    for key in int_keys:
        if hasattr(args, key):
            setattr(args, key, int(getattr(args, key)))
    for key in float_keys:
        if hasattr(args, key):
            setattr(args, key, float(getattr(args, key)))
    if hasattr(args, "train_new") and isinstance(args.train_new, str):
        args.train_new = args.train_new.strip().lower() in {"1", "true", "yes", "on"}
    if hasattr(args, "valid") and isinstance(args.valid, str):
        args.valid = args.valid.strip().lower() in {"1", "true", "yes", "on"}


def _ensure_new_defaults(args):
    defaults = {
        "preset": "none", "loss_normalization": "legacy", "negative_loss": "aggregate",
        "struct_task_weight": 0.0, "fused_task_weight": 0.0, "fusion_alpha": 0.5,
        "inverse_relation_weight": 0.0, "gcn_residual": 0.0,
        "norm_eps": 1e-12, "ib_eps": 1e-6,
        "regularizer_every": 1, "regularizer_rescale": "True", "valid_every": 1,
        "eval_batch_size": 100, "rank_method": "sort", "temporal_fusion": "legacy",
        "validation_mode": "current",
        "matmul_precision": "high", "neg_sampler": "legacy",
        "filter_false_negative": "False", "ib_centroid_mode": "batch",
        "ib_ema_momentum": 0.95, "ib_min_pos": 1, "ib_min_neg": 1,
        "ib_max_relations": 0, "ib_warmup_epochs": 0, "ib_ramp_epochs": 0,
    }
    for name, value in defaults.items():
        if not hasattr(args, name):
            setattr(args, name, value)


def _apply_hybrid_m2max(args):
    values = {
        "-gpu": ("gpu", "mps"), "-fp": ("fp", "float32"),
        "-batch_size": ("batch_size", 2048), "-emb_dim": ("emb_dim", 256),
        "-learning_rate": ("learning_rate", 2e-4), "-neg_ratio": ("neg_ratio", 24),
        "-patience": ("patience", 8), "-num_workers": ("num_workers", 0),
        "-restore_best": ("restore_best", "True"), "-adv_temp": ("adv_temp", 1.0),
        "-grad_clip": ("grad_clip", 5.0), "-lr_scheduler": ("lr_scheduler", "plateau"),
        "-lr_decay_patience": ("lr_decay_patience", 2),
        "-loss_normalization": ("loss_normalization", "positive"),
        "-negative_loss": ("negative_loss", "pairwise"),
        "-neg_sampler": ("neg_sampler", "bernoulli"),
        "-neg_avoid_pos": ("neg_avoid_pos", "True"),
        "-filter_false_negative": ("filter_false_negative", "True"),
        "-regularizer_every": ("regularizer_every", 2),
        "-regularizer_rescale": ("regularizer_rescale", "True"),
        "-struct_task_weight": ("struct_task_weight", 0.15),
        "-fused_task_weight": ("fused_task_weight", 0.25),
        "-fusion_alpha": ("fusion_alpha", 0.5),
        "-inverse_relation_weight": ("inverse_relation_weight", 0.01),
        "-gcn_residual": ("gcn_residual", 0.25),
        "-norm_eps": ("norm_eps", 1e-6),
        "-ib_eps": ("ib_eps", 1e-6),
        "-ib_align_weight": ("ib_align_weight", 0.02), "-ib_beta": ("ib_beta", 2.0),
        "-ib_centroid_mode": ("ib_centroid_mode", "ema"),
        "-ib_ema_momentum": ("ib_ema_momentum", 0.95),
        "-ib_min_pos": ("ib_min_pos", 2), "-ib_min_neg": ("ib_min_neg", 2),
        "-ib_max_relations": ("ib_max_relations", 64),
        "-ib_warmup_epochs": ("ib_warmup_epochs", 5),
        "-ib_ramp_epochs": ("ib_ramp_epochs", 20),
        "-valid_every": ("valid_every", 2), "-eval_batch_size": ("eval_batch_size", 128),
        "-eval_ent_chunk": ("eval_ent_chunk", 2048), "-rank_method": ("rank_method", "count"),
        "-temporal_fusion": ("temporal_fusion", "candidate"),
        "-validation_mode": ("validation_mode", "temporal"),
        "-matmul_precision": ("matmul_precision", "high"),
    }
    for flag, (name, value) in values.items():
        _set_unless_cli(args, flag, name, value)


def config(args):
    _ensure_new_defaults(args)
    if not _cli_given("-learning_rate"):
        args.learning_rate = 1e-4
    if not _cli_given("-emb_dim"):
        args.emb_dim = 200
    if not _cli_given("-batch_size"):
        args.batch_size = 2048

    dataset_reconstruct = 1.0 if getattr(args, "dataset", "") == "FACT" else 0.1
    if getattr(args, "CKGE_name", "") == "MF-CKGE":
        if not _cli_given("-unify_weight"):
            args.unify_weight = 0.01
        if not _cli_given("-reconstruct_weight"):
            args.reconstruct_weight = dataset_reconstruct

    if str(getattr(args, "preset", "none")).lower() == "hybrid_m2max":
        if getattr(args, "dataset", "HYBRID") != "HYBRID":
            raise ValueError("-preset hybrid_m2max is intended for -dataset HYBRID")
        _apply_hybrid_m2max(args)

    _canonicalize_types(args)
    if args.snapshot_num < 1:
        raise ValueError("snapshot_num must be >= 1")
    if args.batch_size < 1 or args.eval_batch_size < 1:
        raise ValueError("batch_size and eval_batch_size must be >= 1")
    if args.neg_ratio < 1:
        raise ValueError("neg_ratio must be >= 1")
    if args.Top_k < 1:
        raise ValueError("Top_k must be >= 1")
    if args.regularizer_every < 1:
        raise ValueError("regularizer_every must be >= 1")
    if args.valid_every < 1:
        raise ValueError("valid_every must be >= 1")
    if not 0.0 <= args.fusion_alpha <= 1.0:
        raise ValueError("fusion_alpha must be in [0, 1]")
    if not 0.0 <= args.gcn_residual <= 1.0:
        raise ValueError("gcn_residual must be in [0, 1]")
    if args.norm_eps <= 0 or args.ib_eps <= 0:
        raise ValueError("norm_eps and ib_eps must be positive")
    if not 0.0 <= args.ib_ema_momentum < 1.0:
        raise ValueError("ib_ema_momentum must be in [0, 1)")
