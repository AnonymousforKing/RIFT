# -*- coding: utf-8 -*-
"""torch_scatter 的原生 PyTorch 等价实现(Mac/Apple-Silicon 适配)。

背景:上游 `torch_scatter` 在 Apple Silicon 上无预编译轮子、源码编译困难,且不支持
MPS 后端。本模块用 PyTorch 原生算子(`index_add_` / `scatter_reduce_`)实现本仓库
实际用到的三个函数,签名与关键语义对齐 torch_scatter 2.x:

  - scatter_add(src, index, dim=-1, out=None, dim_size=None)
  - scatter_mean(src, index, dim=-1, out=None, dim_size=None)   # 无贡献位置为 0
  - scatter_max(src, index, dim=-1, out=None, dim_size=None)    # 返回 (values, argmax)
                                                                # 无贡献位置 value=0,
                                                                # argmax=src.size(dim)(哨兵)

约定(覆盖本仓库全部调用点):index 为 1-D LongTensor,长度 == src.size(dim);
沿 `dim` 聚合,其余维度保持。CPU / CUDA / MPS 通用;dtype 跟随 src。

正确性由 tests/verify_scatter.py 与纯 Python 参考实现逐元素对拍验证。
注:与 torch_scatter 相同,CUDA 上的浮点原子加法不保证跨运行逐位确定;
CPU 上确定。
"""
import torch

__all__ = ["scatter_add", "scatter_mean", "scatter_max"]


def _canon(src: torch.Tensor, index: torch.Tensor, dim: int, dim_size):
    """规范化 dim / dim_size,并做调用点约定的形状检查。"""
    if dim < 0:
        dim = src.dim() + dim
    if index.dim() != 1:
        index = index.reshape(-1)
    if index.numel() != src.size(dim):
        raise ValueError(
            f"scatter_native: index length {index.numel()} != src.size(dim)={src.size(dim)}")
    if dim_size is None:
        dim_size = int(index.max().item()) + 1 if index.numel() > 0 else 0
    return dim, index.long(), int(dim_size)


def scatter_add(src: torch.Tensor, index: torch.Tensor, dim: int = -1,
                out: torch.Tensor = None, dim_size=None) -> torch.Tensor:
    """out[i, ...] = Σ_{j: index[j]==i} src[j, ...](沿 dim 聚合)。"""
    dim, index, dim_size = _canon(src, index, dim, dim_size)
    shape = list(src.shape)
    shape[dim] = dim_size
    if out is None:
        out = torch.zeros(shape, dtype=src.dtype, device=src.device)
    # index_add_ 原生支持任意 dim + 1-D index,CPU/CUDA/MPS 均实现
    out.index_add_(dim, index, src)
    return out


def scatter_mean(src: torch.Tensor, index: torch.Tensor, dim: int = -1,
                 out: torch.Tensor = None, dim_size=None) -> torch.Tensor:
    """均值聚合;无贡献位置为 0(与 torch_scatter 2.x 的 count.clamp_(1) 语义一致)。"""
    dim, index, dim_size = _canon(src, index, dim, dim_size)
    summed = scatter_add(src, index, dim=dim, dim_size=dim_size)
    ones = torch.ones(index.numel(), dtype=src.dtype, device=src.device)
    count = torch.zeros(dim_size, dtype=src.dtype, device=src.device)
    count.index_add_(0, index, ones)
    count = count.clamp(min=1)
    # 把 count 广播到 summed 的 dim 维
    view = [1] * summed.dim()
    view[dim] = dim_size
    result = summed / count.view(view)
    if out is not None:
        out.copy_(result)
        return out
    return result


def scatter_max(src: torch.Tensor, index: torch.Tensor, dim: int = -1,
                out: torch.Tensor = None, dim_size=None):
    """最大值聚合,返回 (values, argmax)。

    对齐 torch_scatter 2.x 的可观测语义:无贡献位置 value=0、argmax=src.size(dim)。
    (本仓库当前激活路径未调用 scatter_max,保留以兼容 star-import 与后续实验。)
    """
    dim, index, dim_size = _canon(src, index, dim, dim_size)
    shape = list(src.shape)
    shape[dim] = dim_size

    values = torch.zeros(shape, dtype=src.dtype, device=src.device)
    idx_expand_shape = [1] * src.dim()
    idx_expand_shape[dim] = index.numel()
    index_expanded = index.view(idx_expand_shape).expand_as(src)
    # include_self=False:未覆盖位置保持初始 0,覆盖位置取真实最大值(可为负)
    values.scatter_reduce_(dim, index_expanded, src, reduce="amax", include_self=False)

    # argmax:src[j]==values[index[j]] 的位置取最大 j(平局取最后,与 CUDA 原子实现同为"未定序"之一)
    gathered = values.index_select(dim, index)
    eq = (src == gathered)
    pos = torch.arange(index.numel(), device=src.device).view(idx_expand_shape).expand_as(src)
    cand = torch.where(eq, pos, torch.full_like(pos, -1))
    arg = torch.full(shape, -1, dtype=torch.long, device=src.device)
    arg.scatter_reduce_(dim, index_expanded, cand, reduce="amax", include_self=False)
    sentinel = src.size(dim)
    arg = torch.where(arg < 0, torch.full_like(arg, sentinel), arg)

    if out is not None:
        out.copy_(values)
        return out, arg
    return values, arg
