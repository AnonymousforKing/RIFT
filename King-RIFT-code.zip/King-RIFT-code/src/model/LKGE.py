from .BaseModel import *


class LKGE(BaseModel):
    def __init__(self, args, kg):
        super(LKGE, self).__init__(args, kg)
        self.init_old_weight()
        self.mse_loss_func = nn.MSELoss(size_average=False)
        self.ent_weight, self.rel_weight, self.other_weight = None, None, None
        self.margin_loss_func = nn.MarginRankingLoss(float(self.args.margin), size_average=False).to(self.args.device)

    def store_old_parameters(self):
        '''
        Store learned paramters and weights for regularization.
        '''
        self.args.snapshot -= 1
        param_weight = self.get_new_weight()
        self.args.snapshot += 1

        for name, param in self.named_parameters():
            if f'ent_embeddings_list.{self.args.snapshot}' in name:
                name = name.replace('.', '_')
                value = param.data
                if self.args.snapshot == 0:
                    old_weight = getattr(self, f'old_weight_ent_embeddings_list_{self.args.snapshot}').to(self.args.device)
                else:
                    old_weight = getattr(self, f'old_weight_expand_ent_embeddings').to(self.args.device)
                new_weight = param_weight[name]
                self.register_buffer('old_data_expand_ent_embeddings', value)
                if self.args.snapshot == 0:
                    old_weight = torch.zeros_like(new_weight)
                else:
                    old_weight = torch.cat([old_weight, torch.zeros(new_weight.size(0) - old_weight.size(0), 1).to(self.args.device)], dim=0)
                self.register_buffer('old_weight_expand_ent_embeddings', old_weight + new_weight)
            elif 'rel' in name:
                name = name.replace('.', '_')
                value = param.data
                old_weight = getattr(self, 'old_weight_{}'.format(name))
                new_weight = param_weight[name]

                self.register_buffer('old_data_{}'.format(name), value)
                if '_embeddings' in name:
                    if self.args.snapshot == 0:
                        old_weight = torch.zeros_like(new_weight)
                    else:
                        old_weight = torch.cat([old_weight, torch.zeros(new_weight.size(0) - old_weight.size(0), 1).to(self.args.device)], dim=0)

                self.register_buffer('old_weight_{}'.format(name), old_weight + new_weight)
        

    def init_old_weight(self):
        '''
        Initialize the learned parameters for storage.
        '''
        for name, param in self.named_parameters():
            name_ = name.replace('.', '_')
            if 'ent_embeddings' in name_:
                self.register_buffer('old_weight_ent_embeddings_list_0', torch.tensor([[]]))
                self.register_buffer('old_data_ent_embeddings_list_0', torch.tensor([[]]))
                self.register_buffer('old_weight_{}'.format(name_), torch.tensor([[]]))
                self.register_buffer('old_data_{}'.format(name_), torch.tensor([[]]))
            elif 'rel_embeddings' in name_:
                self.register_buffer('old_weight_{}'.format(name_), torch.tensor([[]]))
                self.register_buffer('old_data_{}'.format(name_), torch.tensor([[]]))
            else:
                self.register_buffer('old_weight_{}'.format(name_), torch.tensor(0.0))
                self.register_buffer('old_data_{}'.format(name_), param.data)

    def switch_snapshot(self):
        '''
        Prepare for the training on next snapshot.
        '''
        '''store old parameters'''
        self.store_old_parameters()
        ent_embeddings_weight, rel_embeddings_weight = self.expand_embedding_size()
        new_ent_embeddings = ent_embeddings_weight.weight.data
        new_rel_embeddings = rel_embeddings_weight.weight.data
        new_rel_embeddings[:self.kg.snapshots[self.args.snapshot].num_rel] = torch.nn.Parameter(self.rel_embeddings.data)
        new_ent_embeddings[:self.kg.snapshots[self.args.snapshot].num_ent] = torch.nn.Parameter(self.ent_embeddings_list[-1].data)
        
        reconstruct_ent_embeddings, reconstruct_rel_embeddings = self.my_reconstruct(new_ent_embeddings,new_rel_embeddings)
        new_ent_embeddings[self.kg.snapshots[self.args.snapshot].num_ent:] = reconstruct_ent_embeddings[self.kg.snapshots[self.args.snapshot].num_ent:]
        new_rel_embeddings[self.kg.snapshots[self.args.snapshot].num_rel:] = reconstruct_rel_embeddings[self.kg.snapshots[self.args.snapshot].num_rel:]
        self.expand_ent_embeddings = torch.nn.Parameter(new_ent_embeddings)
        self.rel_embeddings = torch.nn.Parameter(new_rel_embeddings)
        '''store the total number of facts containing each entity or relation'''
        new_ent_weight, new_rel_weight, new_other_weight = self.get_weight()
        self.register_buffer('new_weight_ent_embeddings_weight', new_ent_weight.clone().detach())
        self.register_buffer('new_weight_rel_embeddings_weight', new_rel_weight.clone().detach())
        '''get regularization weights'''
        self.new_weight_other_weight = new_other_weight
    
    def reconstruct_rel(self,new_rel_embeddings):
        num_ent, num_rel = self.kg.snapshots[self.args.snapshot+1].num_ent, self.kg.snapshots[self.args.snapshot+1].num_rel
        edge_index, edge_type = self.kg.snapshots[self.args.snapshot+1].edge_index, self.kg.snapshots[self.args.snapshot+1].edge_type
        old_entity_weight, old_relation_weight = None, None
        old_x, old_r = None, None
        old_ent_embeddings, _ = self.embedding('switch')
        ent_embeddings_weight = self.expand_ent_embedding_size()
        new_ent_embeddings = ent_embeddings_weight

        new_ent_embeddings[:self.kg.snapshots[self.args.snapshot].num_ent] = old_ent_embeddings.data

        new_embeddings, rel_embeddings = self.gcn(torch.nn.Parameter(new_ent_embeddings), new_rel_embeddings, edge_index, edge_type, num_ent, num_rel, old_entity_weight, old_relation_weight, old_x, old_r)
        return rel_embeddings
    
    def store_gcn_embedding(self):

        num_ent, num_rel = self.kg.snapshots[self.args.snapshot].num_ent, self.kg.snapshots[self.args.snapshot].num_rel

        edge_index, edge_type = self.kg.snapshots[self.args.snapshot].edge_index, self.kg.snapshots[self.args.snapshot].edge_type
        old_entity_weight, old_relation_weight = None, None
        old_x, old_r = None, None
        ent_embeddings, rel_embeddings = self.embedding('Train')
        gcn_ent_embeddings, _= self.gcn(ent_embeddings, rel_embeddings, edge_index, edge_type, num_ent, num_rel, old_entity_weight, old_relation_weight, old_x, old_r)
        self.register_buffer('gcn_ent_{}_embeddings'.format(str(self.args.snapshot)), gcn_ent_embeddings.clone().detach())
    
    def parameter_cut(self):
        with torch.no_grad():
            num_ent = self.kg.snapshots[self.args.snapshot - 1].num_ent
            
            temp_num_ent = self.kg.snapshots[0].num_ent
            
            current_gcn_embedding = getattr(self, 'gcn_ent_{}_embeddings'.format(str(self.args.snapshot))).clone()
            norm_B = torch.norm(current_gcn_embedding[:num_ent], p=2, dim=1).detach()
            nonzero_maskB = norm_B > 0
            norm_B = torch.where(nonzero_maskB,norm_B,torch.tensor(1.0))
            
            all_cosine = None
            
            gcn_ent_0_embeddings = getattr(self, 'gcn_ent_{}_embeddings'.format(str(0)))
            dot_product = (current_gcn_embedding[:temp_num_ent] * gcn_ent_0_embeddings).sum(dim=1).detach()
            norm_A = torch.norm(gcn_ent_0_embeddings, p=2, dim=1).detach()  
            temp_norm_B = norm_B[:temp_num_ent]  
            cosine_sim = dot_product / (norm_A * temp_norm_B)
            if all_cosine is None:
                cosine_sim = torch.unsqueeze(cosine_sim, dim=1)
                all_cosine = torch.cat((cosine_sim, torch.zeros(num_ent - temp_num_ent, 1).to(self.args.device)), dim=0)

            for index in range(1,self.args.snapshot):

                gcn_ent_embeddings = getattr(self, 'gcn_ent_{}_embeddings'.format(str(index))).clone()

                mask = np.ones(gcn_ent_embeddings.shape[0], dtype=bool) 
                mask[self.valid_vectors[index]] = False  


                gcn_ent_embeddings[mask] = 0
                
                temp_num_ent = self.kg.snapshots[index].num_ent
                dot_product = (current_gcn_embedding[:temp_num_ent] * gcn_ent_embeddings).sum(dim=1).detach()
                
                norm_A = torch.norm(gcn_ent_embeddings, p=2, dim=1).detach()
                nonzero_maskA = norm_A > 0
                norm_A = torch.where(nonzero_maskA,norm_A,torch.tensor(1.0))
                
                temp_norm_B = norm_B[:temp_num_ent] 
                cosine_sim = dot_product / (norm_A * temp_norm_B)
                
                if all_cosine is not None:
                    cosine_sim = torch.unsqueeze(cosine_sim,dim = 1)
                    cosine_sim = torch.cat((cosine_sim,torch.zeros(num_ent - temp_num_ent, 1).to(self.args.device)),dim=0)
                    all_cosine = torch.cat((all_cosine,cosine_sim),dim = 1)
            

            all_cosine = all_cosine.cpu().numpy()
            value = np.amax(all_cosine,axis=1)
            max_indice = np.argmax(all_cosine,axis=1)
            threshold = float(self.args.threshold)
            valid_vectors = np.where(value < threshold)[0].tolist()
            unvalid_vectors = np.where(value >= threshold)[0].tolist()
            unvalid_to_oldIndex = max_indice[unvalid_vectors].tolist()

            additional_indices = list(np.arange(num_ent, self.kg.snapshots[self.args.snapshot].num_ent))
            self.valid_vectors.append(valid_vectors + additional_indices)

            self.unvalid_vectors.append(unvalid_vectors)
            self.unvalid_to_oldIndex.append(unvalid_to_oldIndex)
            
            cut_expand_ent_embeddings = self.expand_ent_embeddings[self.valid_vectors[self.args.snapshot]]

            self.expand_ent_embeddings = nn.Parameter(cut_expand_ent_embeddings)

    def my_reconstruct(self, new_ent_embeddings, new_rel_embeddings):
        '''
        Reconstruct the entity and relation embeddings.
        '''
        num_ent, num_rel = self.kg.snapshots[self.args.snapshot+1].num_ent, self.kg.snapshots[self.args.snapshot+1].num_rel
        edge_index, edge_type = self.kg.snapshots[self.args.snapshot+1].edge_index, self.kg.snapshots[self.args.snapshot+1].edge_type
        try:
            old_entity_weight = self.old_weight_entity_embeddings
            old_relation_weight = self.old_weight_relation_embeddings
            old_x = self.old_data_entity_embeddings
            old_r = self.old_data_relation_embeddings
        except:
            old_entity_weight, old_relation_weight = None, None
            old_x, old_r = None, None
        new_embeddings, rel_embeddings = self.gcn(new_ent_embeddings, new_rel_embeddings, edge_index, edge_type, num_ent, num_rel, old_entity_weight, old_relation_weight, old_x, old_r)
        return new_embeddings, rel_embeddings
    
    def reconstruct(self):
        '''
        Reconstruct the entity and relation embeddings.
        '''
        num_ent, num_rel = self.kg.snapshots[self.args.snapshot+1].num_ent, self.kg.snapshots[self.args.snapshot+1].num_rel
        edge_index, edge_type = self.kg.snapshots[self.args.snapshot+1].edge_index, self.kg.snapshots[self.args.snapshot+1].edge_type
        try:
            old_entity_weight = self.old_weight_entity_embeddings
            old_relation_weight = self.old_weight_relation_embeddings
            old_x = self.old_data_entity_embeddings
            old_r = self.old_data_relation_embeddings
        except:
            old_entity_weight, old_relation_weight = None, None
            old_x, old_r = None, None
        new_embeddings, rel_embeddings = self.gcn(self.ent_embeddings_list[-1].data, self.rel_embeddings.data, edge_index, edge_type, num_ent, num_rel, old_entity_weight, old_relation_weight, old_x, old_r)
        return new_embeddings, rel_embeddings

    def get_new_weight(self):
        '''
        Calculate the regularization weights for MAE loss.
        :return: weights.
        '''
        ent_weight, rel_weight, other_weight = self.get_weight()
        weight = dict()
        for name, param in self.named_parameters():
            name_ = name.replace('.','_')
            if 'ent_embeddings' in name_:
                weight[name_] = ent_weight
            elif 'rel_embeddings' in name_:
                weight[name_] = rel_weight
            else:
                weight[name_] = other_weight
        return weight

    def new_loss(self, head, rel, tail=None, label=None):
        return self.margin_loss(head, rel, tail, label).mean()

    def lkge_regular_loss(self):
        '''
        Calculate regularization loss to avoid catastrophic forgetting.
        :return: regularization loss.
        '''
        if self.args.snapshot == 0:
            return 0.0
        losses = []
        '''get samples number of entities and relations'''
        new_ent_weight, new_rel_weight, new_other_weight = self.new_weight_ent_embeddings_weight, self.new_weight_rel_embeddings_weight, self.new_weight_other_weight
        '''calculate regularization loss'''
        for name, param in self.named_parameters():
            name = name.replace('.', '_')
            if 'expand_ent_embeddings' in name:
                new_weight = new_ent_weight
                new_data = param
                old_weight = getattr(self, 'old_weight_expand_ent_embeddings')
                old_data = getattr(self, 'old_data_expand_ent_embeddings')
                if type(new_weight) != int:
                    new_weight = new_weight[:old_weight.size(0)]
                    new_data = new_data[:old_data.size(0)]
                    
                losses.append((((new_data - old_data) * old_weight / (new_weight+old_weight)) ** 2).sum())
            elif 'rel_embeddings' in name:
                new_weight = new_rel_weight
                new_data = param
                old_weight = getattr(self, 'old_weight_{}'.format(name))
                old_data = getattr(self, 'old_data_{}'.format(name))
                if type(new_weight) != int:
                    new_weight = new_weight[:old_weight.size(0)]
                    new_data = new_data[:old_data.size(0)]
                losses.append((((new_data - old_data) * old_weight / (new_weight+old_weight)) ** 2).sum())
            else:
                new_weight = new_other_weight
            # new_data = param
            # # old_weight = getattr(self, 'old_weight_{}'.format(name))
            # old_weight = getattr(self, 'old_weight_expand_ent_embeddings')
            # old_data = getattr(self, 'old_data_{}'.format(name))
            # if type(new_weight) != int:
            #     new_weight = new_weight[:old_weight.size(0)]
            #     new_data = new_data[:old_data.size(0)]
            # losses.append((((new_data - old_data) * old_weight / (new_weight+old_weight)) ** 2).sum())
        return sum(losses)

class TransE(LKGE):
    def __init__(self, args, kg):
        super(TransE, self).__init__(args, kg)
        self.gcn = MAE(args, kg)

    def MAE_loss(self):
        '''
        Calculate the MAE loss by masking and reconstructing embeddings.
        :return: MAE loss
        '''
        num_ent = self.kg.snapshots[self.args.snapshot].num_ent
        num_rel = self.kg.snapshots[self.args.snapshot].num_rel
        '''get subgraph(edge indexs and relation types of all facts in the training facts)'''
        edge_index = self.kg.snapshots[self.args.snapshot].edge_index
        edge_type = self.kg.snapshots[self.args.snapshot].edge_type

        '''reconstruct'''
        ent_embeddings, rel_embeddings = self.embedding('Train')
        try:
            old_entity_weight = self.old_weight_entity_embeddings
            old_relation_weight = self.old_weight_relation_embeddings
            old_x = self.old_data_entity_embeddings
            old_r = self.old_data_relation_embeddings
        except:
            old_entity_weight, old_relation_weight = None, None
            old_x, old_r = None, None
        ent_embeddings_reconstruct, rel_embeddings_reconstruct = self.gcn(ent_embeddings, rel_embeddings, edge_index, edge_type, num_ent, num_rel, old_entity_weight, old_relation_weight, old_x, old_r)
        return(self.mse_loss_func(ent_embeddings_reconstruct, ent_embeddings[:num_ent]) / num_ent + self.mse_loss_func(
            rel_embeddings_reconstruct, rel_embeddings[:num_rel]) / num_rel)

    def loss(self, head, rel, tail=None, label=None):
        '''
        :param head: subject entity
        :param rel: relation
        :param tail: object entity
        :param label: positive or negative facts
        :return: new facts loss + MAE loss + unify loss
        '''
        new_loss = self.new_loss(head, rel, tail, label)/head.size(0)
        loss = new_loss
        if self.args.using_reconstruct_loss == 'True':
            MAE_loss = self.MAE_loss()
            loss += float(self.args.reconstruct_weight)*MAE_loss
        
        regular_loss = self.lkge_regular_loss()
        loss += float(self.args.unify_weight)*regular_loss
        return loss

    def get_weight(self):
        '''get the total number of samples containing each entity or relation'''
        num_ent = self.kg.snapshots[self.args.snapshot+1].num_ent
        num_rel = self.kg.snapshots[self.args.snapshot+1].num_rel
        ent_weight, rel_weight, other_weight = self.gcn.get_weight(num_ent, num_rel)
        return ent_weight, rel_weight, other_weight


class MAE(nn.Module):
    def __init__(self, args, kg):
        super(MAE, self).__init__()
        self.args = args
        self.kg = kg
        '''masked KG auto encoder'''
        self.conv_layers = nn.ModuleList()
        for i in range(args.num_layer):
            self.conv_layers.append(ConvLayer(args, kg))

    def forward(self, ent_embeddings, rel_embeddings, edge_index, edge_type, num_ent, num_rel, old_entity_weight, old_relation_weight, old_x, old_r):
        '''
        Reconstruct embeddings for all entities and relations
        :param x: input entity embeddings
        :param r: input relation embeddings
        :param edge_index: (s, o)
        :param edge_type: (r)
        :param num_ent: entity number
        :param num_rel: relation number
        :return: reconstructed embeddings
        '''
        x, r = ent_embeddings, rel_embeddings
        for i in range(self.args.num_layer):
            x, r = self.conv_layers[i](x, r, edge_index, edge_type, num_ent, num_rel, old_entity_weight, old_relation_weight, old_x, old_r)
        return x, r

    def get_weight(self, num_ent, num_rel):
        '''get the total number of samples containing each entity or relation'''
        edge_index, edge_type = self.kg.snapshots[self.args.snapshot+1].edge_index, self.kg.snapshots[self.args.snapshot+1].edge_type
        other_weight = edge_index.size(1)
        ent_weight = scatter_add(src=torch.ones_like(edge_index[0]).unsqueeze(1), dim=0, index=edge_index[0], dim_size=num_ent)
        rel_weight = scatter_add(src=torch.ones_like(edge_index[0]).unsqueeze(1), dim=0, index=edge_type, dim_size=num_rel)
        return ent_weight + 1, rel_weight + 1, other_weight

class ConvLayer(nn.Module):
    def __init__(self, args, kg):
        super(ConvLayer, self).__init__()
        self.args = args
        self.kg = kg

    def forward(self, x, r, edge_index, edge_type, num_ent, num_rel, old_entity_weight, old_relation_weight, old_x, old_r):
        '''
        Reconstruct embeddings for all entities and relations
        :param x: input entity embeddings
        :param r: input relation embeddings
        :param edge_index: (s, o)
        :param edge_type: (r)
        :param num_ent: entity number
        :param num_rel: relation number
        :return: reconstructed embeddings
        '''
        '''avoid the reliance for learned facts'''

        if old_entity_weight == None: 

            edge_index, edge_type = self.add_loop_edge(edge_index, edge_type, num_ent, num_rel)

            r = torch.cat([r, torch.zeros(1, r.size(1)).to(self.args.device)], dim=0)

            neigh_t = torch.index_select(x, 0, edge_index[1])
            neigh_r = torch.index_select(r, 0, edge_type)
            neigh_h = torch.index_select(x, 0, edge_index[0])
            ent_embed = scatter_mean(src=neigh_h + neigh_r, dim=0, index=edge_index[1], dim_size=num_ent)
            rel_embed = scatter_mean(src=neigh_t - neigh_h, dim=0, index=edge_type, dim_size=num_rel + 1)
            ent_embed = torch.relu(ent_embed)
            return ent_embed, rel_embed[:-1]
        else:
            '''prepare old parameter and the number of |N(x)|'''
            if x.size(0) > old_entity_weight.size(0):
                old_entity_weight = torch.cat((old_entity_weight, torch.zeros(x.size(0) - old_entity_weight.size(0))), dim=0)
                old_x = torch.cat((old_x, torch.zeros(x.size(0) - old_entity_weight.size(0), x.size(1))), dim=0)
            if r.size(0) > old_relation_weight.size(0):
                old_relation_weight = torch.cat((old_relation_weight, torch.zeros(x.size(0) - old_relation_weight.size(0))),dim=0)
                old_r = torch.cat((old_r, torch.zeros(r.size(0) - old_relation_weight.size(0), r.size(1))), dim=0)

            '''add self-loop edges'''
            edge_index, edge_type = self.add_loop_edge(edge_index, edge_type, num_ent, num_rel)
            r = torch.cat([r, torch.zeros(1, r.size(1)).to(self.args.device)], dim=0)

            '''get neighbor embeddings'''
            neigh_t = torch.index_select(x, 0, edge_index[1])
            neigh_r = torch.index_select(r, 0, edge_type)
            neigh_h = torch.index_select(x, 0, edge_index[0])

            '''calculate entity embeddings'''
            ent_embed_new = scatter_add(src=neigh_h + neigh_r, dim=0, index=edge_index[1], dim_size=num_ent)
            ent_embed_old = old_entity_weight.unsqueeze(1) * old_x
            ent_embed = ent_embed_old + ent_embed_new
            ent_involving_num = old_entity_weight + scatter_add(src=torch.ones(edge_index.size(1)), index=edge_index[1], dim_size = num_ent)
            ent_embed = ent_embed/ent_involving_num
            ent_embed = torch.relu(ent_embed)

            '''calculate relation embeddings'''
            rel_embed_new = scatter_add(src=neigh_t + neigh_h, dim=0, index=edge_index[1], dim_size=num_rel)
            rel_embed_old = old_relation_weight.unsqueeze(1) * old_r
            rel_embed = rel_embed_old + rel_embed_new
            rel_involving_num = old_relation_weight + scatter_add(src=torch.ones(edge_type.size(0)), index=edge_type,
                                                                dim_size=num_rel)
            rel_embed = rel_embed / rel_involving_num

            return ent_embed, rel_embed[:-1]

    def add_loop_edge(self, edge_index, edge_type, num_ent, num_rel):
        '''add self-loop edge for entities'''
        u, v = torch.arange(0, num_ent).unsqueeze(0).to(self.args.device), torch.arange(0, num_ent).unsqueeze(0).to(self.args.device)
        r = torch.zeros(num_ent).to(self.args.device).long()
        loop_edge = torch.cat([u, v], dim=0)
        edge_index = torch.cat([edge_index, loop_edge], dim=-1)
        edge_type = torch.cat([edge_type, r+num_rel], dim=-1)
        return edge_index, edge_type



