# -*- coding: utf-8 -*-
"""Information Bottleneck-based alignment for semantic and structural KG facets.

The literal loop implementation is kept for mathematical regression tests.  The
training path vectorizes all relation classes into [N,C,2] tensors, eliminating
per-relation Python loops and per-relation ``cdist`` launches on Apple MPS.
"""
from __future__ import annotations

from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


# Literal IBMA-compatible reference primitives --------------------------------
def compute_cluster_scores(features, centroids, beta=1.0, normalize=True, eps=1e-12):
    if normalize:
        features = F.normalize(features, p=2, dim=1, eps=eps)
    score = -float(beta) * torch.cdist(features, centroids, p=2).square()
    return torch.softmax(score, dim=-1)


def estimate_q(scores_first, scores_second, eps=1e-9):
    denom = scores_second.sum(dim=0).clamp_min(eps)
    return (scores_first.transpose(0, 1) @ scores_second) / denom


def ib_upper_bound(input_scores, scores_first, scores_second, q, eps=1e-9):
    log_input = torch.log(input_scores.clamp_min(eps))
    log_q = torch.log(q.clamp_min(eps))
    term_1 = torch.einsum("ni,nj,nj->n", scores_first, input_scores, log_input)
    term_2 = torch.einsum("ni,nj,ij->n", scores_first, scores_second, log_q)
    return (term_1 - term_2).mean()


class IBUpperBoundLoss(nn.Module):
    """Loop-based multi-class reference implementation."""

    def __init__(self, beta=1.0, symmetric=True, reduction="mean", eps=1e-9):
        super().__init__()
        if reduction not in ("mean", "sum"):
            raise ValueError("reduction must be 'mean' or 'sum'")
        self.beta = float(beta)
        self.symmetric = bool(symmetric)
        self.reduction = reduction
        self.eps = float(eps)

    def per_class(self, features_a, features_b, input_scores_a_cls,
                  input_scores_b_cls, centroids_a_cls, centroids_b_cls):
        scores_a = compute_cluster_scores(features_a, centroids_a_cls, beta=self.beta)
        scores_b = compute_cluster_scores(features_b, centroids_b_cls, beta=self.beta)
        q_a = estimate_q(scores_a, scores_b, eps=self.eps)
        loss_a = ib_upper_bound(input_scores_a_cls, scores_a, scores_b, q_a, eps=self.eps)
        if not self.symmetric:
            return loss_a, None
        q_b = estimate_q(scores_b, scores_a, eps=self.eps)
        loss_b = ib_upper_bound(input_scores_b_cls, scores_b, scores_a, q_b, eps=self.eps)
        return loss_a, loss_b

    def forward(self, features_a, features_b, input_scores_a, input_scores_b,
                centroids_a, centroids_b):
        num_classes = int(centroids_a.shape[0])
        loss_a = features_a.new_zeros(())
        loss_b = features_a.new_zeros(())
        for cls in range(num_classes):
            la, lb = self.per_class(
                features_a, features_b,
                input_scores_a[:, cls], input_scores_b[:, cls],
                centroids_a[cls], centroids_b[cls],
            )
            loss_a = loss_a + la
            if lb is not None:
                loss_b = loss_b + lb
        if self.reduction == "mean" and num_classes > 0:
            loss_a = loss_a / num_classes
            loss_b = loss_b / num_classes
        return (loss_a, loss_b) if self.symmetric else loss_a


# MPS-friendly vectorized implementation --------------------------------------
def _batched_squared_distance(features, centroids, normalize_features, eps):
    """Squared distances [N,D] x [C,K,D] -> [N,C,K] using one GEMM."""
    if normalize_features:
        features = F.normalize(features, p=2, dim=-1, eps=eps)
    f2 = features.square().sum(dim=-1).view(-1, 1, 1)
    c2 = centroids.square().sum(dim=-1).unsqueeze(0)
    flat_centroids = centroids.reshape(-1, centroids.shape[-1])
    dot = (features @ flat_centroids.transpose(0, 1)).reshape(
        features.shape[0], centroids.shape[0], centroids.shape[1])
    return (f2 + c2 - 2.0 * dot).clamp_min_(0.0)


def compute_cluster_scores_batched(features, centroids, beta=1.0, normalize=True, eps=1e-12):
    return torch.softmax(
        -float(beta) * _batched_squared_distance(features, centroids, normalize, eps),
        dim=-1,
    )


def estimate_q_batched(scores_first, scores_second, eps=1e-9):
    joint = torch.bmm(
        scores_first.permute(1, 2, 0),
        scores_second.permute(1, 0, 2),
    )
    denom = scores_second.sum(dim=0).clamp_min(eps).unsqueeze(1)
    return joint / denom


def ib_upper_bound_batched(input_scores, scores_first, scores_second, q, eps=1e-9):
    """One bound per relation class, shape [C]."""
    log_input = torch.log(input_scores.clamp_min(eps))
    log_q = torch.log(q.clamp_min(eps))
    # i and j are independent in the literal IBMA expression.
    term_1 = scores_first.sum(dim=-1) * (input_scores * log_input).sum(dim=-1)
    expected_log_q = torch.matmul(
        scores_first.unsqueeze(-2), log_q.unsqueeze(0)
    ).squeeze(-2)
    term_2 = (scores_second * expected_log_q).sum(dim=-1)
    return (term_1 - term_2).mean(dim=0)


class VectorizedIBUpperBoundLoss(nn.Module):
    def __init__(self, beta=1.0, symmetric=True, reduction="mean", eps=1e-9):
        super().__init__()
        if reduction not in ("mean", "sum", "none"):
            raise ValueError("reduction must be mean, sum, or none")
        self.beta = float(beta)
        self.symmetric = bool(symmetric)
        self.reduction = reduction
        self.eps = float(eps)

    def _reduce(self, value):
        if self.reduction == "mean":
            return value.mean() if value.numel() else value.new_zeros(())
        if self.reduction == "sum":
            return value.sum()
        return value

    def forward(self, features_a, features_b, input_scores_a, input_scores_b,
                centroids_a, centroids_b):
        scores_a = compute_cluster_scores_batched(
            features_a, centroids_a, beta=self.beta, normalize=True, eps=self.eps)
        scores_b = compute_cluster_scores_batched(
            features_b, centroids_b, beta=self.beta, normalize=True, eps=self.eps)
        q_a = estimate_q_batched(scores_a, scores_b, eps=self.eps)
        loss_a = ib_upper_bound_batched(input_scores_a, scores_a, scores_b, q_a, eps=self.eps)
        if not self.symmetric:
            return self._reduce(loss_a)
        q_b = estimate_q_batched(scores_b, scores_a, eps=self.eps)
        loss_b = ib_upper_bound_batched(input_scores_b, scores_b, scores_a, q_b, eps=self.eps)
        return self._reduce(loss_a), self._reduce(loss_b)


# KG adapter and optional relation-level EMA centers --------------------------
def batch_centroids(features, labels, eps=1e-12, return_counts=False):
    labels = labels.to(features.dtype)
    pos = labels.transpose(0, 1)
    neg = (1.0 - labels).transpose(0, 1)
    cnt_pos = pos.sum(dim=1)
    cnt_neg = neg.sum(dim=1)
    centroids = (pos @ features) / cnt_pos.clamp_min(1.0).unsqueeze(1)
    anti_centroids = (neg @ features) / cnt_neg.clamp_min(1.0).unsqueeze(1)
    centroids = F.normalize(centroids, p=2, dim=1, eps=eps)
    anti_centroids = F.normalize(anti_centroids, p=2, dim=1, eps=eps)
    if return_counts:
        return centroids, anti_centroids, cnt_pos, cnt_neg
    return centroids, anti_centroids


class CrossFacetIB(nn.Module):
    """Symmetric semantic/structural IBB with valid-class filtering and EMA memory."""

    def __init__(self, beta=1.0, reduction="mean", eps=1e-9, min_pos=1,
                 min_neg=1, max_relations=0, centroid_mode="batch",
                 ema_momentum=0.95, num_relations=0, feature_dim=0):
        super().__init__()
        self.ib = VectorizedIBUpperBoundLoss(
            beta=beta, symmetric=True, reduction=reduction, eps=eps)
        self.beta = float(beta)
        self.eps = float(eps)
        self.min_pos = int(min_pos)
        self.min_neg = int(min_neg)
        self.max_relations = int(max_relations)
        self.centroid_mode = str(centroid_mode).lower()
        self.ema_momentum = float(ema_momentum)
        if self.centroid_mode not in ("batch", "ema"):
            raise ValueError("centroid_mode must be batch or ema")
        if self.centroid_mode == "ema" and (num_relations <= 0 or feature_dim <= 0):
            raise ValueError("EMA centroids require num_relations and feature_dim")
        bank_shape = ((int(num_relations), 2, int(feature_dim))
                      if num_relations > 0 and feature_dim > 0 else (0, 2, 0))
        self.register_buffer("centroid_a_bank", torch.zeros(bank_shape), persistent=True)
        self.register_buffer("centroid_b_bank", torch.zeros(bank_shape), persistent=True)
        self.register_buffer("centroid_seen", torch.zeros(int(num_relations), dtype=torch.bool), persistent=True)
        self.last_num_relations = 0

    @staticmethod
    def _stack(centroids, anti_centroids):
        return torch.stack((centroids, anti_centroids), dim=1)

    def _input_scores(self, feats, centroids_ck):
        return compute_cluster_scores_batched(
            feats, centroids_ck, beta=self.beta, normalize=False, eps=self.eps)

    def _select_valid(self, labels):
        pos = labels.sum(dim=0)
        neg = labels.shape[0] - pos
        valid = torch.nonzero(
            (pos >= self.min_pos) & (neg >= self.min_neg), as_tuple=False
        ).flatten()
        if self.max_relations > 0 and valid.numel() > self.max_relations:
            _, local = torch.topk(
                pos.index_select(0, valid), self.max_relations, largest=True, sorted=False)
            valid = valid.index_select(0, local)
            valid, _ = torch.sort(valid)
        return valid

    @torch.no_grad()
    def _update_ema(self, class_ids, batch_a, batch_b) -> Tuple[torch.Tensor, torch.Tensor]:
        class_ids = class_ids.long()
        seen = self.centroid_seen.index_select(0, class_ids)
        old_a = self.centroid_a_bank.index_select(0, class_ids)
        old_b = self.centroid_b_bank.index_select(0, class_ids)
        m = self.ema_momentum
        mixed_a = torch.where(seen.view(-1, 1, 1), m * old_a + (1.0 - m) * batch_a, batch_a)
        mixed_b = torch.where(seen.view(-1, 1, 1), m * old_b + (1.0 - m) * batch_b, batch_b)
        mixed_a = F.normalize(mixed_a, p=2, dim=-1, eps=self.eps)
        mixed_b = F.normalize(mixed_b, p=2, dim=-1, eps=self.eps)
        self.centroid_a_bank.index_copy_(0, class_ids, mixed_a)
        self.centroid_b_bank.index_copy_(0, class_ids, mixed_b)
        self.centroid_seen.index_fill_(0, class_ids, True)
        return mixed_a, mixed_b

    def forward(self, z_a, z_b, labels, class_ids: Optional[torch.Tensor] = None):
        if z_a.ndim != 2 or z_b.ndim != 2 or labels.ndim != 2:
            raise ValueError("expected z_a/z_b [N,D] and labels [N,C]")
        if z_a.shape != z_b.shape or labels.shape[0] != z_a.shape[0]:
            raise ValueError("facet and label shapes are inconsistent")
        if z_a.shape[0] < 2 or labels.shape[1] == 0:
            self.last_num_relations = 0
            return z_a.new_zeros(())
        labels = labels.to(dtype=z_a.dtype, device=z_a.device)
        valid = self._select_valid(labels)
        if valid.numel() == 0:
            self.last_num_relations = 0
            return z_a.new_zeros(())
        labels = labels.index_select(1, valid)
        if class_ids is not None:
            class_ids = class_ids.to(device=z_a.device, dtype=torch.long).index_select(0, valid)

        c_a, anti_a = batch_centroids(z_a.detach(), labels, eps=self.eps)
        c_b, anti_b = batch_centroids(z_b.detach(), labels, eps=self.eps)
        centers_a = self._stack(c_a, anti_a)
        centers_b = self._stack(c_b, anti_b)
        if self.centroid_mode == "ema" and class_ids is not None:
            if class_ids.numel() and int(class_ids.max().item()) >= self.centroid_seen.numel():
                raise IndexError("relation id exceeds EMA centroid bank")
            centers_a, centers_b = self._update_ema(class_ids, centers_a, centers_b)
        else:
            centers_a, centers_b = centers_a.detach(), centers_b.detach()

        input_a = self._input_scores(z_a, centers_a)
        input_b = self._input_scores(z_b, centers_b)
        loss_a, loss_b = self.ib(z_a, z_b, input_a, input_b, centers_a, centers_b)
        self.last_num_relations = int(labels.shape[1])
        return loss_a + loss_b


class CLUBLoss(nn.Module):
    """Experimental CLUB compatibility path."""

    def __init__(self, x_dim, y_dim, hidden_dim=None):
        super().__init__()
        hidden = hidden_dim or max(x_dim, y_dim)
        self.mu_net = nn.Sequential(nn.Linear(x_dim, hidden), nn.ReLU(), nn.Linear(hidden, y_dim))
        self.logvar_net = nn.Sequential(
            nn.Linear(x_dim, hidden), nn.ReLU(), nn.Linear(hidden, y_dim), nn.Tanh())

    def _q_params(self, x):
        return self.mu_net(x), self.logvar_net(x)

    @staticmethod
    def _log_gauss(y, mu, logvar):
        return -0.5 * (logvar + (y - mu).square() * (-logvar).exp())

    def forward(self, x, y):
        mu, logvar = self._q_params(x)
        positive = self._log_gauss(y, mu, logvar).sum(-1)
        diff = y.unsqueeze(0) - mu.unsqueeze(1)
        lv = logvar.unsqueeze(1)
        negative = (-0.5 * (lv + diff.square() * (-lv).exp())).sum(-1).mean(-1)
        return (positive - negative).mean()

    def learning_loss(self, x, y):
        mu, logvar = self._q_params(x)
        return -self._log_gauss(y, mu, logvar).sum(-1).mean()
