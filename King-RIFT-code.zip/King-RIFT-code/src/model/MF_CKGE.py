# -*- coding: utf-8 -*-
"""MF-CKGE with MPS-friendly Information-Bottleneck multimodal alignment."""
from .BaseModel import *
from .quantum import overlap_measure as _q_overlap_measure
from .ib_align import CrossFacetIB, CLUBLoss


def _enabled(value):
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def _quantum_overlap(args, cos):
    """Optional quantum-state interpretation of cosine overlap."""
    return _q_overlap_measure(
        cos,
        mode=getattr(args, "quantum_sim_mode", "hadamard"),
        shots=int(getattr(args, "quantum_sim_shots", 0) or 0),
    )


class MF_CKGE(BaseModel):
    def __init__(self, args, kg):
        super().__init__(args, kg)
        self.mse_loss_func = nn.MSELoss(reduction="sum")
        self.ent_weight, self.rel_weight, self.other_weight = None, None, None
        self.margin_loss_func = nn.MarginRankingLoss(
            float(self.args.margin), reduction="sum"
        ).to(self.args.device)

        # Continual relation consolidation.  MF-CKGE owns a new entity matrix for
        # every snapshot, so only the shared relation table is consolidated here.
        self.init_old_weight()

        self._ib_align_weight = float(getattr(args, "ib_align_weight", 0.0) or 0.0)
        self._ib_mode = str(getattr(args, "ib_mode", "ibb")).lower()
        self.ib_align = None
        self.ib_club = None
        if self._ib_align_weight > 0.0:
            if self._ib_mode == "club":
                self.ib_club = CLUBLoss(args.emb_dim, args.emb_dim).to(args.device)
            else:
                final_num_rel = int(kg.snapshots[int(args.snapshot_num) - 1].num_rel)
                self.ib_align = CrossFacetIB(
                    beta=float(getattr(args, "ib_beta", 1.0)),
                    eps=float(getattr(args, "ib_eps", 1e-6)),
                    min_pos=int(getattr(args, "ib_min_pos", 1)),
                    min_neg=int(getattr(args, "ib_min_neg", 1)),
                    max_relations=int(getattr(args, "ib_max_relations", 0)),
                    centroid_mode=str(getattr(args, "ib_centroid_mode", "batch")),
                    ema_momentum=float(getattr(args, "ib_ema_momentum", 0.95)),
                    num_relations=final_num_rel,
                    feature_dim=int(args.emb_dim),
                ).to(args.device)
        self._last_loss_components = {}

    def _set_buffer(self, name, value):
        value = value.detach()
        if name in self._buffers:
            self._buffers[name] = value
        else:
            self.register_buffer(name, value)

    def init_old_weight(self):
        rel = self.rel_embeddings.detach()
        self.register_buffer(
            "old_data_rel_embeddings", rel.new_empty((0, rel.shape[1]))
        )
        self.register_buffer(
            "old_weight_rel_embeddings", rel.new_empty((0, 1))
        )
        self.register_buffer(
            "new_weight_rel_embeddings_weight", rel.new_empty((0, 1))
        )
        self.register_buffer(
            "new_weight_ent_embeddings_weight", rel.new_empty((0, 1))
        )
        self.new_weight_other_weight = 0

    def _weights_for_snapshot(self, snapshot_id):
        snapshot = self.kg.snapshots[int(snapshot_id)]
        edge_index, edge_type = snapshot.edge_index, snapshot.edge_type
        dtype = self.rel_embeddings.dtype
        device = self.rel_embeddings.device
        edge_index = edge_index.to(device=device)
        edge_type = edge_type.to(device=device)
        ones = torch.ones(edge_type.numel(), 1, dtype=dtype, device=device)
        rel_weight = scatter_add(
            ones, dim=0, index=edge_type, dim_size=int(snapshot.num_rel)
        )
        ent_weight = scatter_add(
            ones, dim=0, index=edge_index[1], dim_size=int(snapshot.num_ent)
        )
        return ent_weight + 1.0, rel_weight + 1.0, int(edge_type.numel())

    @torch.no_grad()
    def store_old_parameters(self):
        """Store the current relation table and cumulative observation counts."""
        _, current_weight, _ = self._weights_for_snapshot(self.args.snapshot)
        previous = self.old_weight_rel_embeddings
        if previous.numel() == 0:
            previous = torch.zeros_like(current_weight)
        elif previous.shape[0] < current_weight.shape[0]:
            previous = torch.cat(
                [
                    previous,
                    previous.new_zeros((current_weight.shape[0] - previous.shape[0], 1)),
                ],
                dim=0,
            )
        else:
            previous = previous[: current_weight.shape[0]]
        self._set_buffer("old_data_rel_embeddings", self.rel_embeddings.detach().clone())
        self._set_buffer("old_weight_rel_embeddings", previous + current_weight)

    @torch.no_grad()
    def switch_snapshot(self):
        """Expand shared relations and initialize newly introduced relations by GCN."""
        self.store_old_parameters()
        old_num_rel = int(self.kg.snapshots[self.args.snapshot].num_rel)
        new_rel_embeddings = self.expand_rel_embedding_size().detach()
        new_rel_embeddings[:old_num_rel].copy_(self.rel_embeddings.detach())
        reconstructed = self.reconstruct_rel(new_rel_embeddings)
        if reconstructed.shape[0] > old_num_rel:
            new_rel_embeddings[old_num_rel:].copy_(reconstructed[old_num_rel:])
        self.rel_embeddings = nn.Parameter(new_rel_embeddings)

        ent_weight, rel_weight, other_weight = self._weights_for_snapshot(
            int(self.args.snapshot) + 1
        )
        self._set_buffer("new_weight_ent_embeddings_weight", ent_weight)
        self._set_buffer("new_weight_rel_embeddings_weight", rel_weight)
        self.new_weight_other_weight = other_weight

    @torch.no_grad()
    def reconstruct_rel(self, new_rel_embeddings):
        next_id = int(self.args.snapshot) + 1
        snapshot = self.kg.snapshots[next_id]
        old_ent_embeddings, _ = self.embedding("switch")
        new_ent_embeddings = self.expand_ent_embedding_size()
        old_num_ent = int(self.kg.snapshots[self.args.snapshot].num_ent)
        new_ent_embeddings[:old_num_ent].copy_(old_ent_embeddings[:old_num_ent])
        _, reconstructed_rel = self.gcn(
            new_ent_embeddings,
            new_rel_embeddings,
            snapshot.edge_index,
            snapshot.edge_type,
            int(snapshot.num_ent),
            int(snapshot.num_rel),
            None,
            None,
            None,
            None,
        )
        return reconstructed_rel

    @torch.no_grad()
    def store_gcn_embedding(self):
        snapshot = self.kg.snapshots[self.args.snapshot]
        ent_embeddings, rel_embeddings = self.embedding("Train")
        gcn_ent_embeddings, _ = self.gcn(
            ent_embeddings,
            rel_embeddings,
            snapshot.edge_index,
            snapshot.edge_type,
            int(snapshot.num_ent),
            int(snapshot.num_rel),
            None,
            None,
            None,
            None,
        )
        self._set_buffer(
            "gcn_ent_{}_embeddings".format(self.args.snapshot),
            gcn_ent_embeddings.clone(),
        )

    def parameter_cut(self):
        """Original optional parameter-cut path, made device/dtype safe."""
        with torch.no_grad():
            num_ent = self.kg.snapshots[self.args.snapshot - 1].num_ent
            temp_num_ent = self.kg.snapshots[0].num_ent
            current = getattr(
                self, "gcn_ent_{}_embeddings".format(self.args.snapshot)
            ).clone()
            norm_b = torch.linalg.vector_norm(current[:num_ent], ord=2, dim=1)
            norm_b = norm_b.clamp_min(torch.finfo(current.dtype).eps)

            first = getattr(self, "gcn_ent_0_embeddings")
            dot = (current[:temp_num_ent] * first).sum(dim=1)
            norm_a = torch.linalg.vector_norm(first, ord=2, dim=1).clamp_min(
                torch.finfo(current.dtype).eps
            )
            cosine = dot / (norm_a * norm_b[:temp_num_ent])
            if getattr(self.args, "quantum_cut", "False") == "True":
                cosine = _quantum_overlap(self.args, cosine)
            all_cosine = torch.cat(
                [cosine.unsqueeze(1), current.new_zeros((num_ent - temp_num_ent, 1))],
                dim=0,
            )

            for index in range(1, self.args.snapshot):
                previous = getattr(self, "gcn_ent_{}_embeddings".format(index)).clone()
                keep = torch.zeros(previous.shape[0], dtype=torch.bool, device=previous.device)
                keep[torch.as_tensor(self.valid_vectors[index], device=previous.device)] = True
                previous[~keep] = 0
                temp_num_ent = self.kg.snapshots[index].num_ent
                dot = (current[:temp_num_ent] * previous).sum(dim=1)
                norm_a = torch.linalg.vector_norm(previous, ord=2, dim=1).clamp_min(
                    torch.finfo(current.dtype).eps
                )
                cosine = dot / (norm_a * norm_b[:temp_num_ent])
                if getattr(self.args, "quantum_cut", "False") == "True":
                    cosine = _quantum_overlap(self.args, cosine)
                column = torch.cat(
                    [
                        cosine.unsqueeze(1),
                        current.new_zeros((num_ent - temp_num_ent, 1)),
                    ],
                    dim=0,
                )
                all_cosine = torch.cat((all_cosine, column), dim=1)

            value, max_indices = all_cosine.max(dim=1)
            threshold = float(self.args.threshold)
            valid_vectors = torch.nonzero(value < threshold, as_tuple=False).flatten().tolist()
            unvalid_vectors = torch.nonzero(value >= threshold, as_tuple=False).flatten().tolist()
            unvalid_to_old_index = max_indices[torch.as_tensor(
                unvalid_vectors, device=max_indices.device, dtype=torch.long
            )].tolist() if unvalid_vectors else []
            additional = list(
                range(num_ent, self.kg.snapshots[self.args.snapshot].num_ent)
            )
            self.valid_vectors.append(valid_vectors + additional)
            self.unvalid_vectors.append(unvalid_vectors)
            self.unvalid_to_oldIndex.append(unvalid_to_old_index)
            self.expand_ent_embeddings = nn.Parameter(
                self.expand_ent_embeddings[self.valid_vectors[self.args.snapshot]]
            )

    def reconstruct(self):
        """Reconstruct the currently trained snapshot (used by diagnostics)."""
        snapshot = self.kg.snapshots[self.args.snapshot]
        ent_embeddings, rel_embeddings = self.embedding("Train")
        return self.gcn(
            ent_embeddings,
            rel_embeddings,
            snapshot.edge_index,
            snapshot.edge_type,
            int(snapshot.num_ent),
            int(snapshot.num_rel),
            None,
            None,
            None,
            None,
        )

    def get_new_weight(self):
        ent_weight, rel_weight, other_weight = self._weights_for_snapshot(
            self.args.snapshot
        )
        weight = {}
        for name, _ in self.named_parameters():
            name = name.replace(".", "_")
            if "ent_embeddings" in name:
                weight[name] = ent_weight
            elif "rel_embeddings" in name:
                weight[name] = rel_weight
            else:
                weight[name] = other_weight
        return weight

    def new_loss(self, head, rel, tail=None, label=None):
        # BaseModel already implements the selected normalization.  Do not divide
        # by the flattened positive+negative batch a second time.
        return self.margin_loss(head, rel, tail, label)

    def inverse_relation_loss(self):
        """TransE requires each generated inverse relation to approximate -r."""
        pair_count = self.rel_embeddings.shape[0] // 2
        if pair_count == 0:
            return self.rel_embeddings.new_zeros(())
        forward = self.rel_embeddings[: 2 * pair_count : 2]
        inverse = self.rel_embeddings[1 : 2 * pair_count : 2]
        return (forward + inverse).square().mean()

    def relation_unify_loss(self):
        if int(self.args.snapshot) == 0 or self.old_data_rel_embeddings.numel() == 0:
            return self.rel_embeddings.new_zeros(())
        n = min(
            self.rel_embeddings.shape[0],
            self.old_data_rel_embeddings.shape[0],
            self.old_weight_rel_embeddings.shape[0],
            self.new_weight_rel_embeddings_weight.shape[0],
        )
        if n <= 0:
            return self.rel_embeddings.new_zeros(())
        current = self.rel_embeddings[:n]
        old_data = self.old_data_rel_embeddings[:n].to(current)
        old_weight = self.old_weight_rel_embeddings[:n].to(current)
        new_weight = self.new_weight_rel_embeddings_weight[:n].to(current)
        retention = old_weight / (old_weight + new_weight).clamp_min(1.0)
        return ((current - old_data) * retention).square().sum()


class TransE(MF_CKGE):
    def __init__(self, args, kg):
        super().__init__(args, kg)
        self.gcn = MAE(args, kg)

    def _facet_reconstruct(self):
        """Return semantic and structural facets with one full-graph GCN pass."""
        snapshot = self.kg.snapshots[self.args.snapshot]
        raw_ent, raw_rel = self.embedding("Train")
        gcn_ent, gcn_rel = self.gcn(
            raw_ent,
            raw_rel,
            snapshot.edge_index,
            snapshot.edge_type,
            int(snapshot.num_ent),
            int(snapshot.num_rel),
            None,
            None,
            None,
            None,
        )
        return raw_ent, raw_rel, gcn_ent, gcn_rel

    def MAE_loss(self, facets=None):
        snapshot = self.kg.snapshots[self.args.snapshot]
        if facets is None:
            facets = self._facet_reconstruct()
        raw_ent, raw_rel, gcn_ent, gcn_rel = facets
        num_ent, num_rel = int(snapshot.num_ent), int(snapshot.num_rel)
        entity_loss = self.mse_loss_func(gcn_ent, raw_ent[:num_ent]) / max(num_ent, 1)
        relation_loss = self.mse_loss_func(gcn_rel, raw_rel[:num_rel]) / max(num_rel, 1)
        return entity_loss + relation_loss

    def ib_align_loss(self, head, rel, tail, label, facets):
        """Relation-conditioned IBB using positive triples only.

        Corrupted entities are deliberately excluded: they are ranking negatives,
        not evidence that an entity participates in a relation class.
        """
        raw_ent, _, gcn_ent, _ = facets
        positive = label > 0
        if not bool(positive.any()):
            return raw_ent.new_zeros(())
        ph, pr, pt = head[positive], rel[positive], tail[positive]
        num_positive = ph.numel()
        entity_ids, entity_inverse = torch.unique(
            torch.cat((ph, pt)), sorted=True, return_inverse=True
        )
        relation_ids, relation_inverse = torch.unique(
            pr, sorted=True, return_inverse=True
        )
        if entity_ids.numel() < 2 or relation_ids.numel() == 0:
            return raw_ent.new_zeros(())

        z_semantic = raw_ent.index_select(0, entity_ids)
        z_structural = gcn_ent.index_select(0, entity_ids)
        if self._ib_mode == "club" and self.ib_club is not None:
            return self.ib_club(z_semantic, z_structural.detach())

        relation_labels = raw_ent.new_zeros(
            (entity_ids.numel(), relation_ids.numel())
        )
        row_h = entity_inverse[:num_positive]
        row_t = entity_inverse[num_positive:]
        relation_labels[row_h, relation_inverse] = 1.0
        relation_labels[row_t, relation_inverse] = 1.0
        return self.ib_align(
            z_semantic,
            z_structural,
            relation_labels,
            class_ids=relation_ids,
        )

    def scheduled_ib_weight(self):
        base = self._ib_align_weight
        if base <= 0.0:
            return 0.0
        epoch = int(getattr(self.args, "epoch", 0))
        warmup = int(getattr(self.args, "ib_warmup_epochs", 0))
        ramp = int(getattr(self.args, "ib_ramp_epochs", 0))
        if epoch < warmup:
            return 0.0
        if ramp <= 0:
            return base
        progress = min(1.0, float(epoch - warmup + 1) / float(ramp))
        return base * progress

    def regularizer_due(self):
        every = max(int(getattr(self.args, "regularizer_every", 1)), 1)
        step = int(getattr(self.args, "train_step", 0))
        return step % every == 0

    def _regularizer_scale(self):
        every = max(int(getattr(self.args, "regularizer_every", 1)), 1)
        return float(every) if _enabled(getattr(self.args, "regularizer_rescale", "True")) else 1.0

    def loss(self, head, rel, tail=None, label=None):
        task_raw = self.new_loss(head, rel, tail, label)
        total = task_raw
        components = {"task_raw": task_raw.detach()}

        need_graph = self.regularizer_due() and (
            _enabled(getattr(self.args, "using_reconstruct_loss", "True"))
            or float(getattr(self.args, "struct_task_weight", 0.0)) > 0.0
            or float(getattr(self.args, "fused_task_weight", 0.0)) > 0.0
            or self.scheduled_ib_weight() > 0.0
        )
        if need_graph:
            facets = self._facet_reconstruct()
            raw_ent, raw_rel, gcn_ent, gcn_rel = facets
            scale = self._regularizer_scale()

            if _enabled(getattr(self.args, "using_reconstruct_loss", "True")):
                mae = self.MAE_loss(facets)
                total = total + scale * float(self.args.reconstruct_weight) * mae
                components["mae"] = mae.detach()

            struct_weight = float(getattr(self.args, "struct_task_weight", 0.0))
            if struct_weight > 0.0:
                task_struct = self.margin_loss_with_embeddings(
                    head, rel, tail, label, gcn_ent, gcn_rel
                )
                total = total + scale * struct_weight * task_struct
                components["task_struct"] = task_struct.detach()

            fused_weight = float(getattr(self.args, "fused_task_weight", 0.0))
            if fused_weight > 0.0:
                alpha = float(getattr(self.args, "fusion_alpha", 0.5))
                fused_ent = alpha * raw_ent[:gcn_ent.shape[0]] + (1.0 - alpha) * gcn_ent
                fused_rel = alpha * raw_rel[:gcn_rel.shape[0]] + (1.0 - alpha) * gcn_rel
                task_fused = self.margin_loss_with_embeddings(
                    head, rel, tail, label, fused_ent, fused_rel
                )
                total = total + scale * fused_weight * task_fused
                components["task_fused"] = task_fused.detach()

            ib_weight = self.scheduled_ib_weight()
            if ib_weight > 0.0:
                ib_loss = self.ib_align_loss(head, rel, tail, label, facets)
                total = total + scale * ib_weight * ib_loss
                components["ib"] = ib_loss.detach()
                components["ib_weight"] = total.new_tensor(ib_weight)

        inverse_weight = float(getattr(self.args, "inverse_relation_weight", 0.0))
        if inverse_weight > 0.0:
            inverse_loss = self.inverse_relation_loss()
            total = total + inverse_weight * inverse_loss
            components["inverse_relation"] = inverse_loss.detach()

        if _enabled(getattr(self.args, "relation_unify_loss", "True")):
            unify = self.relation_unify_loss()
            total = total + float(self.args.unify_weight) * unify
            components["unify"] = unify.detach()

        self._last_loss_components = components
        return total

    def get_weight(self):
        return self._weights_for_snapshot(int(self.args.snapshot) + 1)


class MAE(nn.Module):
    def __init__(self, args, kg):
        super().__init__()
        self.args = args
        self.kg = kg
        self.conv_layers = nn.ModuleList(
            [ConvLayer(args, kg) for _ in range(int(args.num_layer))]
        )

    def forward(
        self,
        ent_embeddings,
        rel_embeddings,
        edge_index,
        edge_type,
        num_ent,
        num_rel,
        old_entity_weight=None,
        old_relation_weight=None,
        old_x=None,
        old_r=None,
    ):
        x, r = ent_embeddings, rel_embeddings
        for layer in self.conv_layers:
            x, r = layer(
                x,
                r,
                edge_index,
                edge_type,
                num_ent,
                num_rel,
                old_entity_weight,
                old_relation_weight,
                old_x,
                old_r,
            )
        return x, r

    def get_weight(self, num_ent, num_rel):
        snapshot = self.kg.snapshots[int(self.args.snapshot) + 1]
        edge_index, edge_type = snapshot.edge_index, snapshot.edge_type
        dtype = torch.get_default_dtype()
        ones = torch.ones(edge_type.numel(), 1, dtype=dtype, device=edge_type.device)
        ent_weight = scatter_add(
            ones, dim=0, index=edge_index[1], dim_size=int(num_ent)
        )
        rel_weight = scatter_add(
            ones, dim=0, index=edge_type, dim_size=int(num_rel)
        )
        return ent_weight + 1.0, rel_weight + 1.0, int(edge_type.numel())


class ConvLayer(nn.Module):
    def __init__(self, args, kg):
        super().__init__()
        self.args = args
        self.kg = kg
        # Full-graph topology is immutable within a snapshot.  Cache the
        # device-converted, self-loop-augmented tensors so every regularizer
        # step does not rebuild and concatenate O(E + V) integer tensors.
        self._cached_edge_key = None
        self._cached_edge_index = None
        self._cached_edge_type = None

    @staticmethod
    def _pad_weight(weight, size, reference):
        if weight is None or weight.numel() == 0:
            return reference.new_zeros(size)
        weight = weight.to(device=reference.device, dtype=reference.dtype).reshape(-1)
        if weight.shape[0] < size:
            weight = torch.cat((weight, weight.new_zeros(size - weight.shape[0])))
        return weight[:size]

    @staticmethod
    def _pad_data(data, size, dim, reference):
        if data is None or data.numel() == 0:
            return reference.new_zeros((size, dim))
        data = data.to(device=reference.device, dtype=reference.dtype)
        if data.shape[0] < size:
            data = torch.cat(
                (data, data.new_zeros((size - data.shape[0], dim))), dim=0
            )
        return data[:size]

    def forward(
        self,
        x,
        r,
        edge_index,
        edge_type,
        num_ent,
        num_rel,
        old_entity_weight=None,
        old_relation_weight=None,
        old_x=None,
        old_r=None,
    ):
        num_ent, num_rel = int(num_ent), int(num_rel)
        edge_key = (id(edge_index), id(edge_type), str(x.device), num_ent, num_rel)
        if edge_key != self._cached_edge_key:
            base_edge_index = edge_index.to(device=x.device, dtype=torch.long)
            base_edge_type = edge_type.to(device=x.device, dtype=torch.long)
            cached_index, cached_type = self.add_loop_edge(
                base_edge_index, base_edge_type, num_ent, num_rel
            )
            self._cached_edge_key = edge_key
            self._cached_edge_index = cached_index
            self._cached_edge_type = cached_type
        edge_index = self._cached_edge_index
        edge_type = self._cached_edge_type
        relation_with_loop = torch.cat((r[:num_rel], r.new_zeros((1, r.shape[1]))), dim=0)

        heads = x.index_select(0, edge_index[0])
        tails = x.index_select(0, edge_index[1])
        relations = relation_with_loop.index_select(0, edge_type)
        ones = x.new_ones(edge_type.numel())

        entity_sum_new = scatter_add(
            heads + relations, dim=0, index=edge_index[1], dim_size=num_ent
        )
        entity_count_new = scatter_add(
            ones, dim=0, index=edge_index[1], dim_size=num_ent
        )
        entity_weight_old = self._pad_weight(old_entity_weight, num_ent, x)
        entity_data_old = self._pad_data(old_x, num_ent, x.shape[1], x)
        entity_denominator = (entity_count_new + entity_weight_old).clamp_min(1.0)
        entity_aggregate = (
            entity_sum_new + entity_weight_old.unsqueeze(1) * entity_data_old
        ) / entity_denominator.unsqueeze(1)
        residual = float(getattr(self.args, "gcn_residual", 0.0))
        if residual > 0.0:
            entity_activated = torch.nn.functional.leaky_relu(
                entity_aggregate, negative_slope=0.1
            )
            entity_out = residual * x[:num_ent] + (1.0 - residual) * entity_activated
        else:
            entity_out = torch.relu(entity_aggregate)

        # Relation messages are indexed by relation type, not by target entity.
        # TransE composition requires tail - head (the old branch used tail + head).
        relation_sum_new = scatter_add(
            tails - heads, dim=0, index=edge_type, dim_size=num_rel + 1
        )
        relation_count_new = scatter_add(
            ones, dim=0, index=edge_type, dim_size=num_rel + 1
        )
        relation_weight_old = self._pad_weight(old_relation_weight, num_rel, r)
        relation_data_old = self._pad_data(old_r, num_rel, r.shape[1], r)
        relation_weight_old = torch.cat((relation_weight_old, r.new_zeros(1)))
        relation_data_old = torch.cat(
            (relation_data_old, r.new_zeros((1, r.shape[1]))), dim=0
        )
        relation_denominator = (relation_count_new + relation_weight_old).clamp_min(1.0)
        relation_out = (
            relation_sum_new + relation_weight_old.unsqueeze(1) * relation_data_old
        ) / relation_denominator.unsqueeze(1)
        relation_out = relation_out[:num_rel]
        if residual > 0.0:
            relation_out = residual * r[:num_rel] + (1.0 - residual) * relation_out
        return entity_out, relation_out

    @staticmethod
    def add_loop_edge(edge_index, edge_type, num_ent, num_rel):
        entity_ids = torch.arange(num_ent, device=edge_index.device, dtype=torch.long)
        loop_edge = torch.stack((entity_ids, entity_ids), dim=0)
        loop_type = torch.full(
            (num_ent,), num_rel, device=edge_type.device, dtype=torch.long
        )
        return (
            torch.cat((edge_index, loop_edge), dim=1),
            torch.cat((edge_type, loop_type), dim=0),
        )
