# -*- coding: utf-8 -*-
"""量子启发的相似度原语与变分量子线路头(经典模拟实现) —— MF-CKGE 量子路线。

本模块为 MF-CKGE 提供"量子流程实现",但全部跑在经典硬件上(quantum-inspired),
与本仓库其它模型(CQEA / structure_free_q)的量子头同源同构。设计上分两层:

================================ 第一层:保真的量子测量重述(已接线,opt-in) ================================
把每个 L2 归一后的嵌入 x ∈ R^D 解释为 q = ⌈log2 D⌉ 比特上的**振幅编码纯态** |ψ⟩
(D ≤ 2^q,零填充不改变内积与范数,故归一向量本身就是合法态)。两个态的相似度即态重叠,
对应三种量子测量协议(估计器):

    mode='hadamard' : Re⟨a|b⟩ = cos(a,b)        —— Hadamard test 量;**与经典余弦逐元素相等**
    mode='swap'     : |⟨a|b⟩|² = cos(a,b)²       —— swap test 量(量子保真度)
    mode='shots'    : 有限采样估计 |⟨a|b⟩|²        —— 诚实反映 NISQ 采样噪声(swap test)

两个**诚实点**(也是本路线"不破坏既有结果"的根本):
  (i) 'hadamard' 是经典余弦的**无损量子重述**:把原代码里的 cos 解释为 Hadamard-test 观测量,
      数值完全不变。因此默认开关下(或 mode=hadamard)所有原实验逐位复现。
 (ii) 对所有态施加**同一个固定幺正 U** 不改变重叠:⟨a|U†U|b⟩ = ⟨a|b⟩(幺正不变性)。
      → 一个**未训练/共享**的变分线路对"基于相对相似度"的打分是 no-op。量子线路要产生增益,
        必须 (a) 用对比目标**训练**它,或 (b) 后接**非幺正测量读出**——这两者落在第二层。

接线位置(均 opt-in,默认关闭,关闭时与原版逐位一致):
  - `MF_CKGE.parameter_cut` 的整合相似度(snapshot 间冗余判定)。
  - `BaseModel.predict` 的多面注意力(关系画像 ↔ 查询关系)。

================================ 第二层:可训练变分量子头 + 混合读出(库,供进阶实验) ================================
完整状态向量模拟器(双实通道,规避复数支持不全):振幅/角度编码 + 交替(单比特 RZ·RY[·RX] 旋转
| CNOT 环形纠缠)+ 混合量子-经典读出 + 误差缓解(去极化 + ZNE)+ 贫瘠高原/有效维度诊断。
这一层提供"学到的额外视图"(QLGAN 式后期融合的量子增益位点),但**不在默认打分路径上**:
它会改变数值且需训练编排,故仅作为库导出,由使用者显式接入。

约定:复态以 (re, im):[N, 2^q] 表示,已归一 ⟨ψ|ψ⟩=1;全程支持 float32/float64
(MF-CKGE 的嵌入为 double,本模块对输入 dtype/device 透明)。
"""
from __future__ import annotations
import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


# ============================================================
# 第一层 · 态重叠测量原语(已接线)
# ============================================================
def overlap_measure(cos: torch.Tensor, mode: str = "hadamard",
                    shots: int = 0, generator: torch.Generator = None) -> torch.Tensor:
    """把已算好的余弦张量重新解释为**态重叠测量**,返回同形状结果。

    这是第一层的核心:任何 cos = ⟨â|b̂⟩ ∈ [-1,1] 都可视为对振幅编码态做某种量子测量的观测量。

    mode='hadamard': 返回 cos(Hadamard-test 的 Re⟨a|b⟩);与经典余弦逐元素相等 → 无损重述。
    mode='swap'    : 返回 cos²(swap-test 的 |⟨a|b⟩|²,即量子保真度)∈ [0,1]。
    mode='shots'   : 以 shots 次 swap test 采样估计 |⟨a|b⟩|²;p0=(1+cos²)/2,
                     F̂ = 2·counts0/shots − 1(无偏,方差 ~ 1/shots)。shots<=0 时退化为解析 swap。
    """
    if mode == "hadamard":
        return cos
    f2 = cos * cos
    if mode == "swap":
        return f2
    if mode == "shots":
        if shots is None or int(shots) <= 0:
            return f2
        shots = int(shots)
        p0 = (0.5 * (1.0 + f2)).clamp(0.0, 1.0)
        # 二项采样(可微性不需要:仅用于整合/评测的相似度估计)。generator 可选,
        # 缺省走全局 RNG(已由 same_seeds 设种),兼容不支持 generator kwarg 的旧版 torch。
        total = torch.full_like(p0, float(shots))
        # Mac 适配:torch.binomial 未在 MPS 后端实现;MPS 设备上临时落到 CPU 采样
        # 再搬回(仅影响 opt-in 的 shots 路径,采样分布与语义不变)。
        if p0.device.type == 'mps':
            total_cpu, p0_cpu = total.cpu(), p0.cpu()
            if generator is None:
                counts0 = torch.binomial(total_cpu, p0_cpu).to(p0.device)
            else:
                counts0 = torch.binomial(total_cpu, p0_cpu, generator=generator).to(p0.device)
        elif generator is None:
            counts0 = torch.binomial(total, p0)
        else:
            counts0 = torch.binomial(total, p0, generator=generator)
        return (2.0 * counts0 / float(shots) - 1.0)
    raise ValueError(f"未知 quantum sim mode: {mode}(可选 hadamard|swap|shots)")


def cosine_to_state_overlap(a: torch.Tensor, b: torch.Tensor, dim: int = -1,
                            eps: float = 1e-12) -> torch.Tensor:
    """逐元素余弦 = 振幅编码态的 Re⟨a|b⟩。a,b 同形状,沿 `dim` 归一后做内积。

    用于 `parameter_cut` / `predict` 中"成对"余弦的量子重述(振幅编码 → Hadamard test)。
    """
    a_n = F.normalize(a, 2, dim, eps=eps)
    b_n = F.normalize(b, 2, dim, eps=eps)
    return (a_n * b_n).sum(dim)


def state_overlap(A: torch.Tensor, B: torch.Tensor, mode: str = "hadamard",
                  shots: int = 0, already_normalized: bool = False,
                  generator: torch.Generator = None) -> torch.Tensor:
    """振幅编码态的**交叉**重叠矩阵 [nA, nB]。A:[nA,D], B:[nB,D]。

    G = Â·B̂ᵀ = Re⟨a|b⟩ = cos;再按测量协议(`overlap_measure`)映射。
    mode='hadamard' 时与经典 `Â·B̂ᵀ` 逐元素相等(振幅编码下两图实体的余弦相似度矩阵)。
    """
    if not already_normalized:
        A = F.normalize(A, 2, -1)
        B = F.normalize(B, 2, -1)
    G = A @ B.t()
    return overlap_measure(G, mode=mode, shots=shots, generator=generator)


def amplitude_qubits(D: int) -> tuple:
    """振幅编码 D 维实特征所需比特数 q 与希尔伯特空间维度 2^q(D ≤ 2^q)。"""
    q = max(1, int(math.ceil(math.log2(max(2, D)))))
    return q, (1 << q)


# ============================================================
# 第二层 · 状态向量模拟器:单/双比特门(双实通道,dtype/device 透明)
# ============================================================
def _cnot_perm(q: int, control: int, target: int) -> torch.Tensor:
    """长度 2^q 的置换索引:对 control 位=1 的基态翻转 target 位。"""
    dim = 1 << q
    perm = torch.arange(dim)
    cbit, tbit = 1 << control, 1 << target
    for s in range(dim):
        if s & cbit:
            perm[s] = s ^ tbit
    return perm


def _apply_ry(re, im, k, q, alpha):
    """对 qubit k 施加 RY(alpha)。alpha 为标量或 [N]。re,im:[N,2^q]。"""
    N = re.shape[0]
    lo, hi = 1 << k, 1 << (q - 1 - k)
    re = re.view(N, hi, 2, lo)
    im = im.view(N, hi, 2, lo)
    half = alpha * 0.5
    if torch.is_tensor(half) and half.dim() == 1:
        c = torch.cos(half).view(N, 1, 1); s = torch.sin(half).view(N, 1, 1)
    else:
        c = torch.cos(half); s = torch.sin(half)
    r0, r1 = re[:, :, 0, :], re[:, :, 1, :]
    i0, i1 = im[:, :, 0, :], im[:, :, 1, :]
    re = torch.stack([c * r0 - s * r1, s * r0 + c * r1], dim=2).reshape(N, -1)
    im = torch.stack([c * i0 - s * i1, s * i0 + c * i1], dim=2).reshape(N, -1)
    return re, im


def _apply_rz(re, im, k, q, beta):
    """对 qubit k 施加 RZ(beta)=diag(e^{-iβ/2}, e^{+iβ/2})。"""
    N = re.shape[0]
    lo, hi = 1 << k, 1 << (q - 1 - k)
    re = re.view(N, hi, 2, lo)
    im = im.view(N, hi, 2, lo)
    half = beta * 0.5
    c, s = torch.cos(half), torch.sin(half)
    r0, i0 = re[:, :, 0, :], im[:, :, 0, :]
    r1, i1 = re[:, :, 1, :], im[:, :, 1, :]
    nr0, ni0 = r0 * c + i0 * s, -r0 * s + i0 * c
    nr1, ni1 = r1 * c - i1 * s, r1 * s + i1 * c
    re = torch.stack([nr0, nr1], dim=2).reshape(N, -1)
    im = torch.stack([ni0, ni1], dim=2).reshape(N, -1)
    return re, im


def _apply_rx(re, im, k, q, gamma):
    """对 qubit k 施加 RX(gamma)=[[cos,-i·sin],[-i·sin,cos]](γ/2)。

    补全硬件高效纠缠线路的 R_x 旋转,使单比特旋转覆盖完整 Bloch 球
    (RZ·RY·RX 可表示任意单比特幺正),提升 VQC 表达力。
    """
    N = re.shape[0]
    lo, hi = 1 << k, 1 << (q - 1 - k)
    re = re.view(N, hi, 2, lo)
    im = im.view(N, hi, 2, lo)
    half = gamma * 0.5
    c, s = torch.cos(half), torch.sin(half)
    r0, i0 = re[:, :, 0, :], im[:, :, 0, :]
    r1, i1 = re[:, :, 1, :], im[:, :, 1, :]
    nr0, ni0 = c * r0 + s * i1, c * i0 - s * r1
    nr1, ni1 = s * i0 + c * r1, -s * r0 + c * i1
    re = torch.stack([nr0, nr1], dim=2).reshape(N, -1)
    im = torch.stack([ni0, ni1], dim=2).reshape(N, -1)
    return re, im


def _single_qubit_marginals(re, im, q):
    """对每个量子比特 k 计算 ⟨Z_k⟩,⟨X_k⟩,⟨Y_k⟩。返回 [N, q, 3](顺序 z,x,y)。可微。"""
    N = re.shape[0]
    prob = re * re + im * im
    outs = []
    for k in range(q):
        lo, hi = 1 << k, 1 << (q - 1 - k)
        p = prob.view(N, hi, 2, lo)
        z = (p[:, :, 0, :] - p[:, :, 1, :]).reshape(N, -1).sum(1)
        rr, ii = re.view(N, hi, 2, lo), im.view(N, hi, 2, lo)
        r0, r1 = rr[:, :, 0, :], rr[:, :, 1, :]
        i0, i1 = ii[:, :, 0, :], ii[:, :, 1, :]
        cross_re = (r0 * r1 + i0 * i1).reshape(N, -1).sum(1)
        cross_im = (r0 * i1 - i0 * r1).reshape(N, -1).sum(1)
        outs.append(torch.stack([z, 2.0 * cross_re, 2.0 * cross_im], dim=1))
    return torch.stack(outs, dim=1)


# ============================================================
# 第二层 · 压缩 / 编码
# ============================================================
class LowRankCompress(nn.Module):
    """W=A·B 的低秩线性压缩,把 H:[N,d] 压到 (layers×q) 维角度(逐层数据再上传)。"""

    def __init__(self, in_dim: int, n_qubits: int, rank: int, layers: int = 1):
        super().__init__()
        out_dim = n_qubits * max(1, layers)
        rank = max(1, min(rank, in_dim, out_dim))
        self.A = nn.Linear(in_dim, rank, bias=False)
        self.B = nn.Linear(rank, out_dim, bias=True)
        self.n_qubits = n_qubits
        self.layers = max(1, layers)

    def forward(self, H: torch.Tensor) -> torch.Tensor:
        z = self.B(self.A(H))
        return math.pi * torch.tanh(z)          # 映射到 (-π, π] 作 RY 数据编码角


class AmplitudeCompress(nn.Module):
    """振幅编码用低秩压缩:输出 2^q 维复振幅(实/虚),L2 归一即合法纯态。"""

    def __init__(self, in_dim: int, n_qubits: int, rank: int):
        super().__init__()
        out_dim = 1 << n_qubits
        rank = max(1, min(rank, in_dim, out_dim))
        self.A = nn.Linear(in_dim, rank, bias=False)
        self.B_re = nn.Linear(rank, out_dim, bias=True)
        self.B_im = nn.Linear(rank, out_dim, bias=True)
        self.out_dim = out_dim

    def forward(self, H: torch.Tensor):
        z = self.A(H)
        re, im = self.B_re(z), self.B_im(z)
        norm = torch.sqrt((re ** 2 + im ** 2).sum(1, keepdim=True)).clamp_min(1e-12)
        return re / norm, im / norm


def amplitude_embed(H: torch.Tensor):
    """**无参**振幅编码:直接把 H:[N,d] 的 L2 归一向量写入复振幅的实部(虚部=0),
    必要时零填充到 2^q。这是第一层"忠实编码"的张量版(不引入可训练参数,不丢判别性)。
    返回 (re, im):[N, 2^q]。
    """
    N, d = H.shape
    q, dim = amplitude_qubits(d)
    Hn = F.normalize(H, 2, -1)
    if dim == d:
        re = Hn
    else:
        re = torch.zeros(N, dim, dtype=H.dtype, device=H.device)
        re[:, :d] = Hn
    return re, torch.zeros_like(re)


# ============================================================
# 第二层 · 变分量子线路
# ============================================================
class VariationalCircuit(nn.Module):
    """角度编码 + 交替(单比特旋转层 | CNOT 环形纠缠层)的变分量子线路(模拟)。

    init_state 给定 (re,im) 时以该复态为初态(振幅编码分支),否则从 |0...0> 出发(角度编码)。
    """

    def __init__(self, n_qubits: int, layers: int, full_rotation: bool = False):
        super().__init__()
        self.q = n_qubits
        self.L = layers
        self.full_rotation = full_rotation
        self.theta = nn.Parameter(0.1 * torch.randn(layers, n_qubits))      # RZ 角
        self.phi = nn.Parameter(0.1 * torch.randn(layers, n_qubits))        # RY 角
        # RX 角(full_rotation 时启用):RZ·RY·RX 覆盖完整单比特幺正,提升表达力
        self.lam = nn.Parameter(0.1 * torch.randn(layers, n_qubits)) if full_rotation else None
        perms = []
        for c in range(n_qubits):
            if n_qubits > 1:
                perms.append(_cnot_perm(n_qubits, c, (c + 1) % n_qubits))
        self.register_buffer("cnot_perms",
                             torch.stack(perms) if perms else torch.zeros(0, dtype=torch.long))

    def _shape_angles(self, enc_angles: torch.Tensor) -> torch.Tensor:
        N = enc_angles.shape[0]
        if enc_angles.dim() == 3:
            return enc_angles
        d = enc_angles.shape[1]
        if d == self.q:
            return enc_angles.view(N, 1, self.q).expand(N, self.L, self.q)
        if d == self.L * self.q:
            return enc_angles.view(N, self.L, self.q)
        raise ValueError(f"编码角维度 {d} 与 (q={self.q}, L={self.L}) 不匹配")

    def forward(self, enc_angles: torch.Tensor = None, init_state=None):
        dim = 1 << self.q
        if init_state is not None:
            re, im = init_state
            re, im = re.clone(), im.clone()
            ang = None
        else:
            ang = self._shape_angles(enc_angles)
            N = ang.shape[0]
            re = torch.zeros(N, dim, device=ang.device, dtype=ang.dtype)
            im = torch.zeros(N, dim, device=ang.device, dtype=ang.dtype)
            re[:, 0] = 1.0

        theta = self.theta.to(re.dtype)
        phi = self.phi.to(re.dtype)
        lam = self.lam.to(re.dtype) if self.lam is not None else None
        for l in range(self.L):
            if ang is not None:
                for k in range(self.q):
                    re, im = _apply_ry(re, im, k, self.q, ang[:, l, k])
            for k in range(self.q):
                re, im = _apply_rz(re, im, k, self.q, theta[l, k])
                re, im = _apply_ry(re, im, k, self.q, phi[l, k])
                if lam is not None:
                    re, im = _apply_rx(re, im, k, self.q, lam[l, k])
            if self.q > 1:
                for ci in range(self.cnot_perms.shape[0]):
                    perm = self.cnot_perms[ci]
                    re = re.index_select(1, perm)
                    im = im.index_select(1, perm)
        norm = torch.sqrt((re ** 2 + im ** 2).sum(1, keepdim=True)).clamp_min(1e-12)
        return re / norm, im / norm


# ============================================================
# 第二层 · 量子映射头(压缩 → 编码 → VQC → 读出;含经典消融 + 振幅 + 混合)
# ============================================================
class QuantumHilbertHead(nn.Module):
    """量子希尔伯特映射头(可训练,供"第二层"后期融合实验)。

    encoding ∈ {"amplitude","angle"}; hybrid_readout 启用混合量子-经典读出;
    local_cost 启用局部单比特保真度(避免贫瘠高原)。use_quantum=False 退化为经典低维投影。
    """

    def __init__(self, in_dim: int, n_qubits: int, layers: int, rank: int,
                 use_quantum: bool = True, encoding: str = "amplitude",
                 hybrid_readout: bool = True, local_cost: bool = True,
                 readout_dim: int = 64, full_rotation: bool = False):
        super().__init__()
        self.use_quantum = use_quantum
        self.q = n_qubits
        self.encoding = encoding
        self.hybrid_readout = hybrid_readout and use_quantum
        self.local_cost = local_cost
        self.out_dim = 1 << n_qubits

        if use_quantum:
            if encoding == "amplitude":
                self.amp = AmplitudeCompress(in_dim, n_qubits, rank)
            else:
                self.compress = LowRankCompress(in_dim, n_qubits, rank, layers=layers)
            self.circuit = VariationalCircuit(n_qubits, layers, full_rotation=full_rotation)
            if self.hybrid_readout:
                qfeat_dim = n_qubits * 3 + n_qubits        # ⟨Z/X/Y⟩ + 相邻 ZZ
                self.cls_proj = nn.Sequential(
                    nn.Linear(in_dim, readout_dim), nn.ReLU(),
                    nn.Linear(readout_dim, readout_dim))
                self.q_readout = nn.Sequential(
                    nn.Linear(qfeat_dim, readout_dim), nn.ReLU(),
                    nn.Linear(readout_dim, readout_dim))
                self.fuse_gate = nn.Parameter(torch.tensor(0.0))
        else:
            self.proj = nn.Sequential(
                nn.Linear(in_dim, 2 * (1 << n_qubits)), nn.ReLU(),
                nn.Linear(2 * (1 << n_qubits), 1 << n_qubits))

    def _zz_correlations(self, re, im):
        """相邻比特 ⟨Z_k Z_{k+1}⟩ 相关(环形)。返回 [N, q]。"""
        N = re.shape[0]
        prob = re * re + im * im
        q = self.q
        outs = []
        for k in range(q):
            j = (k + 1) % q
            idx = torch.arange(1 << q, device=re.device)
            sgn = (1.0 - 2.0 * ((idx >> k) & 1).to(re.dtype)) * (1.0 - 2.0 * ((idx >> j) & 1).to(re.dtype))
            outs.append((prob * sgn.unsqueeze(0)).sum(1))
            if q <= 1:
                break
        return torch.stack(outs, dim=1) if outs else torch.zeros(N, 0, device=re.device, dtype=re.dtype)

    def quantum_state(self, H: torch.Tensor):
        """H:[N,d] → 量子复态 (re, im):[N, 2^q]。"""
        if self.encoding == "amplitude":
            re0, im0 = self.amp(H)
            return self.circuit(init_state=(re0, im0))
        return self.circuit(self.compress(H))

    def readout_features(self, H, re, im):
        """混合读出:归一后的(量子+经典)融合向量 [N, readout_dim]。"""
        marg = _single_qubit_marginals(re, im, self.q).reshape(re.shape[0], -1)
        zz = self._zz_correlations(re, im)
        qv = self.q_readout(torch.cat([marg, zz], dim=1))
        cv = self.cls_proj(H)
        g = torch.sigmoid(self.fuse_gate)
        return F.normalize(torch.cat([cv, g * qv], dim=1), dim=1)

    def forward(self, H: torch.Tensor):
        """H:[N,d] → dict(re/im/squared/readout)。"""
        if not self.use_quantum:
            v = F.normalize(self.proj(H), dim=1)
            return {"re": v, "im": torch.zeros_like(v), "squared": False, "readout": None}
        re, im = self.quantum_state(H)
        readout = self.readout_features(H, re, im) if self.hybrid_readout else None
        return {"re": re, "im": im, "squared": True, "readout": readout}


# ============================================================
# 第二层 · 相似度:全局保真度 + 局部保真度 + 混合相似度
# ============================================================
def fidelity_sim(A_re, A_im, B_re, B_im, squared: bool):
    """squared=True: |⟨a|b⟩|²∈[0,1]; False: 实内积(余弦)。返回 [nA,nB]。"""
    re = A_re @ B_re.t() + A_im @ B_im.t()
    im = A_re @ B_im.t() - A_im @ B_re.t()
    if squared:
        return re * re + im * im
    return re


def local_fidelity_sim(A_re, A_im, B_re, B_im, q: int):
    """局部保真度:对每比特单比特约化密度矩阵的 Bloch 向量做 ½(1+a·b),再对 q 比特平均。
    梯度方差在浅层线路下多项式衰减(避免贫瘠高原)。返回 [nA,nB]∈[0,1]。"""
    a = _single_qubit_marginals(A_re, A_im, q)
    b = _single_qubit_marginals(B_re, B_im, q)
    nA, nB = a.shape[0], b.shape[0]
    sim = torch.zeros(nA, nB, device=A_re.device, dtype=A_re.dtype)
    for k in range(q):
        sim = sim + 0.5 * (1.0 + a[:, k, :] @ b[:, k, :].t())
    return sim / q


def hybrid_sim(readout_A, readout_B):
    """混合读出相似度:归一融合向量的余弦,平移到 [0,1]。"""
    return 0.5 * (1.0 + readout_A @ readout_B.t())


# ============================================================
# 第二层 · 误差缓解:去极化噪声 + ZNE(标量 Richardson 外推)
# ============================================================
def depolarized_fidelity(F_pure: torch.Tensor, p: float, dim: int) -> torch.Tensor:
    """去极化信道下保真度 Tr(ρ_aρ_b) = (1-p)²F + (2p-p²)/D。"""
    p = max(0.0, min(1.0, p))
    return (1 - p) ** 2 * F_pure + (2 * p - p * p) / dim


def zne_fidelity(F_pure: torch.Tensor, base_p: float, dim: int, scales) -> torch.Tensor:
    """零噪声外推:在噪声放大因子 scales 上测标量保真度,多项式外推到 p→0。"""
    scales = list(scales)
    xs = [base_p * s for s in scales]
    ys = [depolarized_fidelity(F_pure, x, dim) for x in xs]
    deg = min(2, len(scales) - 1)
    X = torch.tensor([[x ** k for k in range(deg + 1)] for x in xs],
                     dtype=F_pure.dtype, device="cpu")
    Y = torch.stack(ys, dim=0).reshape(len(scales), -1).to("cpu")
    coef = torch.linalg.lstsq(X, Y).solution
    return coef[0].reshape(F_pure.shape).to(F_pure.device).clamp(0.0, 1.0)


# ============================================================
# 第二层 · 可训练性诊断(可选):贫瘠高原探针
# ============================================================
@torch.no_grad()
def barren_plateau_probe(head: "QuantumHilbertHead", H: torch.Tensor,
                         n_samples: int = 20, eps: float = 1e-2) -> float:
    """贫瘠高原探针(免梯度):随机参数点的有限差分方差。越大=代价景观越健康(非平坦)。"""
    if not head.use_quantum:
        return float("nan")
    circ = head.circuit
    Hs = H[:min(32, H.shape[0])]
    diffs = []
    for _ in range(n_samples):
        which = "theta" if torch.rand(1).item() < 0.5 else "phi"
        P = getattr(circ, which)
        l = torch.randint(0, P.shape[0], (1,)).item()
        k = torch.randint(0, P.shape[1], (1,)).item()
        orig = P[l, k].item()

        def energy():
            re, im = head.quantum_state(Hs)
            return _single_qubit_marginals(re, im, head.q)[:, 0, 0].mean().item()

        P[l, k] = orig + eps; ep = energy()
        P[l, k] = orig - eps; em = energy()
        P[l, k] = orig
        diffs.append((ep - em) / (2 * eps))
    return float(np.var(diffs))
