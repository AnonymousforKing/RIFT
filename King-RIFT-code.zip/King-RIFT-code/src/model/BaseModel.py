from src.utils import *
# Mac 适配:torch_scatter 在 Apple Silicon 上无法安装且不支持 MPS,
# 改用原生 PyTorch 等价实现(语义对齐,tests/verify_scatter.py 逐元素对拍验证)。
# 保持与原 star-import 相同的导出面:LKGE.py 等经 `from .BaseModel import *` 继承这些名字。
from .scatter_native import scatter_add, scatter_mean, scatter_max
from torch import Tensor

class BaseModel(nn.Module):
    def __init__(self, args, kg):
        super(BaseModel, self).__init__()
        self.args = args
        self.kg = kg  # information of snapshot sequence, self.kg.snapshots[i] is the i-th snapshot
        self.LeakyReLU = nn.LeakyReLU(0.2)

        # 精度治理:去掉硬编码 .double(),由 main.py 的 set_default_dtype 统一决定。
        # CPU/CUDA 默认 float64(与原版逐位一致);MPS 用 float32(MPS 不支持 float64)。
        self.ent_embeddings_list = nn.ParameterList()
        self.ent_embeddings_list.append(nn.Parameter(Tensor(self.kg.snapshots[0].num_ent, self.args.emb_dim).to(self.args.device)))

        self.expand_ent_embeddings = None

        self.rel_embeddings = nn.Parameter(Tensor(self.kg.snapshots[0].num_rel, self.args.emb_dim).to(self.args.device))
        xavier_normal_(self.ent_embeddings_list[0])
        xavier_normal_(self.rel_embeddings)
        if self.args.Parameter_cut == 'True':
            self.valid_vectors = []

            self.valid_vectors.append(list(range(0,self.kg.snapshots[0].num_ent)))

            self.unvalid_vectors = []

            self.unvalid_vectors.append(list())

            self.unvalid_to_oldIndex = []

            self.unvalid_to_oldIndex.append(list())

            self.recontruct_vectors = []

        '''loss function'''
        self.margin_loss_func = nn.MarginRankingLoss(margin=float(self.args.margin), reduction="sum")#.to(self.args.device)  #

    def init_expanded_parameters(self):
        self.expand_ent_embeddings = nn.Parameter(Tensor(self.kg.snapshots[self.args.snapshot].num_ent,self.args.emb_dim).to(self.args.device))
        xavier_normal_(self.expand_ent_embeddings)

        new_ent_embeddings = self.expand_ent_embeddings.data

        last_ent_embeddings,_ = self.embedding('switch')

        new_ent_embeddings[:self.kg.snapshots[self.args.snapshot - 1].num_ent] = last_ent_embeddings[:self.kg.snapshots[self.args.snapshot - 1].num_ent].data
        self.expand_ent_embeddings = nn.Parameter(new_ent_embeddings)

    def reinit_param(self):
        '''
        Re-initialize all model parameters
        '''
        for n, p in self.named_parameters():
            if p.requires_grad:
                xavier_normal_(p)

    def expand_embedding_size(self):
        '''
        Initialize entity and relation embeddings for next snapshot
        '''
        ent_embeddings = nn.Embedding(self.kg.snapshots[self.args.snapshot + 1].num_ent, self.args.emb_dim).to(
            self.args.device)
        rel_embeddings = nn.Embedding(self.kg.snapshots[self.args.snapshot + 1].num_rel, self.args.emb_dim).to(
            self.args.device)
        xavier_normal_(ent_embeddings.weight)
        xavier_normal_(rel_embeddings.weight)
        return deepcopy(ent_embeddings), deepcopy(rel_embeddings)

    def store_old_parameters(self):
        '''
        Store the learned model after training on a snapshot
        '''
        for name, param in self.named_parameters():
            name = name.replace('.', '_')
            if param.requires_grad:
                value = param.data
                self.register_buffer('old_data_{}'.format(name), value.clone().detach())

    def initialize_old_data(self):
        '''
        Initialize the storage of old parameters
        '''
        for n, p in self.named_parameters():
            if p.requires_grad:
                n = n.replace('.', '_')
                self.register_buffer('old_data_{}'.format(n), p.data.clone())

    def isolate_parameters(self):
        for item in self.ent_embeddings_list:
            item.requires_grad = False

    def combine(self):
        if self.expand_ent_embeddings is not None:
            self.ent_embeddings_list.append(self.expand_ent_embeddings)
            self.expand_ent_embeddings = None
            # for name, param in self.named_parameters():
            #     name_ = name.replace('.', '_')
            #     if 'ent_embeddings' in name_:
            #         value = param.data
            #         self.register_buffer('old_weight_{}'.format(name_), value)
            #         # self.register_buffer('old_data_{}'.format(name_), torch.tensor([[]]))

    def embedding_to_detach(self,ss_id):
        self.ent_embeddings_list[ss_id].requires_grad = False
        self.ent_embeddings_list[ss_id].detach()

    def expand_rel_embedding_size(self):
        '''
        Initialize relation embeddings for next snapshot
        '''
        rel_embeddings = nn.Parameter(Tensor(self.kg.snapshots[self.args.snapshot + 1].num_rel, self.args.emb_dim)).to(self.args.device)
        xavier_normal_(rel_embeddings)
        return rel_embeddings.clone()

    def expand_ent_embedding_size(self):
        '''
        Initialize entity embeddings for next snapshot
        '''
        ent_embeddings = Tensor(self.kg.snapshots[self.args.snapshot + 1].num_ent, self.args.emb_dim).to(self.args.device)
        xavier_normal_(ent_embeddings)
        return ent_embeddings.clone()

    def embedding(self, stage=None):
        '''
        :param stage: Train / Valid / Test
        :return: entity and relation embeddings
        '''
        if stage == 'Train':
            # store gcn_embedding
            if self.expand_ent_embeddings is not None:
                # snapshot > 0
                return self.expand_ent_embeddings,self.rel_embeddings
            else:
                # snapshot = 0
                return self.ent_embeddings_list[0],self.rel_embeddings
        elif stage == 'switch':
            if self.args.Parameter_cut == 'True' and self.args.snapshot > 0:

                last_ent_embeddings = torch.cat([self.ent_embeddings_list[0].data,torch.zeros(self.kg.snapshots[self.args.snapshot].num_ent - self.ent_embeddings_list[0].shape[0],self.args.emb_dim).to(self.args.device)])
                for index in range(1,self.args.snapshot+1):
                    try:
                        indice = self.valid_vectors[index]
                        last_ent_embeddings[indice] = self.ent_embeddings_list[index].data
                    except:
                        print("except\n")
                return last_ent_embeddings,self.rel_embeddings
            else:
                return self.ent_embeddings_list[-1],self.rel_embeddings
        elif stage == 'Valid':
            if self.expand_ent_embeddings is not None:
                # snapshot > 0
                return self.expand_ent_embeddings,self.rel_embeddings
            else:
                # snapshot = 0
                return self.ent_embeddings_list[0],self.rel_embeddings
        elif stage == 'Test':
            if self.args.Parameter_cut == "True":
                last_ent_embeddings_list = []
                last_ent_embeddings_list.append(self.ent_embeddings_list[0].data)
                for index in range(1,self.args.snapshot + 1):
                    indice = self.valid_vectors[index]
                    temp_ent_embedding = torch.cat([self.ent_embeddings_list[index],torch.zeros(self.kg.snapshots[index].num_ent - self.ent_embeddings_list[index].shape[0],self.args.emb_dim).to(self.args.device)])
                    temp_ent_embedding[indice] = self.ent_embeddings_list[index]
                    unindice = np.array(self.unvalid_vectors[index])
                    unvalid_to_oldIndex = self.unvalid_to_oldIndex[index]
                    if len(unindice) != 0:
                        for i in range(0,index):
                            mask = (np.array(unvalid_to_oldIndex) == i)
                            test = list(unindice[mask])

                            temp_ent_embedding[unindice[mask]] = last_ent_embeddings_list[i][unindice[mask]]
                    last_ent_embeddings_list.append(temp_ent_embedding)
                return last_ent_embeddings_list,self.rel_embeddings
            else:
                # During snapshot>0 training the current entity table lives in
                # ``expand_ent_embeddings`` until ``combine()`` is called.
                # Temporal validation must see that trainable facet; otherwise
                # all newly introduced entities receive no current-snapshot score.
                embeddings = list(self.ent_embeddings_list)
                if self.expand_ent_embeddings is not None:
                    embeddings.append(self.expand_ent_embeddings)
                return embeddings,self.rel_embeddings

    def new_loss(self, head, rel, tail=None, label=None):
        """Task loss normalized according to ``-loss_normalization``."""
        return self.margin_loss(head, rel, tail, label)

    def score_with_embeddings(self, head, rel, tail, ent_embeddings, rel_embeddings):
        """TransE distances using an explicitly supplied representation facet."""
        s = torch.index_select(ent_embeddings, 0, head)
        r = torch.index_select(rel_embeddings, 0, rel)
        o = torch.index_select(ent_embeddings, 0, tail)
        return self.score_fun(s, r, o)

    def ranking_loss_from_scores(self, score, label):
        """Aggregate or per-negative margin hinges with corrected normalization."""
        if label is None:
            raise ValueError('label is required for margin ranking loss')
        positive = score[label > 0]
        negative = score[label < 0]
        if positive.numel() == 0:
            return score.new_zeros(())
        if negative.numel() % positive.numel() != 0:
            raise ValueError('negative count must be divisible by positive count')
        ratio = negative.numel() // positive.numel()
        if ratio == 0:
            return score.new_zeros(())
        neg = negative.reshape(positive.numel(), ratio)
        adv_temp = float(getattr(self.args, 'adv_temp', 0.0) or 0.0)
        weights = None
        if adv_temp > 0:
            weights = torch.softmax(-adv_temp * neg, dim=1).detach()

        mode = str(getattr(self.args, 'negative_loss', 'aggregate')).lower()
        margin = float(self.args.margin)
        if mode == 'pairwise':
            hinge = torch.relu(margin + positive.unsqueeze(1) - neg)
            per_positive = ((weights * hinge).sum(dim=1)
                            if weights is not None else hinge.mean(dim=1))
        elif mode == 'aggregate':
            neg_score = ((weights * neg).sum(dim=1)
                         if weights is not None else neg.mean(dim=1))
            per_positive = torch.relu(margin + positive - neg_score)
        else:
            raise ValueError('unknown negative_loss: {}'.format(mode))

        normalization = str(getattr(self.args, 'loss_normalization', 'legacy')).lower()
        if normalization == 'positive':
            return per_positive.mean()
        if normalization == 'legacy':
            return per_positive.sum() / max(int(score.numel()), 1)
        raise ValueError('unknown loss_normalization: {}'.format(normalization))

    def margin_loss_with_embeddings(self, head, rel, tail, label,
                                    ent_embeddings, rel_embeddings):
        score = self.score_with_embeddings(head, rel, tail, ent_embeddings, rel_embeddings)
        return self.ranking_loss_from_scores(score, label)

    def margin_loss(self, head, rel, tail, label=None):
        ent_embeddings, rel_embeddings = self.embedding('Train')
        return self.margin_loss_with_embeddings(
            head, rel, tail, label, ent_embeddings, rel_embeddings)

    def split_pn_score(self, score, label):
        """Compatibility helper used by legacy tests and analysis scripts."""
        p_score = score[label > 0]
        negative = score[label < 0]
        if p_score.numel() == 0:
            return p_score, negative
        if negative.numel() % p_score.numel() != 0:
            raise ValueError('negative count must be divisible by positive count')
        n_all = negative.reshape(p_score.numel(), -1)
        adv_temp = float(getattr(self.args, 'adv_temp', 0.0) or 0.0)
        if adv_temp > 0:
            weights = torch.softmax(-adv_temp * n_all, dim=1).detach()
            n_score = (weights * n_all).sum(dim=1)
        else:
            n_score = n_all.mean(dim=1)
        return p_score, n_score

    def score_fun(self, s, r, o):
        '''
        score function f(s, r, o) = L1-norm(s + r - o)
        :param h:
        :param r:
        :param t:
        :return:
        '''
        s = self.norm_ent(s)
        r = self.norm_rel(r)
        o = self.norm_ent(o)
        return torch.norm(s + r - o, 1, -1)

    def predict(self, sub, rel, obj, stage='Valid'):
        if str(getattr(self.args, 'temporal_fusion', 'legacy')).lower() == 'candidate':
            return self._predict_candidate_fusion(sub, rel, stage=stage)
        '''
        Scores all candidate facts for evaluation
        :param head: subject entity id
        :param rel: relation id
        :param stage: object entity id
        :return: scores of all candidate facts
        '''

        '''get entity and relation embeddings'''
        if stage != 'Test':
            num_ent = self.kg.snapshots[self.args.snapshot].num_ent
        else:
            num_ent = self.kg.snapshots[self.args.snapshot_test].num_ent

        stage = 'Test'
        ent_embeddings_list, rel_embeddings = self.embedding(stage)

        score_all = None
        r = torch.index_select(rel_embeddings, 0, rel)
        r_norm = self.norm_rel(r)

        attention_all = None
        idx = 0

        '''========== 多面注意力:向量化重写(性能优化,数学与原版等价) ==========
        原版逐 snapshot 物化 sub_r_embedding=[B,R,D] 大张量再做 einsum/norm,
        内存 O(B·R·D) 且每个 snapshot 重复计算"查询关系↔全部关系"的余弦。
        推导:设画像计数 c=sub_r_index[b,j]≥0,
          原式 cos[b,j] = (Σ_d c·rel[j,d]·r[b,d]) / ((c·||rel_j||)·||r_b||)
          c>0 时约去 c = ⟨rel_j,r_b⟩/(||rel_j||·||r_b||)(与 c 取值无关);
          c=0 时分子为 0、分母被钳为 1·||r_b|| → 结果为精确 0。
        故 cos_attention = mask(c>0) · cos(rel_j, r_b),其中余弦矩阵与 snapshot 无关,
        只需对整个 batch 计算一次并在各 snapshot 间共享;内存降为 O(B·R)(约 D 倍),
        einsum/大张量 norm 全部消除。数值:与原式差异仅来自浮点归约顺序
        (einsum vs matmul),量级 ≤ 数个 ulp(~1e-16),top-k 选择与最终排名不变;
        由 tests/verify_predict_equivalence.py 在 float64 下对拍并断言排名逐条一致。'''
        rel_norms = torch.norm(rel_embeddings, dim=1)
        rel_norms = torch.where(rel_norms > 0, rel_norms, rel_norms.new_tensor(1.0))
        norm_matrix2 = torch.norm(r, dim=1).unsqueeze(1)
        cos_qr = (r @ rel_embeddings.t()) / (rel_norms.unsqueeze(0) * norm_matrix2)

        sub_cpu = sub.cpu().detach().numpy()
        num_rel_total = rel_embeddings.shape[0]

        index_module = 0
        for t in range(len(ent_embeddings_list)):
            item = ent_embeddings_list[index_module]
            index_module += 1
            sub_mask = (sub >= 0) & (sub < item.shape[0])
            obj_mask = (obj >= 0) & (obj < item.shape[0])

            train_ent2rel = self.kg.snapshots[idx].train_ent2rel

            '''与原版 pad/truncate + 行选择等价,但只物化 [B,R_t] 的被选行(省去 [num_ent,R] 拷贝)'''
            if num_ent > train_ent2rel.shape[0]:
                rows_np = np.zeros((sub_cpu.shape[0], train_ent2rel.shape[1]), dtype=train_ent2rel.dtype)
                in_range = sub_cpu < train_ent2rel.shape[0]
                rows_np[in_range] = train_ent2rel[sub_cpu[in_range], :]
            else:
                rows_np = train_ent2rel[sub_cpu, :]

            idx = idx + 1

            mask = torch.from_numpy(rows_np > 0).to(self.args.device)
            if mask.shape[1] < num_rel_total:
                mask = torch.cat([mask, torch.zeros(mask.shape[0], num_rel_total - mask.shape[1],
                                                    dtype=torch.bool, device=self.args.device)], dim=1)

            cos_attention = torch.where(mask, cos_qr, cos_qr.new_tensor(0.0))
            if getattr(self.args, 'quantum_attn', 'False') == 'True':
                # opt-in:把关系画像↔查询关系的余弦重述为量子态重叠测量(振幅编码)。
                # hadamard(默认 mode)= 余弦,逐位等价;swap/shots = 量子保真度估计器。
                from .quantum import overlap_measure
                cos_attention = overlap_measure(cos_attention,
                                                mode=getattr(self.args, 'quantum_sim_mode', 'hadamard'),
                                                shots=int(getattr(self.args, 'quantum_sim_shots', 0) or 0))
            k = int(self.args.Top_k)
            top_k_values,top_k_indices = torch.topk(cos_attention,k,dim=1)
            attention = top_k_values.sum(dim=1)
            # weights = 1 + torch.sum(torch.gather(sub_r_index, 1, top_k_indices),dim = 1) / torch.sum(sub_r_index,dim = 1)
            # attention = attention * weights

            attention[~sub_mask] = 0
            attention[~obj_mask] = 0
            if attention_all is None:
                attention_all = attention.unsqueeze(1)
            else:
                attention_all = torch.cat([attention_all,attention.unsqueeze(1)],dim = 1)


        attention_all = nn.Softmax(dim = -1)(attention_all)
        if self.args.wo_adaptive == 'True':
            attention_all = torch.ones_like(attention_all) / attention_all.size(-1)

        '''候选实体分块打分(-eval_ent_chunk>0 时启用):把 [B,num_ent,D] 的中间张量
        切成 [B,chunk,D],峰值内存受控;每个输出元素的算子序列不变 → 结果逐位一致。'''
        chunk = int(getattr(self.args, 'eval_ent_chunk', 0) or 0)

        index_module = 0
        with torch.no_grad():
            for t in range(len(self.ent_embeddings_list)):
                item = ent_embeddings_list[index_module]
                sub_mask = (sub >= 0) & (sub < item.shape[0])
                obj_mask = (obj >= 0) & (obj < item.shape[0])
                item = item[:num_ent]
                item = torch.cat([item,torch.zeros(num_ent - item.shape[0],self.args.emb_dim).to(self.args.device)],dim=0)
                s = torch.index_select(item, 0, sub)

                o_all = item[:num_ent]
                s = self.norm_ent(s)

                o_all = self.norm_ent(o_all)

                pred_o = s + r_norm

                if chunk > 0 and num_ent > chunk:
                    parts = []
                    for c0 in range(0, num_ent, chunk):
                        o_c = o_all[c0:c0 + chunk]
                        parts.append(9.0 - torch.norm(pred_o.unsqueeze(1) - o_c, p=1, dim=2))
                    score = torch.cat(parts, dim=1)
                else:
                    score = 9.0 - torch.norm(pred_o.unsqueeze(1) - o_all, p=1, dim=2)
                score[~sub_mask] = 0
                score[~obj_mask] = 0
                if score_all is None:
                    score_all = score * attention_all[:,index_module].unsqueeze(1)
                else:
                    score_all += score * attention_all[:,index_module].unsqueeze(1)

                index_module += 1
            return score_all, torch.sum(attention_all, dim=0)

    def _predict_candidate_fusion(self, sub, rel, stage='Test'):
        """Leakage-free temporal fusion normalized per candidate entity."""
        if stage != 'Test':
            num_ent = self.kg.snapshots[self.args.snapshot].num_ent
        else:
            num_ent = self.kg.snapshots[self.args.snapshot_test].num_ent

        ent_embeddings_list, rel_embeddings = self.embedding('Test')
        query_r = torch.index_select(rel_embeddings, 0, rel)
        query_r_norm = self.norm_rel(query_r)
        relation_unit = self.norm_rel(rel_embeddings)
        cosine = query_r_norm @ relation_unit.t()
        sub_cpu = sub.detach().cpu().numpy()
        num_rel_total = rel_embeddings.shape[0]

        logits, available_columns = [], []
        for idx, item in enumerate(ent_embeddings_list):
            entity_available = (sub >= 0) & (sub < item.shape[0])
            profile = self.kg.snapshots[idx].train_ent2rel
            rows = np.zeros((sub_cpu.shape[0], profile.shape[1]), dtype=profile.dtype)
            in_range = (sub_cpu >= 0) & (sub_cpu < profile.shape[0])
            if in_range.any():
                rows[in_range] = profile[sub_cpu[in_range]]
            mask = torch.from_numpy(rows > 0).to(device=self.args.device)
            if mask.shape[1] < num_rel_total:
                mask = torch.cat([
                    mask,
                    torch.zeros(mask.shape[0], num_rel_total - mask.shape[1],
                                dtype=torch.bool, device=self.args.device),
                ], dim=1)
            elif mask.shape[1] > num_rel_total:
                mask = mask[:, :num_rel_total]
            # An entity introduced only by valid/test data can exist in a snapshot
            # without any training relation profile.  Such a snapshot should not
            # compete for temporal attention merely because its empty logit is 0.
            available_columns.append(entity_available & mask.any(dim=1))
            relation_similarity = cosine
            if getattr(self.args, 'quantum_attn', 'False') == 'True':
                from .quantum import overlap_measure
                relation_similarity = overlap_measure(
                    relation_similarity,
                    mode=getattr(self.args, 'quantum_sim_mode', 'hadamard'),
                    shots=int(getattr(self.args, 'quantum_sim_shots', 0) or 0),
                )
            # Absent profile relations must not outrank present relations whose
            # cosine happens to be negative. Keep up to k genuine profile entries;
            # snapshots with fewer than k entries contribute only those entries.
            masked_similarity = relation_similarity.masked_fill(
                ~mask, torch.finfo(relation_similarity.dtype).min
            )
            k = min(int(self.args.Top_k), relation_similarity.shape[1])
            values, indices = masked_similarity.topk(k, dim=1)
            selected = mask.gather(1, indices)
            logits.append(torch.where(selected, values, values.new_zeros(())).sum(dim=1))

        logits = torch.stack(logits, dim=1)
        available = torch.stack(available_columns, dim=1)
        no_available = ~available.any(dim=1)
        if no_available.any():
            available[no_available, -1] = True
        masked_logits = logits.masked_fill(~available, torch.finfo(logits.dtype).min)
        attention_all = torch.softmax(masked_logits, dim=1)
        if self.args.wo_adaptive == 'True':
            attention_all = available.to(logits.dtype)
            attention_all = attention_all / attention_all.sum(dim=1, keepdim=True).clamp_min(1.0)

        chunk = int(getattr(self.args, 'eval_ent_chunk', 0) or 0)
        numerator = query_r.new_zeros((sub.shape[0], num_ent))
        denominator = query_r.new_zeros((sub.shape[0], num_ent))

        for idx, item in enumerate(ent_embeddings_list):
            valid_n = min(int(item.shape[0]), int(num_ent))
            if valid_n <= 0:
                continue
            item_current = item[:valid_n]
            if valid_n < num_ent:
                item_full = torch.cat([
                    item_current,
                    item.new_zeros((num_ent - valid_n, item.shape[1])),
                ], dim=0)
            else:
                item_full = item_current
            subject = self.norm_ent(torch.index_select(item_full, 0, sub))
            objects = self.norm_ent(item_current)
            predicted_object = subject + query_r_norm
            if chunk > 0 and valid_n > chunk:
                parts = []
                for c0 in range(0, valid_n, chunk):
                    parts.append(9.0 - torch.norm(
                        predicted_object.unsqueeze(1) - objects[c0:c0 + chunk],
                        p=1, dim=2))
                local_score = torch.cat(parts, dim=1)
            else:
                local_score = 9.0 - torch.norm(
                    predicted_object.unsqueeze(1) - objects, p=1, dim=2)

            # Every snapshot contains the entity id prefix [0, valid_n).  Update
            # only that slice instead of materializing per-snapshot [B, num_ent]
            # score and availability tensors.  This is especially helpful on MPS,
            # where large temporary allocations pressure unified memory.
            active_weight = (
                attention_all[:, idx].unsqueeze(1)
                * available[:, idx].to(attention_all.dtype).unsqueeze(1)
            )
            numerator[:, :valid_n].add_(local_score * active_weight)
            denominator[:, :valid_n].add_(active_weight)

        fused = numerator / denominator.clamp_min(torch.finfo(denominator.dtype).eps)
        return fused, attention_all.sum(dim=0)

    def predict_Valid(self, sub, rel,stage='Valid'):
        num_ent = self.kg.snapshots[self.args.snapshot].num_ent
        stage='Valid'
        ent_embeddings, rel_embeddings = self.embedding(stage)

        s = torch.index_select(ent_embeddings, 0, sub)
        o_all = ent_embeddings[:num_ent]
        r = torch.index_select(rel_embeddings, 0, rel)
        s = self.norm_ent(s)
        r = self.norm_rel(r)
        o_all = self.norm_ent(o_all)
        '''s + r - o'''
        pred_o = s + r

        chunk = int(getattr(self.args, 'eval_ent_chunk', 0) or 0)
        if chunk > 0 and num_ent > chunk:
            parts = []
            for c0 in range(0, num_ent, chunk):
                o_c = o_all[c0:c0 + chunk]
                parts.append(9.0 - torch.norm(pred_o.unsqueeze(1) - o_c, p=1, dim=2))
            score = torch.cat(parts, dim=1)
        else:
            score = 9.0 - torch.norm(pred_o.unsqueeze(1) - o_all, p=1, dim=2)
        score = torch.sigmoid(score)

        return score

    def _normalization_eps(self, tensor):
        configured = float(getattr(self.args, 'norm_eps', 1e-12))
        if tensor.dtype in (torch.float16, torch.bfloat16, torch.float32):
            return max(configured, 1e-6)
        return configured

    def norm_rel(self, r):
        return nn.functional.normalize(r, 2, -1, eps=self._normalization_eps(r))

    def norm_ent(self, e):
        return nn.functional.normalize(e, 2, -1, eps=self._normalization_eps(e))

    def find_triples(self, index, head_entity_id):
        train_facts = self.kg.snapshots[index].train_new
        output_triples = []
        for (s,r,o) in train_facts:
            if head_entity_id.item() == s or head_entity_id.item() == o:
                output_triples.append((self.kg.entity_id2name[s],self.kg.id2relation[r],self.kg.entity_id2name[o]))

        return output_triples
