# -*- coding: utf-8 -*-
"""Train and evaluate MF-CKGE/IBMA on a sequence of HYBRID snapshots."""
from __future__ import annotations

import logging
import os
import shutil
import sys
import time
from datetime import datetime

import torch

from src.config import config
from src.data_load.KnowledgeGraph import KnowledgeGraph
from src.model.MF_CKGE import TransE as MF_CKGE_TransE
from src.parse_args import args
from src.test import Tester
from src.train import Trainer
from src.utils import PrettyTable, empty_device_cache, resolve_dtype, same_seeds, select_device


class Experiment:
    def __init__(self, args):
        self.args = args
        self.prepare()
        self.kg = KnowledgeGraph(args)
        self.model = self.create_model()
        self.args.logger.info(self.args)
        self._log_dataset_summary()

    def _log_dataset_summary(self):
        for snapshot_id in range(int(self.args.snapshot_num)):
            s = self.kg.snapshots[snapshot_id]
            self.args.logger.info(
                "HYBRID snapshot=%d entities=%d relations=%d train=%d valid=%d test=%d",
                snapshot_id,
                s.num_ent,
                s.num_rel,
                len(s.train_new),
                len(s.valid),
                len(s.test),
            )

    def create_model(self):
        if self.args.CKGE_name != "MF-CKGE" or self.args.embedding_model != "TransE":
            raise ValueError("this optimized entry point currently supports MF-CKGE + TransE")
        model = MF_CKGE_TransE(self.args, self.kg).to(self.args.device)
        return model

    def create_optimizer(self):
        parameters = [p for p in self.model.parameters() if p.requires_grad]
        if not parameters:
            raise RuntimeError("no trainable parameters remain")
        return torch.optim.Adam(
            parameters,
            lr=float(self.args.learning_rate),
            weight_decay=float(self.args.l2),
        )

    def build_scheduler(self, optimizer):
        mode = str(getattr(self.args, "lr_scheduler", "none")).lower()
        if mode == "plateau":
            return torch.optim.lr_scheduler.ReduceLROnPlateau(
                optimizer,
                mode="max",
                factor=float(self.args.lr_decay_factor),
                patience=int(self.args.lr_decay_patience),
                min_lr=float(self.args.lr_min),
            )
        if mode == "cosine":
            return torch.optim.lr_scheduler.CosineAnnealingLR(
                optimizer,
                T_max=max(int(self.args.epoch_num), 1),
                eta_min=float(self.args.lr_min),
            )
        return None

    @staticmethod
    def _is_plateau(scheduler):
        return isinstance(scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau)

    def _checkpoint_path(self, snapshot_id=None):
        snapshot_id = self.args.snapshot if snapshot_id is None else snapshot_id
        return os.path.join(self.args.save_path, "{}model_best.tar".format(snapshot_id))

    def save_model(self, metric):
        path = self._checkpoint_path()
        temporary = path + ".tmp"
        torch.save(
            {
                "state_dict": self.model.state_dict(),
                "epoch_id": int(self.args.epoch),
                "metric": float(metric),
                "snapshot": int(self.args.snapshot),
            },
            temporary,
        )
        os.replace(temporary, path)

    def load_checkpoint(self, path, force=False):
        if not os.path.isfile(path):
            raise FileNotFoundError("checkpoint not found: {}".format(path))
        self.args.logger.info("loading checkpoint %s", path)
        try:
            checkpoint = torch.load(path, map_location=self.args.device, weights_only=False)
        except TypeError:
            checkpoint = torch.load(path, map_location=self.args.device)
        if force or str(getattr(self.args, "restore_best", "False")) == "True":
            self.model.load_state_dict(checkpoint["state_dict"], strict=True)
            self.args.logger.info(
                "restored snapshot=%s epoch=%s metric=%s",
                checkpoint.get("snapshot", "?"),
                checkpoint.get("epoch_id", "?"),
                checkpoint.get("metric", "?"),
            )
        return checkpoint

    def _train_current_snapshot(self, expanded=False):
        if expanded:
            self.model.init_expanded_parameters()
            self.model.isolate_parameters()

        self.args.train_step = 0
        self.args.logger.info("trainable parameter configuration:")
        for name, param in self.model.named_parameters():
            self.args.logger.info(
                "parameter %s shape=%s trainable=%s",
                name,
                tuple(param.shape),
                param.requires_grad,
            )

        optimizer = self.create_optimizer()
        trainer = Trainer(self.args, self.kg, self.model, optimizer)
        scheduler = self.build_scheduler(optimizer)
        best_metric = float("-inf")
        checks_without_improvement = 0
        best_path = self._checkpoint_path()
        start = time.time()

        for epoch in range(int(self.args.epoch_num)):
            self.args.epoch = epoch
            validate = (
                epoch % int(self.args.valid_every) == 0
                or epoch == int(self.args.epoch_num) - 1
            )
            loss, valid_result = trainer.run_epoch(validate=validate)

            if scheduler is not None and not self._is_plateau(scheduler):
                scheduler.step()

            if valid_result is None:
                self.args.logger.info(
                    "snapshot=%d epoch=%d loss=%.6f lr=%.3g validation=skipped",
                    self.args.snapshot,
                    epoch,
                    loss,
                    optimizer.param_groups[0]["lr"],
                )
                continue

            metric = float(valid_result[self.args.valid_metrics])
            if scheduler is not None and self._is_plateau(scheduler):
                scheduler.step(metric)

            improved = metric > best_metric
            if improved:
                best_metric = metric
                checks_without_improvement = 0
                self.save_model(metric)
            else:
                checks_without_improvement += 1

            ib_classes = (
                getattr(self.model.ib_align, "last_num_relations", 0)
                if getattr(self.model, "ib_align", None) is not None
                else 0
            )
            self.args.logger.info(
                "snapshot=%d epoch=%d loss=%.6f MRR=%.6f H@10=%.6f "
                "best=%.6f lr=%.3g ib_relations=%d",
                self.args.snapshot,
                epoch,
                loss,
                valid_result["mrr"],
                valid_result["hits10"],
                best_metric,
                optimizer.param_groups[0]["lr"],
                ib_classes,
            )
            if checks_without_improvement >= int(self.args.patience):
                self.args.logger.info(
                    "early stopping snapshot=%d epoch=%d best_%s=%.6f",
                    self.args.snapshot,
                    epoch,
                    self.args.valid_metrics,
                    best_metric,
                )
                break

        elapsed = time.time() - start
        if not os.path.isfile(best_path):
            # Covers zero-epoch debugging runs without leaving the model unloadable.
            self.args.epoch = max(int(self.args.epoch_num) - 1, 0)
            self.save_model(float("nan"))
        if str(getattr(self.args, "restore_best", "False")) == "True":
            self.load_checkpoint(best_path, force=True)

        if self.args.Parameter_cut == "True":
            self.model.store_gcn_embedding()
            if expanded:
                self.model.parameter_cut()
        if expanded:
            self.model.combine()
        return elapsed

    def train_snapshot(self, snapshot_id):
        if snapshot_id == 0 and self.args.Pass_snapshot0 == "True":
            self.load_checkpoint(self._checkpoint_path(0), force=True)
            if self.args.Parameter_cut == "True":
                self.model.store_gcn_embedding()
            return 0.0
        return self._train_current_snapshot(expanded=snapshot_id > 0)

    def test(self):
        return Tester(self.args, self.kg, self.model).test()

    def continual_learning(self):
        report = PrettyTable()
        report.field_names = [
            "Snapshot",
            "Time",
            "Whole_MRR",
            "Whole_Hits@1",
            "Whole_Hits@3",
            "Whole_Hits@10",
        ]
        all_test_tables = []
        training_times = []

        for snapshot_id in range(int(self.args.snapshot_num)):
            self.args.snapshot = snapshot_id
            self.args.snapshot_test = snapshot_id
            self.args.logger.info("starting snapshot %d", snapshot_id)
            training_time = self.train_snapshot(snapshot_id)

            self.model.embedding_to_detach(snapshot_id)
            empty_device_cache(self.args.device)

            table = PrettyTable()
            table.field_names = [
                "Snapshot:{}".format(snapshot_id),
                "MRR",
                "Hits@1",
                "Hits@3",
                "Hits@5",
                "Hits@10",
            ]
            results = []
            for test_snapshot in range(snapshot_id + 1):
                self.args.snapshot_test = test_snapshot
                result = self.test()
                table.add_row(
                    [
                        test_snapshot,
                        round(result["mrr"], 4),
                        round(result["hits1"], 4),
                        round(result["hits3"], 4),
                        round(result["hits5"], 4),
                        round(result["hits10"], 4),
                    ]
                )
                results.append(result)

            self.args.logger.info("\n%s", table)
            all_test_tables.append(table)
            whole = self.get_report_result(results)
            report.add_row(
                [snapshot_id, round(training_time, 2), *[round(v, 4) for v in whole]]
            )
            training_times.append(training_time)

            if snapshot_id < int(self.args.snapshot_num) - 1:
                self.model.switch_snapshot()
                empty_device_cache(self.args.device)

        self.args.logger.info("final per-snapshot results:\n%s", all_test_tables)
        self.args.logger.info("aggregate report:\n%s", report)
        self.args.logger.info("total training seconds=%.2f", sum(training_times))
        self.args.logger.info("per-snapshot training seconds=%s", training_times)

        if self.args.Parameter_cut == "True":
            all_entities = sum(
                self.kg.snapshots[i].num_ent for i in range(int(self.args.snapshot_num))
            )
            reused = sum(len(v) for v in self.model.unvalid_vectors)
            self.args.logger.info(
                "parameter-cut threshold=%s retained_ratio=%.4f",
                self.args.threshold,
                (all_entities - reused) / max(all_entities, 1),
            )

    def get_report_result(self, results):
        sizes = [len(self.kg.snapshots[i].test) * 2 for i in range(len(results))]
        denominator = max(sum(sizes), 1)
        keys = ("mrr", "hits1", "hits3", "hits10")
        return tuple(
            sum(result[key] * sizes[i] for i, result in enumerate(results)) / denominator
            for key in keys
        )

    def prepare(self):
        self.args.device = select_device(self.args.gpu)
        self.args.dtype = resolve_dtype(getattr(self.args, "fp", "auto"), self.args.device)
        torch.set_default_dtype(self.args.dtype)
        torch.set_float32_matmul_precision(str(getattr(self.args, "matmul_precision", "high")))

        base_data = os.path.abspath(self.args.data_path)
        base_save = os.path.abspath(self.args.save_path)
        base_log = os.path.abspath(self.args.log_path)
        self.args.data_path = os.path.join(base_data, self.args.dataset) + os.sep

        run_name = "{}-{}-{}-{}".format(
            self.args.dataset,
            self.args.embedding_model,
            self.args.CKGE_name,
            self.args.loss_name,
        )
        if str(getattr(self.args, "preset", "none")) != "none":
            run_name += "-{}".format(self.args.preset)
        if self.args.note:
            run_name += "-{}".format(str(self.args.note).lstrip("-_"))
        self.args.save_path = os.path.join(base_save, run_name)
        os.makedirs(self.args.save_path, exist_ok=True)

        date_dir = os.path.join(base_log, datetime.now().strftime("%Y%m%d"))
        os.makedirs(date_dir, exist_ok=True)
        log_file = os.path.join(
            date_dir, "{}-{}.log".format(run_name, datetime.now().strftime("%H%M%S"))
        )
        logger = logging.getLogger("mf_ckge_ibma")
        logger.handlers.clear()
        logger.propagate = False
        logger.setLevel(logging.INFO)
        formatter = logging.Formatter("%(asctime)s %(levelname)-8s: %(message)s")
        console_formatter = logging.Formatter("%(asctime)-8s: %(message)s")
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setFormatter(formatter)
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(console_formatter)
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
        self.args.logger = logger

        print(
            "[device] {} | [dtype] {} | [matmul_precision] {}".format(
                self.args.device,
                self.args.dtype,
                getattr(self.args, "matmul_precision", "high"),
            )
        )


# Backward-compatible name used by notebooks based on the uploaded project.
experiment = Experiment


if __name__ == "__main__":
    config(args)
    same_seeds(int(args.seed))
    Experiment(args).continual_learning()
