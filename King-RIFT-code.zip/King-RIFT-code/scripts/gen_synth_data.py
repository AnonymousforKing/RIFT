# -*- coding: utf-8 -*-
"""生成 5-snapshot 增长式合成知识图谱(用于无真实数据集时的端到端验证)。

输出目录结构与 README 约定一致:
    <out>/SYNTH/{0..4}/{train,valid,test}.txt   每行: head rel tail

实体/关系随 snapshot 增长(持续学习场景),三元组从"低秩语义 + 噪声"分布采样,
使嵌入模型可学(MRR 明显高于随机),同时规模足够小,CPU 数十秒内可完成全流程。
用法:
    python scripts/gen_synth_data.py [--out ./data] [--seed 55]
"""
import argparse
import os
import numpy as np


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default='./data')
    ap.add_argument('--seed', type=int, default=55)
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    ENT = [80, 120, 160, 200, 240]          # 每个 snapshot 结束时的累计实体数
    REL = [6, 8, 10, 12, 14]                # 累计关系数(基关系;载入时自动配 inv)
    N_TRAIN = [320, 240, 240, 240, 240]
    N_VALID = [40, 30, 30, 30, 30]
    N_TEST = [40, 30, 30, 30, 30]

    # 低秩"语义":每个实体/关系一个隐向量,r(h,t) 成立概率随 h+r≈t 的隐空间贴近度上升
    Z = 8
    ent_z = rng.normal(size=(ENT[-1], Z))
    rel_z = rng.normal(size=(REL[-1], Z)) * 0.5

    def sample_triples(n, num_ent, num_rel, lo_ent, seen):
        '''采 n 条不重复三元组;至少 30% 含新实体(id >= lo_ent),保证增长语义'''
        out = []
        guard = 0
        while len(out) < n and guard < n * 200:
            guard += 1
            if rng.random() < 0.3 and lo_ent < num_ent:
                h = int(rng.integers(lo_ent, num_ent))
            else:
                h = int(rng.integers(0, num_ent))
            r = int(rng.integers(0, num_rel))
            # 候选尾实体:按隐空间距离的 softmax 采样(温度控制可学性)
            target = ent_z[h] + rel_z[r]
            d = np.linalg.norm(ent_z[:num_ent] - target, axis=1)
            p = np.exp(-d / 0.6)
            p = p / p.sum()
            t = int(rng.choice(num_ent, p=p))
            if t == h:
                continue
            key = (h, r, t)
            if key in seen:
                continue
            seen.add(key)
            out.append(key)
        assert len(out) == n, f"采样不足: {len(out)}/{n}"
        return out

    base = os.path.join(args.out, 'SYNTH')
    seen = set()
    lo = 0
    for ss in range(5):
        d = os.path.join(base, str(ss))
        os.makedirs(d, exist_ok=True)
        for split, n in (('train', N_TRAIN[ss]), ('valid', N_VALID[ss]), ('test', N_TEST[ss])):
            triples = sample_triples(n, ENT[ss], REL[ss], lo, seen)
            with open(os.path.join(d, split + '.txt'), 'w') as f:
                for (h, r, t) in triples:
                    f.write(f"e{h}\tr{r}\te{t}\n")
        lo = ENT[ss]
    print(f"合成数据已生成: {base}  (5 snapshots, 实体 {ENT[-1]}, 基关系 {REL[-1]})")


if __name__ == '__main__':
    main()
