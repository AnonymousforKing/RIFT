# -*- coding: utf-8 -*-
"""predict 优化前后对比基准:速度 / 中间内存 / 数值一致性(可在 Mac 上运行)。

对比对象:
  reference = 原版 predict 的逐字转录(物化 [B,R,D] 大张量 + einsum + 逐 snapshot 重算)
  optimized = 本仓库 BaseModel.predict(共享余弦 + 掩码,O(B·R) 中间内存 + 可选分块打分)

用法:
  python scripts/bench_predict.py                       # CPU float64,含数值对拍
  python scripts/bench_predict.py --device mps          # M2 Max GPU(float32)
  python scripts/bench_predict.py --ents 4000 8000 12000 --rels 800
"""
import argparse
import sys, os, time
import numpy as np
import torch
import torch.nn as nn
from torch import Tensor

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from src.model.BaseModel import BaseModel


class A:
    pass


class Snap:
    pass


class KG:
    pass


def sync(device):
    if device.type == 'cuda':
        torch.cuda.synchronize()
    elif device.type == 'mps':
        torch.mps.synchronize()


def predict_reference(model, sub, rel, obj, stage='Test'):
    '''原版 predict 逐字转录(3D 张量路径),用于对拍与计时。'''
    self = model
    if stage != 'Test':
        num_ent = self.kg.snapshots[self.args.snapshot].num_ent
    else:
        num_ent = self.kg.snapshots[self.args.snapshot_test].num_ent
    stage = 'Test'
    ent_embeddings_list, rel_embeddings = self.embedding(stage)
    score_all = None
    r = torch.index_select(rel_embeddings, 0, rel)
    r_norm = self.norm_rel(r)
    attention_all = None
    idx = 0
    index_module = 0
    for t in range(len(ent_embeddings_list)):
        item = ent_embeddings_list[index_module]
        index_module += 1
        sub_mask = (sub >= 0) & (sub < item.shape[0])
        obj_mask = (obj >= 0) & (obj < item.shape[0])
        train_ent2rel = self.kg.snapshots[idx].train_ent2rel
        if num_ent > train_ent2rel.shape[0]:
            train_ent2rel = np.concatenate((train_ent2rel, np.zeros((num_ent - train_ent2rel.shape[0], train_ent2rel.shape[1]))), axis=0)
        else:
            train_ent2rel = train_ent2rel[:num_ent]
        sub_cpu = sub.cpu().detach().numpy()
        sub_r_index = Tensor(train_ent2rel[sub_cpu, :]).to(self.args.device)
        if sub_r_index.shape[1] < rel_embeddings.shape[0]:
            sub_r_index = torch.cat([sub_r_index, torch.zeros(sub_r_index.shape[0], rel_embeddings.shape[0] - sub_r_index.shape[1]).to(self.args.device)], dim=1)
        idx = idx + 1
        sub_r_embedding = sub_r_index.unsqueeze(2) * rel_embeddings
        norm_matrix1 = torch.norm(sub_r_embedding, dim=2)
        attention = torch.einsum('brd,bd->br', sub_r_embedding, r)
        nonzero_mask1 = norm_matrix1 > 0
        norm_matrix1 = torch.where(nonzero_mask1, norm_matrix1, norm_matrix1.new_tensor(1.0))
        norm_matrix2 = torch.norm(r, dim=1).unsqueeze(1)
        cos_attention = attention / (norm_matrix1 * norm_matrix2)
        k = int(self.args.Top_k)
        top_k_values, top_k_indices = torch.topk(cos_attention, k, dim=1)
        attention = top_k_values.sum(dim=1)
        attention[~sub_mask] = 0
        attention[~obj_mask] = 0
        attention_all = attention.unsqueeze(1) if attention_all is None else torch.cat([attention_all, attention.unsqueeze(1)], dim=1)
    attention_all = nn.Softmax(dim=-1)(attention_all)
    if self.args.wo_adaptive == 'True':
        attention_all = torch.ones_like(attention_all) / attention_all.size(-1)
    index_module = 0
    with torch.no_grad():
        for t in range(len(self.ent_embeddings_list)):
            item = ent_embeddings_list[index_module]
            sub_mask = (sub >= 0) & (sub < item.shape[0])
            obj_mask = (obj >= 0) & (obj < item.shape[0])
            item = item[:num_ent]
            item = torch.cat([item, torch.zeros(num_ent - item.shape[0], self.args.emb_dim).to(self.args.device)], dim=0)
            s = torch.index_select(item, 0, sub)
            o_all = item[:num_ent]
            s = self.norm_ent(s)
            o_all = self.norm_ent(o_all)
            pred_o = s + r_norm
            score = 9.0 - torch.norm(pred_o.unsqueeze(1) - o_all, p=1, dim=2)
            score[~sub_mask] = 0
            score[~obj_mask] = 0
            score_all = score * attention_all[:, index_module].unsqueeze(1) if score_all is None \
                else score_all + score * attention_all[:, index_module].unsqueeze(1)
            index_module += 1
        return score_all, torch.sum(attention_all, dim=0)


def build(ents, rels, D, device, dtype, chunk):
    torch.manual_seed(7); np.random.seed(7)
    torch.set_default_dtype(dtype)
    args = A()
    args.emb_dim = D
    args.device = device
    args.margin = 8.0
    args.Parameter_cut = 'False'
    args.Top_k = 3
    args.wo_adaptive = 'False'
    args.quantum_attn = 'False'
    args.eval_ent_chunk = chunk
    args.adv_temp = 0.0
    args.neg_ratio = 10
    args.snapshot = len(ents) - 1
    args.snapshot_test = len(ents) - 1
    kg = KG(); kg.snapshots = {}
    R_each = np.linspace(rels // 2, rels, len(ents)).astype(int)
    for i, ne in enumerate(ents):
        s = Snap(); s.num_ent = ne; s.num_rel = int(R_each[i])
        te = (np.random.rand(ne, s.num_rel) < 0.02).astype(np.float64)
        te *= np.random.choice([1, 1, 2, 3], size=te.shape)
        s.train_ent2rel = te
        kg.snapshots[i] = s
    model = BaseModel(args, kg).to(device)
    with torch.no_grad():
        for i in range(1, len(ents)):
            model.ent_embeddings_list.append(nn.Parameter(torch.randn(ents[i], D, device=device)))
        model.rel_embeddings = nn.Parameter(torch.randn(rels, D, device=device))
    return model, args


def timed(fn, reps, device):
    for _ in range(2):
        fn()
    sync(device)
    t0 = time.perf_counter()
    for _ in range(reps):
        fn()
    sync(device)
    return (time.perf_counter() - t0) / reps


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--device', default='cpu', choices=['cpu', 'mps', 'cuda'])
    ap.add_argument('--ents', type=int, nargs='+', default=[3000, 5000, 8000])
    ap.add_argument('--rels', type=int, default=500)
    ap.add_argument('--dim', type=int, default=200)
    ap.add_argument('--batch', type=int, default=100)
    ap.add_argument('--chunk', type=int, default=4096)
    ap.add_argument('--reps', type=int, default=5)
    args_cli = ap.parse_args()

    device = torch.device(args_cli.device)
    if device.type == 'mps' and not torch.backends.mps.is_available():
        print('MPS 不可用,回退 CPU'); device = torch.device('cpu')
    dtype = torch.float32 if device.type == 'mps' else torch.float64

    B, R, D = args_cli.batch, args_cli.rels, args_cli.dim
    model, margs = build(args_cli.ents, R, D, device, dtype, args_cli.chunk)
    ne = args_cli.ents[-1]
    sub = torch.randint(0, ne, (B,), device=device)
    obj = torch.randint(0, ne, (B,), device=device)
    rel = torch.randint(0, R, (B,), device=device)

    bytes_ = torch.finfo(dtype).bits // 8
    n_snap = len(args_cli.ents)
    print(f"设备={device} dtype={dtype}  B={B} R={R} D={D} snapshots={n_snap} 实体={args_cli.ents}")
    print(f"注意力中间张量: 原版 [B,R,D]×{n_snap} = {n_snap*B*R*D*bytes_/1e6:.0f} MB"
          f"  →  优化 [B,R] 共享 = {B*R*bytes_/1e6:.2f} MB  (约 {D}× 降低/每 snapshot)")

    if device.type == 'cpu' and dtype == torch.float64:
        s_ref, a_ref = predict_reference(model, sub, rel, obj)
        s_opt, a_opt = model.predict(sub, rel, obj, stage='Test')
        print(f"数值对拍(float64): score max|Δ| = {(s_ref-s_opt).abs().max().item():.2e}"
              f",  attention max|Δ| = {(a_ref-a_opt).abs().max().item():.2e}")

    t_ref = timed(lambda: predict_reference(model, sub, rel, obj), args_cli.reps, device)
    t_opt = timed(lambda: model.predict(sub, rel, obj, stage='Test'), args_cli.reps, device)
    print(f"predict 每批耗时: 原版 {t_ref*1e3:.1f} ms  →  优化 {t_opt*1e3:.1f} ms"
          f"  (加速 {t_ref/t_opt:.2f}×)")


if __name__ == '__main__':
    main()
