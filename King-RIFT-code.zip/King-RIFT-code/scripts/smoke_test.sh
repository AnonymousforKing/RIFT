#!/usr/bin/env bash
# 一键冒烟测试:在本机(Mac / Linux / 有无 GPU 均可)端到端验证优化后的代码。
# 用法:  bash scripts/smoke_test.sh
# 内容:  单元/等价性测试 → 生成合成数据 → 5 组端到端配置(默认/float32/准确率包/
#        参数整合+量子/量子注意力),每组跑满 5 个 snapshot 的训练+评测。
set -e
cd "$(dirname "$0")/.."
export PYTORCH_ENABLE_MPS_FALLBACK=1   # MPS 个别算子缺失时自动回退 CPU(防御性)

LOGDIR=scripts/_smoke_logs
mkdir -p "$LOGDIR"

echo "==== [0/7] 单元与等价性测试 ===="
python tests/verify_scatter.py
python tests/verify_quantum.py
python tests/verify_equivalence.py
python tests/verify_predict_equivalence.py
python tests/verify_accuracy_opts.py
python tests/verify_ib_align.py

echo "==== [1/7] 生成合成数据 ===="
python scripts/gen_synth_data.py --out ./data --seed 55

COMMON="-dataset SYNTH -data_path ./data/ -snapshot_num 5 -epoch_num 3 -patience 2 \
        -emb_dim 32 -batch_size 512 -neg_ratio 4 -seed 55"

run () {
  local name="$1"; shift
  echo "==== $name ===="
  # shellcheck disable=SC2086
  python main.py $COMMON "$@" 2>&1 | tee "$LOGDIR/$name.log" | tail -4
  grep -q "Report Result" "$LOGDIR/$name.log" || { echo "[FAIL] $name 未产出 Report Result"; exit 1; }
  echo "[OK] $name"
}

run "2of7_default"        # 默认路径:CPU/CUDA 上与原版数值一致(Mac 上自动用 MPS+float32)
run "3of7_float32_chunk"  -fp float32 -eval_ent_chunk 64
run "4of7_accuracy_pack"  -restore_best True -adv_temp 1.0 -lr_scheduler plateau \
                          -neg_avoid_pos True -grad_clip 1.0
grep -q "restored best-valid weights" "$LOGDIR/4of7_accuracy_pack.log" \
  || { echo "[FAIL] restore_best 未生效"; exit 1; }
echo "[OK] restore_best 已生效(检测到最优权重恢复日志)"
run "5of7_param_cut_quantum" -Parameter_cut True -threshold 0.9 \
                          -quantum_cut True -quantum_sim_mode hadamard -restore_best True
run "6of7_quantum_attn"   -quantum_attn True -quantum_sim_mode swap
run "7of8_ib_align"       -ib_align_weight 0.05 -ib_mode ibb -ib_beta 1.0 -restore_best True

echo "==== [8/8] 全部冒烟测试通过 ✅ ===="
echo "日志目录: $LOGDIR/"
